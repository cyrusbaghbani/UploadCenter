﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbHamyarnetTvDataContext
/// </summary>
/// 
namespace DataAccsess
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "Common.MediaZhanr")]
    public partial class MediaZhanr : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private int _ZhanrId;

        private System.Guid _MediaId;

        private string _Dsc;

        private EntityRef<Zhanr> _Zhanr;

        private EntityRef<Media> _Media;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnZhanrIdChanging(int value);
        partial void OnZhanrIdChanged();
        partial void OnMediaIdChanging(System.Guid value);
        partial void OnMediaIdChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        #endregion

        public MediaZhanr()
        {
            this._Zhanr = default(EntityRef<Zhanr>);
            this._Media = default(EntityRef<Media>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ZhanrId", DbType = "Int NOT NULL")]
        public int ZhanrId
        {
            get
            {
                return this._ZhanrId;
            }
            set
            {
                if ((this._ZhanrId != value))
                {
                    if (this._Zhanr.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnZhanrIdChanging(value);
                    this.SendPropertyChanging();
                    this._ZhanrId = value;
                    this.SendPropertyChanged("ZhanrId");
                    this.OnZhanrIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MediaId", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid MediaId
        {
            get
            {
                return this._MediaId;
            }
            set
            {
                if ((this._MediaId != value))
                {
                    if (this._Media.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnMediaIdChanging(value);
                    this.SendPropertyChanging();
                    this._MediaId = value;
                    this.SendPropertyChanged("MediaId");
                    this.OnMediaIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Zhanr_MediaZhanr", Storage = "_Zhanr", ThisKey = "ZhanrId", OtherKey = "Id", IsForeignKey = true)]
        public Zhanr Zhanr
        {
            get
            {
                return this._Zhanr.Entity;
            }
            set
            {
                Zhanr previousValue = this._Zhanr.Entity;
                if (((previousValue != value)
                            || (this._Zhanr.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Zhanr.Entity = null;
                        previousValue.MediaZhanrs.Remove(this);
                    }
                    this._Zhanr.Entity = value;
                    if ((value != null))
                    {
                        value.MediaZhanrs.Add(this);
                        this._ZhanrId = value.Id;
                    }
                    else
                    {
                        this._ZhanrId = default(int);
                    }
                    this.SendPropertyChanged("Zhanr");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Media_MediaZhanr", Storage = "_Media", ThisKey = "MediaId", OtherKey = "UID", IsForeignKey = true)]
        public Media Media
        {
            get
            {
                return this._Media.Entity;
            }
            set
            {
                Media previousValue = this._Media.Entity;
                if (((previousValue != value)
                            || (this._Media.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Media.Entity = null;
                        previousValue.MediaZhanrs.Remove(this);
                    }
                    this._Media.Entity = value;
                    if ((value != null))
                    {
                        value.MediaZhanrs.Add(this);
                        this._MediaId = value.UID;
                    }
                    else
                    {
                        this._MediaId = default(System.Guid);
                    }
                    this.SendPropertyChanged("Media");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}