﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbHamyarnetTvDataContext
/// </summary>
/// 
namespace DataAccsess
{

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "Common.Media")]
    public partial class Media : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private string _Name;

        private string _NameKeyword;

        private string _AvamelFilmKeyword;

        private string _Dsc;

        private string _UrlAxPoshtCard;

        private string _PosterAxUrl;

        private string _UrlAxJeloCard;

        private string _UrlAxVideoStrip;

        private string _Dsc_PoshtCard;

        private int _Pishfarz_Bazdid;

        private int _Pishfarz_Download;

        private System.Nullable<int> _Priority;

        private System.DateTime _ZamanSabt;

        private string _MediaTime;

        private string _UrlAxFilmhayMoshabe;

        private System.Nullable<int> _SalSakhtMiladi;

        private System.Nullable<int> _SalSakht;

        private string _AvamelFilm;

        private bool _IsShowSalSakhtMiadi;

        private bool _IsUseFilterForPoshtJesld;

        private bool _IsShowMediaInSite;

        private EntitySet<Dastebandi> _Dastebandis;

        private EntitySet<MediaGallery> _MediaGalleries;

        private EntitySet<MediaLink> _MediaLinks;

        private EntitySet<Comment> _Comments;

        private EntitySet<MediaZhanr> _MediaZhanrs;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnUrlAxPoshtCardChanging(string value);
        partial void OnUrlAxPoshtCardChanged();
        partial void OnUrlAxJeloCardChanging(string value);
        partial void OnUrlAxJeloCardChanged();
        partial void OnUrlAxVideoStripChanging(string value);
        partial void OnUrlAxVideoStripChanged();
        partial void OnDsc_PoshtCardChanging(string value);
        partial void OnDsc_PoshtCardChanged();
        partial void OnPriorityChanging(System.Nullable<int> value);
        partial void OnPriorityChanged();
        partial void OnZamanSabtChanging(System.DateTime value);
        partial void OnZamanSabtChanged();
        partial void OnMediaTimeChanging(string value);
        partial void OnMediaTimeChanged();
        partial void OnUrlAxFilmhayMoshabeChanging(string value);
        partial void OnUrlAxFilmhayMoshabeChanged();
        partial void OnSalSakhtMiladiChanging(System.Nullable<int> value);
        partial void OnSalSakhtMiladiChanged();
        partial void OnSalSakhtChanging(System.Nullable<int> value);
        partial void OnSalSakhtChanged();
        partial void OnAvamelFilmChanging(string value);
        partial void OnAvamelFilmChanged();
        partial void OnZhanrIdChanging(System.Nullable<int> value);
        partial void OnZhanrIdChanged();
        partial void OnIsShowSalSakhtMiadiChanging(bool value);
        partial void OnIsShowSalSakhtMiadiChanged();
        partial void OnPosterAxUrlChanging(string value);
        partial void OnPosterAxUrlChanged();
        partial void OnIsUseFilterForPoshtJesldChanging(bool value);
        partial void OnIsUseFilterForPoshtJesldChanged();
        partial void OnNameKeywordChanging(string value);
        partial void OnNameKeywordChanged();
        partial void OnAvamelFilmKeywordChanging(string value);
        partial void OnAvamelFilmKeywordChanged();
        partial void OnIsShowMediaInSiteChanging(bool value);
        partial void OnIsShowMediaInSiteChanged();
        partial void OnPishfarz_BazdidChanging(int value);
        partial void OnPishfarz_BazdidChanged();
        partial void OnPishfarz_DownloadChanging(int value);
        partial void OnPishfarz_DownloadChanged();

        #endregion

        public Media()
        {
            this._MediaZhanrs = new EntitySet<MediaZhanr>(new Action<MediaZhanr>(this.attach_MediaZhanrs), new Action<MediaZhanr>(this.detach_MediaZhanrs));
            this._Comments = new EntitySet<Comment>(new Action<Comment>(this.attach_Comments), new Action<Comment>(this.detach_Comments));
            this._Dastebandis = new EntitySet<Dastebandi>(new Action<Dastebandi>(this.attach_Dastebandis), new Action<Dastebandi>(this.detach_Dastebandis));
            this._MediaGalleries = new EntitySet<MediaGallery>(new Action<MediaGallery>(this.attach_MediaGalleries), new Action<MediaGallery>(this.detach_MediaGalleries));
            this._MediaLinks = new EntitySet<MediaLink>(new Action<MediaLink>(this.attach_MediaLinks), new Action<MediaLink>(this.detach_MediaLinks));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(200)")]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this.OnNameChanging(value);
                    this.SendPropertyChanging();
                    this._Name = value;
                    this.SendPropertyChanged("Name");
                    this.OnNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_NameKeyword", DbType = "NVarChar(MAX)")]
        public string NameKeyword
        {
            get
            {
                return this._NameKeyword;
            }
            set
            {
                if ((this._NameKeyword != value))
                {
                    this.OnNameKeywordChanging(value);
                    this.SendPropertyChanging();
                    this._NameKeyword = value;
                    this.SendPropertyChanged("NameKeyword");
                    this.OnNameKeywordChanged();
                }
            }
        }
        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AvamelFilmKeyword", DbType = "NVarChar(MAX)")]
        public string AvamelFilmKeyword
        {
            get
            {
                return this._AvamelFilmKeyword;
            }
            set
            {
                if ((this._AvamelFilmKeyword != value))
                {
                    this.OnAvamelFilmKeywordChanging(value);
                    this.SendPropertyChanging();
                    this._AvamelFilmKeyword = value;
                    this.SendPropertyChanged("AvamelFilmKeyword");
                    this.OnAvamelFilmKeywordChanged();
                }
            }
        }


        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UrlAxPoshtCard", DbType = "NVarChar(500)")]
        public string UrlAxPoshtCard
        {
            get
            {
                return this._UrlAxPoshtCard;
            }
            set
            {
                if ((this._UrlAxPoshtCard != value))
                {
                    this.OnUrlAxPoshtCardChanging(value);
                    this.SendPropertyChanging();
                    this._UrlAxPoshtCard = value;
                    this.SendPropertyChanged("UrlAxPoshtCard");
                    this.OnUrlAxPoshtCardChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UrlAxJeloCard", DbType = "NVarChar(500)")]
        public string UrlAxJeloCard
        {
            get
            {
                return this._UrlAxJeloCard;
            }
            set
            {
                if ((this._UrlAxJeloCard != value))
                {
                    this.OnUrlAxJeloCardChanging(value);
                    this.SendPropertyChanging();
                    this._UrlAxJeloCard = value;
                    this.SendPropertyChanged("UrlAxJeloCard");
                    this.OnUrlAxJeloCardChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UrlAxVideoStrip", DbType = "NVarChar(500)")]
        public string UrlAxVideoStrip
        {
            get
            {
                return this._UrlAxVideoStrip;
            }
            set
            {
                if ((this._UrlAxVideoStrip != value))
                {
                    this.OnUrlAxVideoStripChanging(value);
                    this.SendPropertyChanging();
                    this._UrlAxVideoStrip = value;
                    this.SendPropertyChanged("UrlAxVideoStrip");
                    this.OnUrlAxVideoStripChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PosterAxUrl", DbType = "NVarChar(500)")]
        public string PosterAxUrl
        {
            get
            {
                return this._PosterAxUrl;
            }
            set
            {
                if ((this._PosterAxUrl != value))
                {
                    this.OnPosterAxUrlChanging(value);
                    this.SendPropertyChanging();
                    this._PosterAxUrl = value;
                    this.SendPropertyChanged("PosterAxUrl");
                    this.OnPosterAxUrlChanged();
                }
            }
        }


        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc_PoshtCard", DbType = "NVarChar(MAX)")]
        public string Dsc_PoshtCard
        {
            get
            {
                return this._Dsc_PoshtCard;
            }
            set
            {
                if ((this._Dsc_PoshtCard != value))
                {
                    this.OnDsc_PoshtCardChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc_PoshtCard = value;
                    this.SendPropertyChanged("Dsc_PoshtCard");
                    this.OnDsc_PoshtCardChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Priority", DbType = "Int")]
        public System.Nullable<int> Priority
        {
            get
            {
                return this._Priority;
            }
            set
            {
                if ((this._Priority != value))
                {
                    this.OnPriorityChanging(value);
                    this.SendPropertyChanging();
                    this._Priority = value;
                    this.SendPropertyChanged("Priority");
                    this.OnPriorityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ZamanSabt", DbType = "DateTime NOT NULL")]
        public System.DateTime ZamanSabt
        {
            get
            {
                return this._ZamanSabt;
            }
            set
            {
                if ((this._ZamanSabt != value))
                {
                    this.OnZamanSabtChanging(value);
                    this.SendPropertyChanging();
                    this._ZamanSabt = value;
                    this.SendPropertyChanged("ZamanSabt");
                    this.OnZamanSabtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MediaTime", DbType = "NVarChar(8)")]
        public string MediaTime
        {
            get
            {
                return this._MediaTime;
            }
            set
            {
                if ((this._MediaTime != value))
                {
                    this.OnMediaTimeChanging(value);
                    this.SendPropertyChanging();
                    this._MediaTime = value;
                    this.SendPropertyChanged("MediaTime");
                    this.OnMediaTimeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UrlAxFilmhayMoshabe", DbType = "NVarChar(500)")]
        public string UrlAxFilmhayMoshabe
        {
            get
            {
                return this._UrlAxFilmhayMoshabe;
            }
            set
            {
                if ((this._UrlAxFilmhayMoshabe != value))
                {
                    this.OnUrlAxFilmhayMoshabeChanging(value);
                    this.SendPropertyChanging();
                    this._UrlAxFilmhayMoshabe = value;
                    this.SendPropertyChanged("UrlAxFilmhayMoshabe");
                    this.OnUrlAxFilmhayMoshabeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SalSakhtMiladi", DbType = "Int")]
        public System.Nullable<int> SalSakhtMiladi
        {
            get
            {
                return this._SalSakhtMiladi;
            }
            set
            {
                if ((this._SalSakhtMiladi != value))
                {
                    this.OnSalSakhtMiladiChanging(value);
                    this.SendPropertyChanging();
                    this._SalSakhtMiladi = value;
                    this.SendPropertyChanged("SalSakhtMiladi");
                    this.OnSalSakhtMiladiChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SalSakht", DbType = "Int")]
        public System.Nullable<int> SalSakht
        {
            get
            {
                return this._SalSakht;
            }
            set
            {
                if ((this._SalSakht != value))
                {
                    this.OnSalSakhtChanging(value);
                    this.SendPropertyChanging();
                    this._SalSakht = value;
                    this.SendPropertyChanged("SalSakht");
                    this.OnSalSakhtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AvamelFilm", DbType = "NVarChar(MAX)")]
        public string AvamelFilm
        {
            get
            {
                return this._AvamelFilm;
            }
            set
            {
                if ((this._AvamelFilm != value))
                {
                    this.OnAvamelFilmChanging(value);
                    this.SendPropertyChanging();
                    this._AvamelFilm = value;
                    this.SendPropertyChanged("AvamelFilm");
                    this.OnAvamelFilmChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsShowSalSakhtMiadi", DbType = "Bit NOT NULL")]
        public bool IsShowSalSakhtMiadi
        {
            get
            {
                return this._IsShowSalSakhtMiadi;
            }
            set
            {
                if ((this._IsShowSalSakhtMiadi != value))
                {
                    this.OnIsShowSalSakhtMiadiChanging(value);
                    this.SendPropertyChanging();
                    this._IsShowSalSakhtMiadi = value;
                    this.SendPropertyChanged("IsShowSalSakhtMiadi");
                    this.OnIsShowSalSakhtMiadiChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsUseFilterForPoshtJesld", DbType = "Bit NOT NULL")]
        public bool IsUseFilterForPoshtJesld
        {
            get
            {
                return this._IsUseFilterForPoshtJesld;
            }
            set
            {
                if ((this._IsUseFilterForPoshtJesld != value))
                {
                    this.OnIsUseFilterForPoshtJesldChanging(value);
                    this.SendPropertyChanging();
                    this._IsUseFilterForPoshtJesld = value;
                    this.SendPropertyChanged("IsUseFilterForPoshtJesld");
                    this.OnIsUseFilterForPoshtJesldChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Pishfarz_Bazdid", DbType = "Int NOT NULL")]
        public int Pishfarz_Bazdid
        {
            get
            {
                return this._Pishfarz_Bazdid;
            }
            set
            {
                if ((this._Pishfarz_Bazdid != value))
                {
                    this.OnPishfarz_BazdidChanging(value);
                    this.SendPropertyChanging();
                    this._Pishfarz_Bazdid = value;
                    this.SendPropertyChanged("Pishfarz_Bazdid");
                    this.OnPishfarz_BazdidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Pishfarz_Download", DbType = "Int NOT NULL")]
        public int Pishfarz_Download
        {
            get
            {
                return this._Pishfarz_Download;
            }
            set
            {
                if ((this._Pishfarz_Download != value))
                {
                    this.OnPishfarz_DownloadChanging(value);
                    this.SendPropertyChanging();
                    this._Pishfarz_Download = value;
                    this.SendPropertyChanged("Pishfarz_Download");
                    this.OnPishfarz_DownloadChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsShowMediaInSite", DbType = "Bit NOT NULL")]
        public bool IsShowMediaInSite
        {
            get
            {
                return this._IsShowMediaInSite;
            }
            set
            {
                if ((this._IsShowMediaInSite != value))
                {
                    this.OnIsShowMediaInSiteChanging(value);
                    this.SendPropertyChanging();
                    this._IsShowMediaInSite = value;
                    this.SendPropertyChanged("IsShowMediaInSite");
                    this.OnIsShowMediaInSiteChanged();
                }
            }
        }


        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Media_Dastebandi", Storage = "_Dastebandis", ThisKey = "UID", OtherKey = "MediaId")]
        public EntitySet<Dastebandi> Dastebandis
        {
            get
            {
                return this._Dastebandis;
            }
            set
            {
                this._Dastebandis.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Media_MediaGallery", Storage = "_MediaGalleries", ThisKey = "UID", OtherKey = "MediaId")]
        public EntitySet<MediaGallery> MediaGalleries
        {
            get
            {
                return this._MediaGalleries;
            }
            set
            {
                this._MediaGalleries.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Media_MediaLink", Storage = "_MediaLinks", ThisKey = "UID", OtherKey = "MediaId")]
        public EntitySet<MediaLink> MediaLinks
        {
            get
            {
                return this._MediaLinks;
            }
            set
            {
                this._MediaLinks.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Media_Comment", Storage = "_Comments", ThisKey = "UID", OtherKey = "MediaId")]
        public EntitySet<Comment> Comments
        {
            get
            {
                return this._Comments;
            }
            set
            {
                this._Comments.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Media_MediaZhanr", Storage = "_MediaZhanrs", ThisKey = "UID", OtherKey = "MediaId")]
        public EntitySet<MediaZhanr> MediaZhanrs
        {
            get
            {
                return this._MediaZhanrs;
            }
            set
            {
                this._MediaZhanrs.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_Dastebandis(Dastebandi entity)
        {
            this.SendPropertyChanging();
            entity.Media = this;
        }

        private void detach_Dastebandis(Dastebandi entity)
        {
            this.SendPropertyChanging();
            entity.Media = null;
        }

        private void attach_MediaGalleries(MediaGallery entity)
        {
            this.SendPropertyChanging();
            entity.Media = this;
        }

        private void detach_MediaGalleries(MediaGallery entity)
        {
            this.SendPropertyChanging();
            entity.Media = null;
        }

        private void attach_MediaLinks(MediaLink entity)
        {
            this.SendPropertyChanging();
            entity.Media = this;
        }

        private void detach_MediaLinks(MediaLink entity)
        {
            this.SendPropertyChanging();
            entity.Media = null;
        }

        private void attach_Comments(Comment entity)
        {
            this.SendPropertyChanging();
            entity.Media = this;
        }

        private void detach_Comments(Comment entity)
        {
            this.SendPropertyChanging();
            entity.Media = null;
        }
        private void attach_MediaZhanrs(MediaZhanr entity)
        {
            this.SendPropertyChanging();
            entity.Media = this;
        }

        private void detach_MediaZhanrs(MediaZhanr entity)
        {
            this.SendPropertyChanging();
            entity.Media = null;
        }
    }
}