﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbHamyarnetTvDataContext
/// </summary>
/// 
namespace DataAccsess
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "Common.MediaLink")]
    public partial class MediaLink : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Guid _MediaId;

        private string _UrlName;

        private string _MediaName;

        private string _ExtentionMedia;

        private System.Nullable<decimal> _Hajm;

        private bool _IsShowOnVideo;

        private System.Nullable<int> _qualityId;

        private EntitySet<FaaliatKarbaran> _FaaliatKarbarans;

        private EntityRef<Media> _Media;

        private EntityRef<Quality> _Quality;

        private string _OnvanNamayeshFilm;

        private System.Nullable<int> _priority;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnMediaIdChanging(System.Guid value);
        partial void OnMediaIdChanged();
        partial void OnUrlNameChanging(string value);
        partial void OnUrlNameChanged();
        partial void OnMediaNameChanging(string value);
        partial void OnMediaNameChanged();
        partial void OnExtentionMediaChanging(string value);
        partial void OnExtentionMediaChanged();
        partial void OnHajmChanging(System.Nullable<decimal> value);
        partial void OnHajmChanged();
        partial void OnIsShowOnVideoChanging(bool value);
        partial void OnIsShowOnVideoChanged();
        partial void OnqualityIdChanging(System.Nullable<int> value);
        partial void OnqualityIdChanged();
        partial void OnOnvanNamayeshFilmChanging(string value);
        partial void OnOnvanNamayeshFilmChanged();
        partial void OnpriorityChanging(System.Nullable<int> value);
        partial void OnpriorityChanged();
        #endregion

        public MediaLink()
        {
            this._FaaliatKarbarans = new EntitySet<FaaliatKarbaran>(new Action<FaaliatKarbaran>(this.attach_FaaliatKarbarans), new Action<FaaliatKarbaran>(this.detach_FaaliatKarbarans));
            this._Media = default(EntityRef<Media>);
            this._Quality = default(EntityRef<Quality>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MediaId", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid MediaId
        {
            get
            {
                return this._MediaId;
            }
            set
            {
                if ((this._MediaId != value))
                {
                    if (this._Media.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnMediaIdChanging(value);
                    this.SendPropertyChanging();
                    this._MediaId = value;
                    this.SendPropertyChanged("MediaId");
                    this.OnMediaIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UrlName", DbType = "NVarChar(MAX)")]
        public string UrlName
        {
            get
            {
                return this._UrlName;
            }
            set
            {
                if ((this._UrlName != value))
                {
                    this.OnUrlNameChanging(value);
                    this.SendPropertyChanging();
                    this._UrlName = value;
                    this.SendPropertyChanged("UrlName");
                    this.OnUrlNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OnvanNamayeshFilm", DbType = "NVarChar(MAX)")]
        public string OnvanNamayeshFilm
        {
            get
            {
                return this._OnvanNamayeshFilm;
            }
            set
            {
                if ((this._OnvanNamayeshFilm != value))
                {
                    this.OnOnvanNamayeshFilmChanging(value);
                    this.SendPropertyChanging();
                    this._OnvanNamayeshFilm = value;
                    this.SendPropertyChanged("OnvanNamayeshFilm");
                    this.OnOnvanNamayeshFilmChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MediaName", DbType = "NVarChar(MAX)")]
        public string MediaName
        {
            get
            {
                return this._MediaName;
            }
            set
            {
                if ((this._MediaName != value))
                {
                    this.OnMediaNameChanging(value);
                    this.SendPropertyChanging();
                    this._MediaName = value;
                    this.SendPropertyChanged("MediaName");
                    this.OnMediaNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ExtentionMedia", DbType = "NVarChar(50)")]
        public string ExtentionMedia
        {
            get
            {
                return this._ExtentionMedia;
            }
            set
            {
                if ((this._ExtentionMedia != value))
                {
                    this.OnExtentionMediaChanging(value);
                    this.SendPropertyChanging();
                    this._ExtentionMedia = value;
                    this.SendPropertyChanged("ExtentionMedia");
                    this.OnExtentionMediaChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Hajm", DbType = "Decimal(18,1)")]
        public System.Nullable<decimal> Hajm
        {
            get
            {
                return this._Hajm;
            }
            set
            {
                if ((this._Hajm != value))
                {
                    this.OnHajmChanging(value);
                    this.SendPropertyChanging();
                    this._Hajm = value;
                    this.SendPropertyChanged("Hajm");
                    this.OnHajmChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsShowOnVideo", DbType = "Bit NOT NULL")]
        public bool IsShowOnVideo
        {
            get
            {
                return this._IsShowOnVideo;
            }
            set
            {
                if ((this._IsShowOnVideo != value))
                {
                    this.OnIsShowOnVideoChanging(value);
                    this.SendPropertyChanging();
                    this._IsShowOnVideo = value;
                    this.SendPropertyChanged("IsShowOnVideo");
                    this.OnIsShowOnVideoChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_priority", DbType = "Int")]
        public System.Nullable<int> priority
        {
            get
            {
                return this._priority;
            }
            set
            {
                if ((this._priority != value))
                {
                    if (this._Quality.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnpriorityChanging(value);
                    this.SendPropertyChanging();
                    this._priority = value;
                    this.SendPropertyChanged("priority");
                    this.OnpriorityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_qualityId", DbType = "Int")]
        public System.Nullable<int> qualityId
        {
            get
            {
                return this._qualityId;
            }
            set
            {
                if ((this._qualityId != value))
                {
                    if (this._Quality.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnqualityIdChanging(value);
                    this.SendPropertyChanging();
                    this._qualityId = value;
                    this.SendPropertyChanged("qualityId");
                    this.OnqualityIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "MediaLink_FaaliatKarbaran", Storage = "_FaaliatKarbarans", ThisKey = "UID", OtherKey = "MediaLinkId")]
        public EntitySet<FaaliatKarbaran> FaaliatKarbarans
        {
            get
            {
                return this._FaaliatKarbarans;
            }
            set
            {
                this._FaaliatKarbarans.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Media_MediaLink", Storage = "_Media", ThisKey = "MediaId", OtherKey = "UID", IsForeignKey = true)]
        public Media Media
        {
            get
            {
                return this._Media.Entity;
            }
            set
            {
                Media previousValue = this._Media.Entity;
                if (((previousValue != value)
                            || (this._Media.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Media.Entity = null;
                        previousValue.MediaLinks.Remove(this);
                    }
                    this._Media.Entity = value;
                    if ((value != null))
                    {
                        value.MediaLinks.Add(this);
                        this._MediaId = value.UID;
                    }
                    else
                    {
                        this._MediaId = default(System.Guid);
                    }
                    this.SendPropertyChanged("Media");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Quality_MediaLink", Storage = "_Quality", ThisKey = "qualityId", OtherKey = "Id", IsForeignKey = true)]
        public Quality Quality
        {
            get
            {
                return this._Quality.Entity;
            }
            set
            {
                Quality previousValue = this._Quality.Entity;
                if (((previousValue != value)
                            || (this._Quality.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Quality.Entity = null;
                        previousValue.MediaLinks.Remove(this);
                    }
                    this._Quality.Entity = value;
                    if ((value != null))
                    {
                        value.MediaLinks.Add(this);
                        this._qualityId = value.Id;
                    }
                    else
                    {
                        this._qualityId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("Quality");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_FaaliatKarbarans(FaaliatKarbaran entity)
        {
            this.SendPropertyChanging();
            entity.MediaLink = this;
        }

        private void detach_FaaliatKarbarans(FaaliatKarbaran entity)
        {
            this.SendPropertyChanging();
            entity.MediaLink = null;
        }
    }
}