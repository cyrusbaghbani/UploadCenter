﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbHamyarnetTvDataContext
/// </summary>
/// 
namespace DataAccsess
{

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "Common.Dastebandi")]
    public partial class Dastebandi : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Guid _MediaId;

        private int _DastebandiTypeId;

        private string _Dsc;

        private bool _IsShowOnSite;

        private EntityRef<DastebandiType> _DastebandiType;

        private EntityRef<Media> _Media;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnMediaIdChanging(System.Guid value);
        partial void OnMediaIdChanged();
        partial void OnDastebandiTypeIdChanging(int value);
        partial void OnDastebandiTypeIdChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnIsShowOnSiteChanging(bool value);
        partial void OnIsShowOnSiteChanged();
        #endregion

        public Dastebandi()
        {
            this._DastebandiType = default(EntityRef<DastebandiType>);
            this._Media = default(EntityRef<Media>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MediaId", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid MediaId
        {
            get
            {
                return this._MediaId;
            }
            set
            {
                if ((this._MediaId != value))
                {
                    if (this._Media.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnMediaIdChanging(value);
                    this.SendPropertyChanging();
                    this._MediaId = value;
                    this.SendPropertyChanged("MediaId");
                    this.OnMediaIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DastebandiTypeId", DbType = "Int NOT NULL")]
        public int DastebandiTypeId
        {
            get
            {
                return this._DastebandiTypeId;
            }
            set
            {
                if ((this._DastebandiTypeId != value))
                {
                    if (this._DastebandiType.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnDastebandiTypeIdChanging(value);
                    this.SendPropertyChanging();
                    this._DastebandiTypeId = value;
                    this.SendPropertyChanged("DastebandiTypeId");
                    this.OnDastebandiTypeIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "DastebandiType_Dastebandi", Storage = "_DastebandiType", ThisKey = "DastebandiTypeId", OtherKey = "Id", IsForeignKey = true)]
        public DastebandiType DastebandiType
        {
            get
            {
                return this._DastebandiType.Entity;
            }
            set
            {
                DastebandiType previousValue = this._DastebandiType.Entity;
                if (((previousValue != value)
                            || (this._DastebandiType.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._DastebandiType.Entity = null;
                        previousValue.Dastebandis.Remove(this);
                    }
                    this._DastebandiType.Entity = value;
                    if ((value != null))
                    {
                        value.Dastebandis.Add(this);
                        this._DastebandiTypeId = value.Id;
                    }
                    else
                    {
                        this._DastebandiTypeId = default(int);
                    }
                    this.SendPropertyChanged("DastebandiType");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Media_Dastebandi", Storage = "_Media", ThisKey = "MediaId", OtherKey = "UID", IsForeignKey = true)]
        public Media Media
        {
            get
            {
                return this._Media.Entity;
            }
            set
            {
                Media previousValue = this._Media.Entity;
                if (((previousValue != value)
                            || (this._Media.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Media.Entity = null;
                        previousValue.Dastebandis.Remove(this);
                    }
                    this._Media.Entity = value;
                    if ((value != null))
                    {
                        value.Dastebandis.Add(this);
                        this._MediaId = value.UID;
                    }
                    else
                    {
                        this._MediaId = default(System.Guid);
                    }
                    this.SendPropertyChanged("Media");
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsShowOnSite", DbType = "Bit NOT NULL")]
        public bool IsShowOnSite
        {
            get
            {
                return this._IsShowOnSite;
            }
            set
            {
                if ((this._IsShowOnSite != value))
                {
                    this.OnIsShowOnSiteChanging(value);
                    this.SendPropertyChanging();
                    this._IsShowOnSite = value;
                    this.SendPropertyChanged("IsShowOnSite");
                    this.OnIsShowOnSiteChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
	
}