﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbHamyarnetTvDataContext
/// </summary>
/// 
namespace DataAccsess
{

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "Common.Events")]
    public partial class Event : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Guid _UserID;

        private int _EventTypeId;

        private string _IP;

        private string _Dsc;

        private string _Date;

        private string _Time;

        private System.DateTime _En_DateTime;

        private EntityRef<EventType> _EventType;

        private EntityRef<_User> @__User;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnUserIDChanging(System.Guid value);
        partial void OnUserIDChanged();
        partial void OnEventTypeIdChanging(int value);
        partial void OnEventTypeIdChanged();
        partial void OnIPChanging(string value);
        partial void OnIPChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnDateChanging(string value);
        partial void OnDateChanged();
        partial void OnTimeChanging(string value);
        partial void OnTimeChanged();
        partial void OnEn_DateTimeChanging(System.DateTime value);
        partial void OnEn_DateTimeChanged();
        #endregion

        public Event()
        {
            this._EventType = default(EntityRef<EventType>);
            this.@__User = default(EntityRef<_User>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserID", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid UserID
        {
            get
            {
                return this._UserID;
            }
            set
            {
                if ((this._UserID != value))
                {
                    if (this.@__User.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserIDChanging(value);
                    this.SendPropertyChanging();
                    this._UserID = value;
                    this.SendPropertyChanged("UserID");
                    this.OnUserIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_EventTypeId", DbType = "Int NOT NULL")]
        public int EventTypeId
        {
            get
            {
                return this._EventTypeId;
            }
            set
            {
                if ((this._EventTypeId != value))
                {
                    if (this._EventType.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnEventTypeIdChanging(value);
                    this.SendPropertyChanging();
                    this._EventTypeId = value;
                    this.SendPropertyChanged("EventTypeId");
                    this.OnEventTypeIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IP", DbType = "NVarChar(50)")]
        public string IP
        {
            get
            {
                return this._IP;
            }
            set
            {
                if ((this._IP != value))
                {
                    this.OnIPChanging(value);
                    this.SendPropertyChanging();
                    this._IP = value;
                    this.SendPropertyChanged("IP");
                    this.OnIPChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Date", DbType = "NChar(10)")]
        public string Date
        {
            get
            {
                return this._Date;
            }
            set
            {
                if ((this._Date != value))
                {
                    this.OnDateChanging(value);
                    this.SendPropertyChanging();
                    this._Date = value;
                    this.SendPropertyChanged("Date");
                    this.OnDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Time", DbType = "NChar(8)")]
        public string Time
        {
            get
            {
                return this._Time;
            }
            set
            {
                if ((this._Time != value))
                {
                    this.OnTimeChanging(value);
                    this.SendPropertyChanging();
                    this._Time = value;
                    this.SendPropertyChanged("Time");
                    this.OnTimeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_En_DateTime", DbType = "DateTime NOT NULL")]
        public System.DateTime En_DateTime
        {
            get
            {
                return this._En_DateTime;
            }
            set
            {
                if ((this._En_DateTime != value))
                {
                    this.OnEn_DateTimeChanging(value);
                    this.SendPropertyChanging();
                    this._En_DateTime = value;
                    this.SendPropertyChanged("En_DateTime");
                    this.OnEn_DateTimeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "EventType_Event", Storage = "_EventType", ThisKey = "EventTypeId", OtherKey = "Id", IsForeignKey = true)]
        public EventType EventType
        {
            get
            {
                return this._EventType.Entity;
            }
            set
            {
                EventType previousValue = this._EventType.Entity;
                if (((previousValue != value)
                            || (this._EventType.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._EventType.Entity = null;
                        previousValue.Events.Remove(this);
                    }
                    this._EventType.Entity = value;
                    if ((value != null))
                    {
                        value.Events.Add(this);
                        this._EventTypeId = value.Id;
                    }
                    else
                    {
                        this._EventTypeId = default(int);
                    }
                    this.SendPropertyChanged("EventType");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "_User_Event", Storage = "__User", ThisKey = "UserID", OtherKey = "UID", IsForeignKey = true)]
        public _User _User
        {
            get
            {
                return this.@__User.Entity;
            }
            set
            {
                _User previousValue = this.@__User.Entity;
                if (((previousValue != value)
                            || (this.@__User.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this.@__User.Entity = null;
                        previousValue.Events.Remove(this);
                    }
                    this.@__User.Entity = value;
                    if ((value != null))
                    {
                        value.Events.Add(this);
                        this._UserID = value.UID;
                    }
                    else
                    {
                        this._UserID = default(System.Guid);
                    }
                    this.SendPropertyChanged("_User");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}