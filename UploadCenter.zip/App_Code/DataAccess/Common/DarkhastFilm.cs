﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbHamyarnetTvDataContext
/// </summary>
/// 
namespace DataAccsess
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "Common.DarkhastFilm")]
    public partial class DarkhastFilm : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Guid _UserId;

        private string _NamFilm;

        private string _SalSakht;

        private string _AvamelFilm;

        private string _Dsc;

        private bool _IsRead;

        private System.DateTime _ZamanSabt;

        private string _Date;

        private string _Time;

        private EntityRef<_User> @__User;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnUserIdChanging(System.Guid value);
        partial void OnUserIdChanged();
        partial void OnNamFilmChanging(string value);
        partial void OnNamFilmChanged();
        partial void OnSalSakhtChanging(string value);
        partial void OnSalSakhtChanged();
        partial void OnAvamelFilmChanging(string value);
        partial void OnAvamelFilmChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnIsReadChanging(bool value);
        partial void OnIsReadChanged();
        partial void OnZamanSabtChanging(System.DateTime value);
        partial void OnZamanSabtChanged();
        partial void OnDateChanging(string value);
        partial void OnDateChanged();
        partial void OnTimeChanging(string value);
        partial void OnTimeChanged();
        #endregion

        public DarkhastFilm()
        {
            this.@__User = default(EntityRef<_User>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserId", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid UserId
        {
            get
            {
                return this._UserId;
            }
            set
            {
                if ((this._UserId != value))
                {
                    if (this.@__User.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserIdChanging(value);
                    this.SendPropertyChanging();
                    this._UserId = value;
                    this.SendPropertyChanged("UserId");
                    this.OnUserIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_NamFilm", DbType = "NVarChar(MAX)")]
        public string NamFilm
        {
            get
            {
                return this._NamFilm;
            }
            set
            {
                if ((this._NamFilm != value))
                {
                    this.OnNamFilmChanging(value);
                    this.SendPropertyChanging();
                    this._NamFilm = value;
                    this.SendPropertyChanged("NamFilm");
                    this.OnNamFilmChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SalSakht", DbType = "NVarChar(MAX)")]
        public string SalSakht
        {
            get
            {
                return this._SalSakht;
            }
            set
            {
                if ((this._SalSakht != value))
                {
                    this.OnSalSakhtChanging(value);
                    this.SendPropertyChanging();
                    this._SalSakht = value;
                    this.SendPropertyChanged("SalSakht");
                    this.OnSalSakhtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AvamelFilm", DbType = "NVarChar(MAX)")]
        public string AvamelFilm
        {
            get
            {
                return this._AvamelFilm;
            }
            set
            {
                if ((this._AvamelFilm != value))
                {
                    this.OnAvamelFilmChanging(value);
                    this.SendPropertyChanging();
                    this._AvamelFilm = value;
                    this.SendPropertyChanged("AvamelFilm");
                    this.OnAvamelFilmChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsRead", DbType = "Bit NOT NULL")]
        public bool IsRead
        {
            get
            {
                return this._IsRead;
            }
            set
            {
                if ((this._IsRead != value))
                {
                    this.OnIsReadChanging(value);
                    this.SendPropertyChanging();
                    this._IsRead = value;
                    this.SendPropertyChanged("IsRead");
                    this.OnIsReadChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ZamanSabt", DbType = "DateTime NOT NULL")]
        public System.DateTime ZamanSabt
        {
            get
            {
                return this._ZamanSabt;
            }
            set
            {
                if ((this._ZamanSabt != value))
                {
                    this.OnZamanSabtChanging(value);
                    this.SendPropertyChanging();
                    this._ZamanSabt = value;
                    this.SendPropertyChanged("ZamanSabt");
                    this.OnZamanSabtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Date", DbType = "NChar(10)")]
        public string Date
        {
            get
            {
                return this._Date;
            }
            set
            {
                if ((this._Date != value))
                {
                    this.OnDateChanging(value);
                    this.SendPropertyChanging();
                    this._Date = value;
                    this.SendPropertyChanged("Date");
                    this.OnDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Time", DbType = "NChar(8)")]
        public string Time
        {
            get
            {
                return this._Time;
            }
            set
            {
                if ((this._Time != value))
                {
                    this.OnTimeChanging(value);
                    this.SendPropertyChanging();
                    this._Time = value;
                    this.SendPropertyChanged("Time");
                    this.OnTimeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "_User_DarkhastFilm", Storage = "__User", ThisKey = "UserId", OtherKey = "UID", IsForeignKey = true)]
        public _User _User
        {
            get
            {
                return this.@__User.Entity;
            }
            set
            {
                _User previousValue = this.@__User.Entity;
                if (((previousValue != value)
                            || (this.@__User.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this.@__User.Entity = null;
                        previousValue.DarkhastFilms.Remove(this);
                    }
                    this.@__User.Entity = value;
                    if ((value != null))
                    {
                        value.DarkhastFilms.Add(this);
                        this._UserId = value.UID;
                    }
                    else
                    {
                        this._UserId = default(System.Guid);
                    }
                    this.SendPropertyChanged("_User");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }


}