﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbHamyarnetTvDataContext
/// </summary>
/// 
namespace DataAccsess
{

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "Common.MediaGallery")]
    public partial class MediaGallery : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Guid _MediaId;

        private System.Nullable<int> _Priority;

        private string _ImageUrl;

        private string _Dsc;

        private EntityRef<Media> _Media;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnMediaIdChanging(System.Guid value);
        partial void OnMediaIdChanged();
        partial void OnPriorityChanging(System.Nullable<int> value);
        partial void OnPriorityChanged();
        partial void OnImageUrlChanging(string value);
        partial void OnImageUrlChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        #endregion

        public MediaGallery()
        {
            this._Media = default(EntityRef<Media>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MediaId", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid MediaId
        {
            get
            {
                return this._MediaId;
            }
            set
            {
                if ((this._MediaId != value))
                {
                    if (this._Media.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnMediaIdChanging(value);
                    this.SendPropertyChanging();
                    this._MediaId = value;
                    this.SendPropertyChanged("MediaId");
                    this.OnMediaIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Priority", DbType = "Int")]
        public System.Nullable<int> Priority
        {
            get
            {
                return this._Priority;
            }
            set
            {
                if ((this._Priority != value))
                {
                    this.OnPriorityChanging(value);
                    this.SendPropertyChanging();
                    this._Priority = value;
                    this.SendPropertyChanged("Priority");
                    this.OnPriorityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ImageUrl", DbType = "NVarChar(MAX)")]
        public string ImageUrl
        {
            get
            {
                return this._ImageUrl;
            }
            set
            {
                if ((this._ImageUrl != value))
                {
                    this.OnImageUrlChanging(value);
                    this.SendPropertyChanging();
                    this._ImageUrl = value;
                    this.SendPropertyChanged("ImageUrl");
                    this.OnImageUrlChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Media_MediaGallery", Storage = "_Media", ThisKey = "MediaId", OtherKey = "UID", IsForeignKey = true)]
        public Media Media
        {
            get
            {
                return this._Media.Entity;
            }
            set
            {
                Media previousValue = this._Media.Entity;
                if (((previousValue != value)
                            || (this._Media.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Media.Entity = null;
                        previousValue.MediaGalleries.Remove(this);
                    }
                    this._Media.Entity = value;
                    if ((value != null))
                    {
                        value.MediaGalleries.Add(this);
                        this._MediaId = value.UID;
                    }
                    else
                    {
                        this._MediaId = default(System.Guid);
                    }
                    this.SendPropertyChanged("Media");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}