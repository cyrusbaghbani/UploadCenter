﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbHamyarnetTvDataContext
/// </summary>
/// 
namespace DataAccsess
{

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "Common.Comment")]
    public partial class Comment : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private string _Dsc;

        private int _CommentTypeId;

        private bool _IsRead;

        private System.Nullable<bool> _IsShowOnSite;

        private string _Time;

        private string _Date;

        private System.Nullable<System.DateTime> _SabtDate;

        private System.Nullable<System.Guid> _ParentId;

        private System.Nullable<System.Guid> _UserId;

        private System.Guid _MediaId;

        private EntityRef<Media> _Media;

        private EntitySet<Comment> _childs_Comments;

        private EntityRef<Comment> _Parents_Comments;

        private EntityRef<CommentType> _CommentType;

        private EntityRef<_User> @__User;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnCommentTypeIdChanging(int value);
        partial void OnCommentTypeIdChanged();
        partial void OnIsReadChanging(bool value);
        partial void OnIsReadChanged();
        partial void OnIsShowOnSiteChanging(System.Nullable<bool> value);
        partial void OnIsShowOnSiteChanged();
        partial void OnTimeChanging(string value);
        partial void OnTimeChanged();
        partial void OnDateChanging(string value);
        partial void OnDateChanged();
        partial void OnSabtDateChanging(System.Nullable<System.DateTime> value);
        partial void OnSabtDateChanged();
        partial void OnParentIdChanging(System.Nullable<System.Guid> value);
        partial void OnParentIdChanged();
        partial void OnUserIdChanging(System.Nullable<System.Guid> value);
        partial void OnUserIdChanged();
        partial void OnMediaIdChanging(System.Guid value);
        partial void OnMediaIdChanged();
        #endregion

        public Comment()
        {
            this._Media = default(EntityRef<Media>);
            this._childs_Comments = new EntitySet<Comment>(new Action<Comment>(this.attach_childs_Comments), new Action<Comment>(this.detach_childs_Comments));
            this._Parents_Comments = default(EntityRef<Comment>);
            this._CommentType = default(EntityRef<CommentType>);
            this.@__User = default(EntityRef<_User>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CommentTypeId", DbType = "Int NOT NULL")]
        public int CommentTypeId
        {
            get
            {
                return this._CommentTypeId;
            }
            set
            {
                if ((this._CommentTypeId != value))
                {
                    if (this._CommentType.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnCommentTypeIdChanging(value);
                    this.SendPropertyChanging();
                    this._CommentTypeId = value;
                    this.SendPropertyChanged("CommentTypeId");
                    this.OnCommentTypeIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsRead", DbType = "Bit NOT NULL")]
        public bool IsRead
        {
            get
            {
                return this._IsRead;
            }
            set
            {
                if ((this._IsRead != value))
                {
                    this.OnIsReadChanging(value);
                    this.SendPropertyChanging();
                    this._IsRead = value;
                    this.SendPropertyChanged("IsRead");
                    this.OnIsReadChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsShowOnSite", DbType = "Bit")]
        public System.Nullable<bool> IsShowOnSite
        {
            get
            {
                return this._IsShowOnSite;
            }
            set
            {
                if ((this._IsShowOnSite != value))
                {
                    this.OnIsShowOnSiteChanging(value);
                    this.SendPropertyChanging();
                    this._IsShowOnSite = value;
                    this.SendPropertyChanged("IsShowOnSite");
                    this.OnIsShowOnSiteChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Time", DbType = "NVarChar(8)")]
        public string Time
        {
            get
            {
                return this._Time;
            }
            set
            {
                if ((this._Time != value))
                {
                    this.OnTimeChanging(value);
                    this.SendPropertyChanging();
                    this._Time = value;
                    this.SendPropertyChanged("Time");
                    this.OnTimeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Date", DbType = "NVarChar(10)")]
        public string Date
        {
            get
            {
                return this._Date;
            }
            set
            {
                if ((this._Date != value))
                {
                    this.OnDateChanging(value);
                    this.SendPropertyChanging();
                    this._Date = value;
                    this.SendPropertyChanged("Date");
                    this.OnDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SabtDate", DbType = "DateTime")]
        public System.Nullable<System.DateTime> SabtDate
        {
            get
            {
                return this._SabtDate;
            }
            set
            {
                if ((this._SabtDate != value))
                {
                    this.OnSabtDateChanging(value);
                    this.SendPropertyChanging();
                    this._SabtDate = value;
                    this.SendPropertyChanged("SabtDate");
                    this.OnSabtDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ParentId", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> ParentId
        {
            get
            {
                return this._ParentId;
            }
            set
            {
                if ((this._ParentId != value))
                {
                    if (this._Parents_Comments.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnParentIdChanging(value);
                    this.SendPropertyChanging();
                    this._ParentId = value;
                    this.SendPropertyChanged("ParentId");
                    this.OnParentIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserId", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> UserId
        {
            get
            {
                return this._UserId;
            }
            set
            {
                if ((this._UserId != value))
                {
                    if (this.@__User.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserIdChanging(value);
                    this.SendPropertyChanging();
                    this._UserId = value;
                    this.SendPropertyChanged("UserId");
                    this.OnUserIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MediaId", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid MediaId
        {
            get
            {
                return this._MediaId;
            }
            set
            {
                if ((this._MediaId != value))
                {
                    if (this._Media.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnMediaIdChanging(value);
                    this.SendPropertyChanging();
                    this._MediaId = value;
                    this.SendPropertyChanged("MediaId");
                    this.OnMediaIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Comment_Comment", Storage = "_childs_Comments", ThisKey = "UID", OtherKey = "ParentId")]
        public EntitySet<Comment> childs_Comments
        {
            get
            {
                return this._childs_Comments;
            }
            set
            {
                this._childs_Comments.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Comment_Comment", Storage = "_Parents_Comments", ThisKey = "ParentId", OtherKey = "UID", IsForeignKey = true)]
        public Comment Parents_Comments
        {
            get
            {
                return this._Parents_Comments.Entity;
            }
            set
            {
                Comment previousValue = this._Parents_Comments.Entity;
                if (((previousValue != value)
                            || (this._Parents_Comments.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Parents_Comments.Entity = null;
                        previousValue.childs_Comments.Remove(this);
                    }
                    this._Parents_Comments.Entity = value;
                    if ((value != null))
                    {
                        value.childs_Comments.Add(this);
                        this._ParentId = value.UID;
                    }
                    else
                    {
                        this._ParentId = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("Parents_Comments");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "CommentType_Comment", Storage = "_CommentType", ThisKey = "CommentTypeId", OtherKey = "Id", IsForeignKey = true)]
        public CommentType CommentType
        {
            get
            {
                return this._CommentType.Entity;
            }
            set
            {
                CommentType previousValue = this._CommentType.Entity;
                if (((previousValue != value)
                            || (this._CommentType.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._CommentType.Entity = null;
                        previousValue.Comments.Remove(this);
                    }
                    this._CommentType.Entity = value;
                    if ((value != null))
                    {
                        value.Comments.Add(this);
                        this._CommentTypeId = value.Id;
                    }
                    else
                    {
                        this._CommentTypeId = default(int);
                    }
                    this.SendPropertyChanged("CommentType");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "_User_Comment", Storage = "__User", ThisKey = "UserId", OtherKey = "UID", IsForeignKey = true)]
        public _User _User
        {
            get
            {
                return this.@__User.Entity;
            }
            set
            {
                _User previousValue = this.@__User.Entity;
                if (((previousValue != value)
                            || (this.@__User.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this.@__User.Entity = null;
                        previousValue.Comments.Remove(this);
                    }
                    this.@__User.Entity = value;
                    if ((value != null))
                    {
                        value.Comments.Add(this);
                        this._UserId = value.UID;
                    }
                    else
                    {
                        this._UserId = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("_User");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Media_Comment", Storage = "_Media", ThisKey = "MediaId", OtherKey = "UID", IsForeignKey = true)]
        public Media Media
        {
            get
            {
                return this._Media.Entity;
            }
            set
            {
                Media previousValue = this._Media.Entity;
                if (((previousValue != value)
                            || (this._Media.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Media.Entity = null;
                        previousValue.Comments.Remove(this);
                    }
                    this._Media.Entity = value;
                    if ((value != null))
                    {
                        value.Comments.Add(this);
                        this._MediaId = value.UID;
                    }
                    else
                    {
                        this._MediaId = default(System.Guid);
                    }
                    this.SendPropertyChanged("Media");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_childs_Comments(Comment entity)
        {
            this.SendPropertyChanging();
            entity.Parents_Comments = this;
        }

        private void detach_childs_Comments(Comment entity)
        {
            this.SendPropertyChanging();
            entity.Parents_Comments = null;
        }
    }
}