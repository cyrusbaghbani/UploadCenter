﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbHamyarnetTvDataContext
/// </summary>
/// 
namespace DataAccsess
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "Common.TempSave")]
    public partial class TempSave : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private string _Address;
  
        private string _Type;

        private System.Nullable<System.DateTime> _Datetime;

        private System.Nullable<decimal> _Hajm;

        private System.Nullable<bool> _IsShowOnVideo;

        private System.Nullable<int> _qualityId;

        private EntityRef<Quality> _Quality;

        private string _OnvanNamayeshFilm;

        private System.Nullable<int> _priority;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnAddressChanging(string value);
        partial void OnAddressChanged();
        partial void OnTypeChanging(string value);
        partial void OnTypeChanged();
        partial void OnDatetimeChanging(System.Nullable<System.DateTime> value);
        partial void OnDatetimeChanged();
        partial void OnHajmChanging(System.Nullable<decimal> value);
        partial void OnHajmChanged();
        partial void OnIsShowOnVideoChanging(System.Nullable<bool> value);
        partial void OnIsShowOnVideoChanged();
        partial void OnqualityIdChanging(System.Nullable<int> value);
        partial void OnqualityIdChanged();
        partial void OnOnvanNamayeshFilmChanging(string value);
        partial void OnOnvanNamayeshFilmChanged();
        partial void OnpriorityChanging(System.Nullable<int> value);
        partial void OnpriorityChanged();
   

       
        #endregion

        public TempSave()
        {
            this._Quality = default(EntityRef<Quality>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Address", DbType = "NVarChar(MAX)")]
        public string Address
        {
            get
            {
                return this._Address;
            }
            set
            {
                if ((this._Address != value))
                {
                    this.OnAddressChanging(value);
                    this.SendPropertyChanging();
                    this._Address = value;
                    this.SendPropertyChanged("Address");
                    this.OnAddressChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_priority", DbType = "Int")]
        public System.Nullable<int> priority
        {
            get
            {
                return this._priority;
            }
            set
            {
                if ((this._priority != value))
                {
                    if (this._Quality.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnpriorityChanging(value);
                    this.SendPropertyChanging();
                    this._priority = value;
                    this.SendPropertyChanged("priority");
                    this.OnpriorityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OnvanNamayeshFilm", DbType = "NVarChar(MAX)")]
        public string OnvanNamayeshFilm
        {
            get
            {
                return this._OnvanNamayeshFilm;
            }
            set
            {
                if ((this._OnvanNamayeshFilm != value))
                {
                    this.OnOnvanNamayeshFilmChanging(value);
                    this.SendPropertyChanging();
                    this._OnvanNamayeshFilm = value;
                    this.SendPropertyChanged("OnvanNamayeshFilm");
                    this.OnOnvanNamayeshFilmChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Type", DbType = "NVarChar(MAX)")]
        public string Type
        {
            get
            {
                return this._Type;
            }
            set
            {
                if ((this._Type != value))
                {
                    this.OnTypeChanging(value);
                    this.SendPropertyChanging();
                    this._Type = value;
                    this.SendPropertyChanged("Type");
                    this.OnTypeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Datetime", DbType = "DateTime")]
        public System.Nullable<System.DateTime> Datetime
        {
            get
            {
                return this._Datetime;
            }
            set
            {
                if ((this._Datetime != value))
                {
                    this.OnDatetimeChanging(value);
                    this.SendPropertyChanging();
                    this._Datetime = value;
                    this.SendPropertyChanged("Datetime");
                    this.OnDatetimeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Hajm", DbType = "Decimal(18,1)")]
        public System.Nullable<decimal> Hajm
        {
            get
            {
                return this._Hajm;
            }
            set
            {
                if ((this._Hajm != value))
                {
                    this.OnHajmChanging(value);
                    this.SendPropertyChanging();
                    this._Hajm = value;
                    this.SendPropertyChanged("Hajm");
                    this.OnHajmChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsShowOnVideo", DbType = "Bit")]
        public System.Nullable<bool> IsShowOnVideo
        {
            get
            {
                return this._IsShowOnVideo;
            }
            set
            {
                if ((this._IsShowOnVideo != value))
                {
                    this.OnIsShowOnVideoChanging(value);
                    this.SendPropertyChanging();
                    this._IsShowOnVideo = value;
                    this.SendPropertyChanged("IsShowOnVideo");
                    this.OnIsShowOnVideoChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_qualityId", DbType = "Int")]
        public System.Nullable<int> qualityId
        {
            get
            {
                return this._qualityId;
            }
            set
            {
                if ((this._qualityId != value))
                {
                    if (this._Quality.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnqualityIdChanging(value);
                    this.SendPropertyChanging();
                    this._qualityId = value;
                    this.SendPropertyChanged("qualityId");
                    this.OnqualityIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Quality_TempSave", Storage = "_Quality", ThisKey = "qualityId", OtherKey = "Id", IsForeignKey = true)]
        public Quality Quality
        {
            get
            {
                return this._Quality.Entity;
            }
            set
            {
                Quality previousValue = this._Quality.Entity;
                if (((previousValue != value)
                            || (this._Quality.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Quality.Entity = null;
                        previousValue.TempSaves.Remove(this);
                    }
                    this._Quality.Entity = value;
                    if ((value != null))
                    {
                        value.TempSaves.Add(this);
                        this._qualityId = value.Id;
                    }
                    else
                    {
                        this._qualityId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("Quality");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}