﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbHamyarnetTvDataContext
/// </summary>
/// 
namespace DataAccsess
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "Common.FaaliatKarbaran")]
    public partial class FaaliatKarbaran : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Nullable<System.Guid> _UserId;

        private string _IP;

        private string _Dsc;

        private System.Nullable<int> _FaaliatTypeId;

        private System.Nullable<System.Guid> _MediaLinkId;

        private System.Nullable<System.DateTime> _ZamanSabt;

        private EntityRef<FaaliatType> _FaaliatType;

        private EntityRef<MediaLink> _MediaLink;

        private EntityRef<_User> @__User;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnUserIdChanging(System.Nullable<System.Guid> value);
        partial void OnUserIdChanged();
        partial void OnIPChanging(string value);
        partial void OnIPChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnFaaliatTypeIdChanging(System.Nullable<int> value);
        partial void OnFaaliatTypeIdChanged();
        partial void OnMediaLinkIdChanging(System.Nullable<System.Guid> value);
        partial void OnMediaLinkIdChanged();
        partial void OnZamanSabtChanging(System.Nullable<System.DateTime> value);
        partial void OnZamanSabtChanged();
        #endregion

        public FaaliatKarbaran()
        {
            this._FaaliatType = default(EntityRef<FaaliatType>);
            this._MediaLink = default(EntityRef<MediaLink>);
            this.@__User = default(EntityRef<_User>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserId", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> UserId
        {
            get
            {
                return this._UserId;
            }
            set
            {
                if ((this._UserId != value))
                {
                    if (this.@__User.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserIdChanging(value);
                    this.SendPropertyChanging();
                    this._UserId = value;
                    this.SendPropertyChanged("UserId");
                    this.OnUserIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IP", DbType = "NVarChar(50)")]
        public string IP
        {
            get
            {
                return this._IP;
            }
            set
            {
                if ((this._IP != value))
                {
                    this.OnIPChanging(value);
                    this.SendPropertyChanging();
                    this._IP = value;
                    this.SendPropertyChanged("IP");
                    this.OnIPChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FaaliatTypeId", DbType = "Int")]
        public System.Nullable<int> FaaliatTypeId
        {
            get
            {
                return this._FaaliatTypeId;
            }
            set
            {
                if ((this._FaaliatTypeId != value))
                {
                    if (this._FaaliatType.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnFaaliatTypeIdChanging(value);
                    this.SendPropertyChanging();
                    this._FaaliatTypeId = value;
                    this.SendPropertyChanged("FaaliatTypeId");
                    this.OnFaaliatTypeIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MediaLinkId", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> MediaLinkId
        {
            get
            {
                return this._MediaLinkId;
            }
            set
            {
                if ((this._MediaLinkId != value))
                {
                    if (this._MediaLink.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnMediaLinkIdChanging(value);
                    this.SendPropertyChanging();
                    this._MediaLinkId = value;
                    this.SendPropertyChanged("MediaLinkId");
                    this.OnMediaLinkIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ZamanSabt", DbType = "DateTime")]
        public System.Nullable<System.DateTime> ZamanSabt
        {
            get
            {
                return this._ZamanSabt;
            }
            set
            {
                if ((this._ZamanSabt != value))
                {
                    this.OnZamanSabtChanging(value);
                    this.SendPropertyChanging();
                    this._ZamanSabt = value;
                    this.SendPropertyChanged("ZamanSabt");
                    this.OnZamanSabtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "FaaliatType_FaaliatKarbaran", Storage = "_FaaliatType", ThisKey = "FaaliatTypeId", OtherKey = "Id", IsForeignKey = true)]
        public FaaliatType FaaliatType
        {
            get
            {
                return this._FaaliatType.Entity;
            }
            set
            {
                FaaliatType previousValue = this._FaaliatType.Entity;
                if (((previousValue != value)
                            || (this._FaaliatType.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._FaaliatType.Entity = null;
                        previousValue.FaaliatKarbarans.Remove(this);
                    }
                    this._FaaliatType.Entity = value;
                    if ((value != null))
                    {
                        value.FaaliatKarbarans.Add(this);
                        this._FaaliatTypeId = value.Id;
                    }
                    else
                    {
                        this._FaaliatTypeId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("FaaliatType");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "MediaLink_FaaliatKarbaran", Storage = "_MediaLink", ThisKey = "MediaLinkId", OtherKey = "UID", IsForeignKey = true)]
        public MediaLink MediaLink
        {
            get
            {
                return this._MediaLink.Entity;
            }
            set
            {
                MediaLink previousValue = this._MediaLink.Entity;
                if (((previousValue != value)
                            || (this._MediaLink.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._MediaLink.Entity = null;
                        previousValue.FaaliatKarbarans.Remove(this);
                    }
                    this._MediaLink.Entity = value;
                    if ((value != null))
                    {
                        value.FaaliatKarbarans.Add(this);
                        this._MediaLinkId = value.UID;
                    }
                    else
                    {
                        this._MediaLinkId = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("MediaLink");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "_User_FaaliatKarbaran", Storage = "__User", ThisKey = "UserId", OtherKey = "UID", IsForeignKey = true)]
        public _User _User
        {
            get
            {
                return this.@__User.Entity;
            }
            set
            {
                _User previousValue = this.@__User.Entity;
                if (((previousValue != value)
                            || (this.@__User.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this.@__User.Entity = null;
                        previousValue.FaaliatKarbarans.Remove(this);
                    }
                    this.@__User.Entity = value;
                    if ((value != null))
                    {
                        value.FaaliatKarbarans.Add(this);
                        this._UserId = value.UID;
                    }
                    else
                    {
                        this._UserId = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("_User");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}