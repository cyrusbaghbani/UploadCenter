﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbHamyarnetTvDataContext
/// </summary>
/// 
namespace DataAccsess
{

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "[_Systems].Quality")]
    public partial class Quality : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private string _Name;

        private string _Dsc;

        private System.Nullable<int> _Priority;

        private EntitySet<MediaLink> _MediaLinks;

        private EntitySet<TempSave> _TempSaves;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnPriorityChanging(System.Nullable<int> value);
        partial void OnPriorityChanged();
        #endregion

        public Quality()
        {
            this._TempSaves = new EntitySet<TempSave>(new Action<TempSave>(this.attach_TempSaves), new Action<TempSave>(this.detach_TempSaves));
            this._MediaLinks = new EntitySet<MediaLink>(new Action<MediaLink>(this.attach_MediaLinks), new Action<MediaLink>(this.detach_MediaLinks));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", DbType = "Int NOT NULL", IsPrimaryKey = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(200)")]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this.OnNameChanging(value);
                    this.SendPropertyChanging();
                    this._Name = value;
                    this.SendPropertyChanged("Name");
                    this.OnNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Priority", DbType = "Int")]
        public System.Nullable<int> Priority
        {
            get
            {
                return this._Priority;
            }
            set
            {
                if ((this._Priority != value))
                {
                    this.OnPriorityChanging(value);
                    this.SendPropertyChanging();
                    this._Priority = value;
                    this.SendPropertyChanged("Priority");
                    this.OnPriorityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Quality_MediaLink", Storage = "_MediaLinks", ThisKey = "Id", OtherKey = "qualityId")]
        public EntitySet<MediaLink> MediaLinks
        {
            get
            {
                return this._MediaLinks;
            }
            set
            {
                this._MediaLinks.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Quality_TempSave", Storage = "_TempSaves", ThisKey = "Id", OtherKey = "qualityId")]
        public EntitySet<TempSave> TempSaves
        {
            get
            {
                return this._TempSaves;
            }
            set
            {
                this._TempSaves.Assign(value);
            }
        }
		

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_MediaLinks(MediaLink entity)
        {
            this.SendPropertyChanging();
            entity.Quality = this;
        }

        private void detach_MediaLinks(MediaLink entity)
        {
            this.SendPropertyChanging();
            entity.Quality = null;
        }

        private void attach_TempSaves(TempSave entity)
        {
            this.SendPropertyChanging();
            entity.Quality = this;
        }

        private void detach_TempSaves(TempSave entity)
        {
            this.SendPropertyChanging();
            entity.Quality = null;
        }
    }
}