﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbHamyarnetTvDataContext
/// </summary>
/// 
namespace DataAccsess
{
    [global::System.Data.Linq.Mapping.DatabaseAttribute(Name = "db_hamyarnetTV")]
    public partial class dbhamyarnetTvDataContext : System.Data.Linq.DataContext
    {

        private static System.Data.Linq.Mapping.MappingSource mappingSource = new AttributeMappingSource();

        #region Extensibility Method Definitions
        partial void OnCreated();
        partial void InsertTempSave(TempSave instance);
        partial void UpdateTempSave(TempSave instance);
        partial void DeleteTempSave(TempSave instance);
        partial void InsertCommentType(CommentType instance);
        partial void UpdateCommentType(CommentType instance);
        partial void DeleteCommentType(CommentType instance);
        partial void InsertUserType(UserType instance);
        partial void UpdateUserType(UserType instance);
        partial void DeleteUserType(UserType instance);
        partial void InsertDastebandiType(DastebandiType instance);
        partial void UpdateDastebandiType(DastebandiType instance);
        partial void DeleteDastebandiType(DastebandiType instance);
        partial void InsertEventType(EventType instance);
        partial void UpdateEventType(EventType instance);
        partial void DeleteEventType(EventType instance);
        partial void InsertFaaliatType(FaaliatType instance);
        partial void UpdateFaaliatType(FaaliatType instance);
        partial void DeleteFaaliatType(FaaliatType instance);
        partial void InsertQuality(Quality instance);
        partial void UpdateQuality(Quality instance);
        partial void DeleteQuality(Quality instance);
        partial void InsertZhanr(Zhanr instance);
        partial void UpdateZhanr(Zhanr instance);
        partial void DeleteZhanr(Zhanr instance);
        partial void InsertComment(Comment instance);
        partial void UpdateComment(Comment instance);
        partial void DeleteComment(Comment instance);
        partial void InsertDarkhastFilm(DarkhastFilm instance);
        partial void UpdateDarkhastFilm(DarkhastFilm instance);
        partial void DeleteDarkhastFilm(DarkhastFilm instance);
        partial void InsertDastebandi(Dastebandi instance);
        partial void UpdateDastebandi(Dastebandi instance);
        partial void DeleteDastebandi(Dastebandi instance);
        partial void InsertEvent(Event instance);
        partial void UpdateEvent(Event instance);
        partial void DeleteEvent(Event instance);
        partial void InsertFaaliatKarbaran(FaaliatKarbaran instance);
        partial void UpdateFaaliatKarbaran(FaaliatKarbaran instance);
        partial void DeleteFaaliatKarbaran(FaaliatKarbaran instance);
        partial void InsertMedia(Media instance);
        partial void UpdateMedia(Media instance);
        partial void DeleteMedia(Media instance);
        partial void InsertMediaGallery(MediaGallery instance);
        partial void UpdateMediaGallery(MediaGallery instance);
        partial void DeleteMediaGallery(MediaGallery instance);
        partial void InsertMediaLink(MediaLink instance);
        partial void UpdateMediaLink(MediaLink instance);
        partial void DeleteMediaLink(MediaLink instance);
        partial void Insert_User(_User instance);
        partial void Update_User(_User instance);
        partial void Delete_User(_User instance);
        partial void InsertMediaZhanr(MediaZhanr instance);
        partial void UpdateMediaZhanr(MediaZhanr instance);
        partial void DeleteMediaZhanr(MediaZhanr instance);
        #endregion

        public dbhamyarnetTvDataContext() :
            base(global::System.Configuration.ConfigurationManager.ConnectionStrings["db_hamyarnetTVConnectionString"].ConnectionString, mappingSource)
        {
            OnCreated();
        }

        public dbhamyarnetTvDataContext(string connection) :
            base(connection, mappingSource)
        {
            OnCreated();
        }

        public dbhamyarnetTvDataContext(System.Data.IDbConnection connection) :
            base(connection, mappingSource)
        {
            OnCreated();
        }

        public dbhamyarnetTvDataContext(string connection, System.Data.Linq.Mapping.MappingSource mappingSource) :
            base(connection, mappingSource)
        {
            OnCreated();
        }

        public dbhamyarnetTvDataContext(System.Data.IDbConnection connection, System.Data.Linq.Mapping.MappingSource mappingSource) :
            base(connection, mappingSource)
        {
            OnCreated();
        }

        public System.Data.Linq.Table<CommentType> CommentTypes
        {
            get
            {
                return this.GetTable<CommentType>();
            }
        }

        public System.Data.Linq.Table<UserType> UserTypes
        {
            get
            {
                return this.GetTable<UserType>();
            }
        }

        public System.Data.Linq.Table<DastebandiType> DastebandiTypes
        {
            get
            {
                return this.GetTable<DastebandiType>();
            }
        }

        public System.Data.Linq.Table<EventType> EventTypes
        {
            get
            {
                return this.GetTable<EventType>();
            }
        }

        public System.Data.Linq.Table<FaaliatType> FaaliatTypes
        {
            get
            {
                return this.GetTable<FaaliatType>();
            }
        }

        public System.Data.Linq.Table<Quality> Qualities
        {
            get
            {
                return this.GetTable<Quality>();
            }
        }

        public System.Data.Linq.Table<Zhanr> Zhanrs
        {
            get
            {
                return this.GetTable<Zhanr>();
            }
        }

        public System.Data.Linq.Table<Comment> Comments
        {
            get
            {
                return this.GetTable<Comment>();
            }
        }

        public System.Data.Linq.Table<DarkhastFilm> DarkhastFilms
        {
            get
            {
                return this.GetTable<DarkhastFilm>();
            }
        }

        public System.Data.Linq.Table<Dastebandi> Dastebandis
        {
            get
            {
                return this.GetTable<Dastebandi>();
            }
        }

        public System.Data.Linq.Table<Event> Events
        {
            get
            {
                return this.GetTable<Event>();
            }
        }

        public System.Data.Linq.Table<FaaliatKarbaran> FaaliatKarbarans
        {
            get
            {
                return this.GetTable<FaaliatKarbaran>();
            }
        }

        public System.Data.Linq.Table<Media> Medias
        {
            get
            {
                return this.GetTable<Media>();
            }
        }

        public System.Data.Linq.Table<MediaGallery> MediaGalleries
        {
            get
            {
                return this.GetTable<MediaGallery>();
            }
        }

        public System.Data.Linq.Table<MediaLink> MediaLinks
        {
            get
            {
                return this.GetTable<MediaLink>();
            }
        }

        public System.Data.Linq.Table<_User> _Users
        {
            get
            {
                return this.GetTable<_User>();
            }
        }

        public System.Data.Linq.Table<MediaZhanr> MediaZhanrs
        {
            get
            {
                return this.GetTable<MediaZhanr>();
            }
        }
        public System.Data.Linq.Table<TempSave> TempSaves
        {
            get
            {
                return this.GetTable<TempSave>();
            }
        }
    }
}