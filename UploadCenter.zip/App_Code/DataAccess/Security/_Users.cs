﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for dbHamyarnetTvDataContext
/// </summary>
/// 
namespace DataAccsess
{

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "Security.[_Users]")]
    public partial class _User : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private string _FirstName;

        private string _LastName;

        private string _FullName;

        private string _Email;

        private string _Address;

        private System.Nullable<bool> _Sex_isMan;

        private string _UserName;

        private string _Password;

        private System.Nullable<int> _UserTypeId;

        private string _Mobile;

        private string _Telephone;

        private bool _IsActive;

        private string _Dsc;

        private System.DateTime _DateTimeSabtNam;

        private bool _IsLogin;

        private EntitySet<Comment> _Comments;

        private EntitySet<DarkhastFilm> _DarkhastFilms;

        private EntitySet<Event> _Events;

        private EntitySet<FaaliatKarbaran> _FaaliatKarbarans;

        private EntityRef<UserType> _UserType;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnFirstNameChanging(string value);
        partial void OnFirstNameChanged();
        partial void OnLastNameChanging(string value);
        partial void OnLastNameChanged();
        partial void OnFullNameChanging(string value);
        partial void OnFullNameChanged();
        partial void OnEmailChanging(string value);
        partial void OnEmailChanged();
        partial void OnAddressChanging(string value);
        partial void OnAddressChanged();
        partial void OnSex_isManChanging(System.Nullable<bool> value);
        partial void OnSex_isManChanged();
        partial void OnUserNameChanging(string value);
        partial void OnUserNameChanged();
        partial void OnPasswordChanging(string value);
        partial void OnPasswordChanged();
        partial void OnUserTypeIdChanging(System.Nullable<int> value);
        partial void OnUserTypeIdChanged();
        partial void OnMobileChanging(string value);
        partial void OnMobileChanged();
        partial void OnTelephoneChanging(string value);
        partial void OnTelephoneChanged();
        partial void OnIsActiveChanging(bool value);
        partial void OnIsActiveChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnDateTimeSabtNamChanging(System.DateTime value);
        partial void OnDateTimeSabtNamChanged();
        partial void OnIsLoginChanging(bool value);
        partial void OnIsLoginChanged();
        #endregion

        public _User()
        {
            this._Comments = new EntitySet<Comment>(new Action<Comment>(this.attach_Comments), new Action<Comment>(this.detach_Comments));
            this._DarkhastFilms = new EntitySet<DarkhastFilm>(new Action<DarkhastFilm>(this.attach_DarkhastFilms), new Action<DarkhastFilm>(this.detach_DarkhastFilms));
            this._Events = new EntitySet<Event>(new Action<Event>(this.attach_Events), new Action<Event>(this.detach_Events));
            this._FaaliatKarbarans = new EntitySet<FaaliatKarbaran>(new Action<FaaliatKarbaran>(this.attach_FaaliatKarbarans), new Action<FaaliatKarbaran>(this.detach_FaaliatKarbarans));
            this._UserType = default(EntityRef<UserType>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FirstName", DbType = "NVarChar(200)")]
        public string FirstName
        {
            get
            {
                return this._FirstName;
            }
            set
            {
                if ((this._FirstName != value))
                {
                    this.OnFirstNameChanging(value);
                    this.SendPropertyChanging();
                    this._FirstName = value;
                    this.SendPropertyChanged("FirstName");
                    this.OnFirstNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LastName", DbType = "NVarChar(200)")]
        public string LastName
        {
            get
            {
                return this._LastName;
            }
            set
            {
                if ((this._LastName != value))
                {
                    this.OnLastNameChanging(value);
                    this.SendPropertyChanging();
                    this._LastName = value;
                    this.SendPropertyChanged("LastName");
                    this.OnLastNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FullName", AutoSync = AutoSync.Always, DbType = "NVarChar(401)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string FullName
        {
            get
            {
                return this._FullName;
            }
            set
            {
                if ((this._FullName != value))
                {
                    this.OnFullNameChanging(value);
                    this.SendPropertyChanging();
                    this._FullName = value;
                    this.SendPropertyChanged("FullName");
                    this.OnFullNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Email", DbType = "NVarChar(500)")]
        public string Email
        {
            get
            {
                return this._Email;
            }
            set
            {
                if ((this._Email != value))
                {
                    this.OnEmailChanging(value);
                    this.SendPropertyChanging();
                    this._Email = value;
                    this.SendPropertyChanged("Email");
                    this.OnEmailChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Address", DbType = "NVarChar(500)")]
        public string Address
        {
            get
            {
                return this._Address;
            }
            set
            {
                if ((this._Address != value))
                {
                    this.OnAddressChanging(value);
                    this.SendPropertyChanging();
                    this._Address = value;
                    this.SendPropertyChanged("Address");
                    this.OnAddressChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Sex_isMan", DbType = "Bit")]
        public System.Nullable<bool> Sex_isMan
        {
            get
            {
                return this._Sex_isMan;
            }
            set
            {
                if ((this._Sex_isMan != value))
                {
                    this.OnSex_isManChanging(value);
                    this.SendPropertyChanging();
                    this._Sex_isMan = value;
                    this.SendPropertyChanged("Sex_isMan");
                    this.OnSex_isManChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserName", DbType = "NVarChar(500)")]
        public string UserName
        {
            get
            {
                return this._UserName;
            }
            set
            {
                if ((this._UserName != value))
                {
                    this.OnUserNameChanging(value);
                    this.SendPropertyChanging();
                    this._UserName = value;
                    this.SendPropertyChanged("UserName");
                    this.OnUserNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Password", DbType = "NVarChar(MAX)")]
        public string Password
        {
            get
            {
                return this._Password;
            }
            set
            {
                if ((this._Password != value))
                {
                    this.OnPasswordChanging(value);
                    this.SendPropertyChanging();
                    this._Password = value;
                    this.SendPropertyChanged("Password");
                    this.OnPasswordChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserTypeId", DbType = "Int")]
        public System.Nullable<int> UserTypeId
        {
            get
            {
                return this._UserTypeId;
            }
            set
            {
                if ((this._UserTypeId != value))
                {
                    if (this._UserType.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserTypeIdChanging(value);
                    this.SendPropertyChanging();
                    this._UserTypeId = value;
                    this.SendPropertyChanged("UserTypeId");
                    this.OnUserTypeIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Mobile", DbType = "NVarChar(50)")]
        public string Mobile
        {
            get
            {
                return this._Mobile;
            }
            set
            {
                if ((this._Mobile != value))
                {
                    this.OnMobileChanging(value);
                    this.SendPropertyChanging();
                    this._Mobile = value;
                    this.SendPropertyChanged("Mobile");
                    this.OnMobileChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Telephone", DbType = "NVarChar(50)")]
        public string Telephone
        {
            get
            {
                return this._Telephone;
            }
            set
            {
                if ((this._Telephone != value))
                {
                    this.OnTelephoneChanging(value);
                    this.SendPropertyChanging();
                    this._Telephone = value;
                    this.SendPropertyChanged("Telephone");
                    this.OnTelephoneChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsActive", DbType = "Bit NOT NULL")]
        public bool IsActive
        {
            get
            {
                return this._IsActive;
            }
            set
            {
                if ((this._IsActive != value))
                {
                    this.OnIsActiveChanging(value);
                    this.SendPropertyChanging();
                    this._IsActive = value;
                    this.SendPropertyChanged("IsActive");
                    this.OnIsActiveChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeSabtNam", DbType = "DateTime NOT NULL")]
        public System.DateTime DateTimeSabtNam
        {
            get
            {
                return this._DateTimeSabtNam;
            }
            set
            {
                if ((this._DateTimeSabtNam != value))
                {
                    this.OnDateTimeSabtNamChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeSabtNam = value;
                    this.SendPropertyChanged("DateTimeSabtNam");
                    this.OnDateTimeSabtNamChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsLogin", DbType = "Bit NOT NULL")]
        public bool IsLogin
        {
            get
            {
                return this._IsLogin;
            }
            set
            {
                if ((this._IsLogin != value))
                {
                    this.OnIsLoginChanging(value);
                    this.SendPropertyChanging();
                    this._IsLogin = value;
                    this.SendPropertyChanged("IsLogin");
                    this.OnIsLoginChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "_User_Comment", Storage = "_Comments", ThisKey = "UID", OtherKey = "UserId")]
        public EntitySet<Comment> Comments
        {
            get
            {
                return this._Comments;
            }
            set
            {
                this._Comments.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "_User_DarkhastFilm", Storage = "_DarkhastFilms", ThisKey = "UID", OtherKey = "UserId")]
        public EntitySet<DarkhastFilm> DarkhastFilms
        {
            get
            {
                return this._DarkhastFilms;
            }
            set
            {
                this._DarkhastFilms.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "_User_Event", Storage = "_Events", ThisKey = "UID", OtherKey = "UserID")]
        public EntitySet<Event> Events
        {
            get
            {
                return this._Events;
            }
            set
            {
                this._Events.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "_User_FaaliatKarbaran", Storage = "_FaaliatKarbarans", ThisKey = "UID", OtherKey = "UserId")]
        public EntitySet<FaaliatKarbaran> FaaliatKarbarans
        {
            get
            {
                return this._FaaliatKarbarans;
            }
            set
            {
                this._FaaliatKarbarans.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "UserType__User", Storage = "_UserType", ThisKey = "UserTypeId", OtherKey = "Id", IsForeignKey = true)]
        public UserType UserType
        {
            get
            {
                return this._UserType.Entity;
            }
            set
            {
                UserType previousValue = this._UserType.Entity;
                if (((previousValue != value)
                            || (this._UserType.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._UserType.Entity = null;
                        previousValue._Users.Remove(this);
                    }
                    this._UserType.Entity = value;
                    if ((value != null))
                    {
                        value._Users.Add(this);
                        this._UserTypeId = value.Id;
                    }
                    else
                    {
                        this._UserTypeId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("UserType");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_Comments(Comment entity)
        {
            this.SendPropertyChanging();
            entity._User = this;
        }

        private void detach_Comments(Comment entity)
        {
            this.SendPropertyChanging();
            entity._User = null;
        }

        private void attach_DarkhastFilms(DarkhastFilm entity)
        {
            this.SendPropertyChanging();
            entity._User = this;
        }

        private void detach_DarkhastFilms(DarkhastFilm entity)
        {
            this.SendPropertyChanging();
            entity._User = null;
        }

        private void attach_Events(Event entity)
        {
            this.SendPropertyChanging();
            entity._User = this;
        }

        private void detach_Events(Event entity)
        {
            this.SendPropertyChanging();
            entity._User = null;
        }

        private void attach_FaaliatKarbarans(FaaliatKarbaran entity)
        {
            this.SendPropertyChanging();
            entity._User = this;
        }

        private void detach_FaaliatKarbarans(FaaliatKarbaran entity)
        {
            this.SendPropertyChanging();
            entity._User = null;
        }
    }
}