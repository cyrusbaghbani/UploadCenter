﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utility;

/// <summary>
/// Summary description for ArssPayamHelp
/// </summary>
public static class ArssPayamHelp
{
    public static string GetNameOfDatebandiTitleImage(int? dastebandiIds)
    {
        if (dastebandiIds == (int)DastebandiTypeIds.FilmHayIrani_)
            return "Film_irani.png";
        if (dastebandiIds == (int)DastebandiTypeIds.FilmHayKhareji)
            return "FilmKhareji.png";
        if (dastebandiIds == (int)DastebandiTypeIds.Animation)
            return "Animation.png";
        if (dastebandiIds == (int)DastebandiTypeIds.SerialIrani)
            return "SerialIrani.png";
        if (dastebandiIds == (int)DastebandiTypeIds.SerialKhareji)
            return "SerialKhareji.png";
        if (dastebandiIds == (int)DastebandiTypeIds.Mazhabi)
            return "Mazhabi.png";
        if (dastebandiIds == (int)DastebandiTypeIds.Mostanad)
            return "Mostanad.png";
        if (dastebandiIds == (int)DastebandiTypeIds.ClipMoshghi)
            return "ClipMoshghi.png";
        if (dastebandiIds == (int)DastebandiTypeIds.Varzeshi)
            return "Varzeshi.png";
        if (dastebandiIds == (int)DastebandiTypeIds.Amozeshi)
            return "Amozeshi.png";
        if (dastebandiIds == (int)DastebandiTypeIds.Daghtarin)
            return "Daghtarinha.png";
        if (dastebandiIds == (int)DastebandiTypeIds.Jadidtarin)
            return "JadidTarinha.png";
        if (dastebandiIds == (int)DastebandiTypeIds.Sargarmi)
            return "Sargarmi.png";

        return "NatijeJostejo.png";
    }
    


    public static AnsJasonObject GetUserFromWebService(string UserName, string Password)
    {
        try
        {
            HamyarnetWebService.davoodkhorasani ws = new HamyarnetWebService.davoodkhorasani();
            Jasonobject json = new Jasonobject();
            json.Username = UserName;
            json.Password = Password;
            json.AdslTel = UserName;
            json.WUsername = "partakwsdl";
            json.WPassword = "rahapartak120";
            string jas = JsonConvert.SerializeObject(json);

            string str = ws.GetCustomerInfo(jas);
            var obj = JsonConvert.DeserializeObject<AnsJasonObject>(str);
            return obj;
        }
        catch
        {
            return (AnsJasonObject)null;
        }
    }


}