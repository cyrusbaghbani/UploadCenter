﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utility;

/// <summary>
/// Summary description for ArssPayamUtility
/// </summary>
public enum DastebandiTypeIds
{
    FilmHayIrani_ = 1,
    Animation = 2,
    FilmHayKhareji = 3,
    Daghtarin = 4,
    Jadidtarin = 5,
    SerialIrani = 6,
    SerialKhareji = 7,
    Mostanad = 8,
    Amozeshi = 9,
    ClipMoshghi = 10,
    Varzeshi = 11,
    Mazhabi = 12,
    Sargarmi = 13,
};

public enum UserTypeIds
{
    Modirsystem = 1,
    KarbarSystem = 2,
    MihmanHamyarnet = 3,
    MoshtarakHamyarnet = 4,

};
public enum FaaliatTypeIds
{
    Bazdid = 1,
    Download = 2,

};
public enum EventTypeIds
{
    VorodBeSystem = 1,
    KhorojAzSystem = 2,
    Darj = 3,
    Hazf = 4,
    virayesh = 5,
    SabtNazar = 6,

};

public enum CommentTypeIds
{
    comment = 1,
    agree = 2,
    disAgree = 3,


};



