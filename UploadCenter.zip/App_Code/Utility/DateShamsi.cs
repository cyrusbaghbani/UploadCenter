﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;
using System.Text.RegularExpressions;

/// <summary>
/// Summary description for DateShamsi
/// </summary>
/// 
namespace Utility
{

    public class DateShamsi
    {
        public DateShamsi()
        {
        }

        /// <summary>
        /// 
        /// اگر ماه و سال وارد شود تمام اول هفته های آن ماه را میدهد
        /// اگر سال وارد شود تمام اول هفته های آن سال را بر میگرداند
        ///
        /// </summary>

        /// <param name="Month">ماه </param>
        /// <param name="Year">سال</param>
        /// <returns></returns>
        public static List<string> GetListOfStartWeek(int? Month = null, int? Year = null)
        {
            List<string> date = new List<string>();
            if (Year == null || Year < 0)
                return date;


            if (Month == null)
            {
                string startDate = Year.ToString() + "/01/01";
                string StartDateweek = Utility.DateShamsi.GetStartDateOfWeek(startDate);
                while (StartDateweek.CompareTo((Year + 1).ToString() + "/01/01") < 0)
                {
                    if (StartDateweek.CompareTo((Year).ToString() + "/01/01") > 0)
                    {
                        date.Add(StartDateweek);
                    }
                    startDate = Utility.DateShamsi.AddDaysToShamsiDate(startDate, 0, 0, 7);
                    StartDateweek = Utility.DateShamsi.GetStartDateOfWeek(startDate);
                }
            }
            else
            {
                string thisMonth = "";
                string nextMonth = "";

                if (Month <= 0 || Month >= 13)
                {
                    thisMonth = "01";

                }
                else if (Month >= 1 && Month <= 9)
                {
                    thisMonth = "0" + Month.ToString();
                }
                else
                {
                    thisMonth = Month.ToString();
                }

                string startDate = Year.ToString() + "/" + thisMonth + "/01";
                Month += 1;
                int? nextyaer = Year;
                if (Month == null || Month <= 0 || Month >= 13)
                {
                    nextMonth = "01";
                    nextyaer++;
                }
                else if (Month >= 1 && Month <= 9)
                {
                    nextMonth = "0" + Month.ToString();
                }
                else
                {
                    nextMonth = Month.ToString();
                }

                string StartDateweek = Utility.DateShamsi.GetStartDateOfWeek(startDate);
                while (StartDateweek.CompareTo((nextyaer).ToString() + "/" + nextMonth + "/01") < 0)
                {
                    if (StartDateweek.CompareTo((Year).ToString() + "/" + thisMonth + "/01") >= 0)
                    {
                        date.Add(StartDateweek);
                    }
                    startDate = Utility.DateShamsi.AddDaysToShamsiDate(startDate, 0, 0, 7);
                    StartDateweek = Utility.DateShamsi.GetStartDateOfWeek(startDate);
                }
            }

            return date;
        }
        /// <summary>
        /// یک تاریخ گرفته و می گوید چه روزی از هفته می باشد
        /// (روز هفاته بر گردانده شده بر اساس DayOfWeek  میباشد)
        /// </summary>
        /// <param name="persianDate">تاریخ شمسی</param>
        /// <returns></returns>
        public static int GetDayOfWeek(string persianDate)
        {
            DateTime? dt = ConvertShamsiToMiladiDateTime(persianDate);
            if (dt == null)
                throw new Exception(" خطا در تبدیل تاریخ شمسی به میلادی");

            return (int)dt.Value.DayOfWeek;

        }
        /// <summary>
        /// اختلاف دو تاریخ شمسی بر حسب سال و ماه و روز
        /// حتما تاریخ بزگتر باید تاریخ پایان باشد
        /// می گوید حدودا چند سال ، چند ماه و چند روز با هم فصله دارند
        /// </summary>
        /// <param name="start">تاریخ شروع</param>
        /// <param name="end">تاریخ پایان</param>
        /// <returns></returns>
        public static string Ekhtelaf2TarikhShamsi(string start, string end)
        {
            int year = 0;
            int month = 0;
            int day = 0;
            int startYear = Convert.ToInt32(start.Substring(0, 4));
            int startMonth = Convert.ToInt32(start.Substring(5, 2));
            int startDay = Convert.ToInt32(start.Substring(8, 2));
            int endYear = Convert.ToInt32(end.Substring(0, 4));
            int endMonth = Convert.ToInt32(end.Substring(5, 2));
            int endDay = Convert.ToInt32(end.Substring(8, 2));
            System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();

            //محاسبه تفاضل دو تاریخ
            if (endDay >= startDay)
            {
                day = endDay - startDay + 1;

                if (endMonth >= startMonth)
                {
                    year = endYear - startYear;
                    month = endMonth - startMonth;
                }
                else
                {
                    year = endYear - startYear - 1;
                    month = (12 - startMonth) + endMonth;
                }
            }
            else
            {
                if (startMonth < 7)
                    day = (31 - startDay + 1) + endDay;
                else if (startMonth < 12)
                    day = (30 - startDay + 1) + endDay;
                else if (pc.IsLeapYear(startYear))
                    day = (30 - startDay + 1) + endDay;
                else
                    day = (29 - startDay + 1) + endDay;

                if (endMonth > startMonth)
                {
                    year = endYear - startYear;
                    month = endMonth - startMonth;
                }
                else
                {
                    year = endYear - startYear - 1;
                    month = (12 - startMonth) + endMonth - 1;
                }
            }

            return year.ToString() + ";" + month.ToString() + ";" + day.ToString();
        }
        /// <summary>
        /// تاریخ تولد به شمسی را گرفته و می گوید چند سال سن دارد
        /// </summary>
        /// <param name="birthDate">تاریخ تولد</param>
        /// <returns></returns>
        public static Nullable<int> CalculateAge(string birthDate)
        {
            try
            {
                int year = Convert.ToInt32(birthDate.Split('/')[0]);
                int mon = Convert.ToInt32(birthDate.Split('/')[1]);
                int day = Convert.ToInt32(birthDate.Split('/')[2]);
                System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();
                pc.ToDateTime(year, mon, day, 0, 0, 0, 0);
                // cache the current time
                DateTime now = DateTime.Today; // today is fine, don't need the timestamp from now
                // get the difference in years
                int years = now.Year - year;
                // subtract another year if we're before the
                // birth day in the current year
                if (now.Month < mon || (now.Month == mon && now.Day < day))
                    --years;
                return years;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// تاریخ شمسی را گرفته و چک م کند که آیا تاریخ درست است یا نه در صورت صحیح بودن تاریخ را با فرمت کامل(1300/01/01) بر می گرداند
        /// در غیر این صورت رشته خالی بر می گرداند
        /// </summary>
        /// <param name="date">تاریخ شمسی</param>
        /// <returns></returns>
        public static string GetShamsiDateString(string date)
        {
            //تاریخ شمسی را میگیرد و به صورت تاریخ با فرمت صحیح میدهد
            try
            {
                int year = Convert.ToInt32(date.Split('/')[0]);
                int mon = Convert.ToInt32(date.Split('/')[1]);
                int day = Convert.ToInt32(date.Split('/')[2]);

                if (year < 100)
                    year += 1300;
                System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();
                pc.ToDateTime(year, mon, day, 0, 0, 0, 0);
                return year.ToString("0000") + "/" + mon.ToString("00") + "/" + day.ToString("00");
            }
            catch
            {
                return string.Empty;
            }
        }
        /// <summary>
        /// تاریخ شمسی را گرفته و تاریخ میلادی آن را به صورت رشته بر می گرداند
        /// </summary>
        /// <param name="date">تاریخ شمسی</param>
        /// <returns></returns>
        public static string ConvertShamsiToMiladiStr(string date)
        {
            //تاریخ شمسی میگیرد و میلادی میدهد
            try
            {
                int year = Convert.ToInt32(date.Split('/')[0]);
                int mon = Convert.ToInt32(date.Split('/')[1]);
                int day = Convert.ToInt32(date.Split('/')[2]);

                System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();
                return pc.ToDateTime(year, mon, day, 0, 0, 0, 0).ToShortDateString();
            }
            catch
            {
                return "";
            }
        }
        /// <summary>
        /// تاریخ شمسی را گرفته و تاریخ میلادی را بر می گرداند
        /// </summary>
        /// <param name="persionDate">تاریخ شمسی</param>
        /// <returns></returns>
        public static DateTime? ConvertShamsiToMiladiDateTime(string persionDate)
        {

            if (persionDate != null && persionDate != string.Empty)
            {
                System.Globalization.PersianCalendar cal = new System.Globalization.PersianCalendar();
                string[] persion = persionDate.Split('/');
                DateTime miladiDate = new DateTime(int.Parse(persion[0]), int.Parse(persion[1]), int.Parse(persion[2]), cal);
                string s = miladiDate.ToShortDateString();
                return miladiDate;
            }
            return null;
        }
        /// <summary>
        /// تبدیل تاریخ شمسی به تاریخ میلادی
        /// </summary>
        /// <param name="date">تاریخ شمسی</param>
        /// <returns></returns>
        public static DateTime? GetMiladiDate(string date)
        {
            try
            {
                int year = Convert.ToInt32(date.Split('/')[0]);
                int mon = Convert.ToInt32(date.Split('/')[1]);
                int day = Convert.ToInt32(date.Split('/')[2]);

                System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();
                return pc.ToDateTime(year, mon, day, 0, 0, 0, 0);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// شماره ماه شمسی را گرفته و ماه را به صورت رشته ای برمیگرداند
        /// </summary>
        /// <param name="mon"></param>
        /// <returns></returns>
        public static string GetShamsiMonth(int mon)
        {
            string month = "";
            switch (mon)
            {
                case 1:
                    month = "فروردین";
                    break;
                case 2:
                    month = "اردیبهشت";
                    break;
                case 3:
                    month = "خرداد";
                    break;
                case 4:
                    month = "تیر";
                    break;
                case 5:
                    month = "مرداد";
                    break;
                case 6:
                    month = "شهریور";
                    break;
                case 7:
                    month = "مهر";
                    break;
                case 8:
                    month = "آبان";
                    break;
                case 9:
                    month = "آذر";
                    break;
                case 10:
                    month = "دی";
                    break;
                case 11:
                    month = "بهمن";
                    break;
                case 12:
                    month = "اسفند";
                    break;
            }
            return month;
        }

        /// <summary>
        /// روزای هفته فارسی را برمیگرداند
        /// </summary>
        /// <param name="day"></param>
        /// <returns></returns>
        public static string GetShamsiDayOfWeek(DayOfWeek day)
        {
            string Weekday = "";
            switch (day)
            {
                case DayOfWeek.Friday:
                    Weekday = "جمعه";
                    break;
                case DayOfWeek.Monday:
                    Weekday = "دوشنبه";
                    break;
                case DayOfWeek.Saturday:
                    Weekday = "شنبه";
                    break;
                case DayOfWeek.Sunday:
                    Weekday = "یک شنبه";
                    break;
                case DayOfWeek.Thursday:
                    Weekday = "پنج شنبه";
                    break;
                case DayOfWeek.Tuesday:
                    Weekday = "سه شنبه";
                    break;
                case DayOfWeek.Wednesday:
                    Weekday = "چهارشنبه";
                    break;
            }
            return Weekday;
        }

        /// <summary>
        /// تاریخ شمسی را میگیرد و مانند 1 فروردین 1390 برمیگرداند
        /// </summary>
        /// <param name="date"></param>
        /// <param name="TodayYesterday"></param>
        /// <returns></returns>
        public static string GetDayMonYearStr(string date, bool TodayYesterday = false, bool ShowDayOfWeek = true)
        {
            date = GetShamsiDateString(date); //برای اینکه اگر فرمتش صحیح نیست درست شود
            DateTime? Miladi = GetMiladiDate(date); //تبدیل به تاریخ میلادی
            System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();

            if (Miladi != null)
            {
                if (TodayYesterday)
                {
                    if (Miladi.Value.ToShortDateString() == System.DateTime.Now.ToShortDateString())
                        return "امروز";
                    else if (System.DateTime.Now.AddDays(-1).ToShortDateString() == Miladi.Value.ToShortDateString())
                        return "دیروز";
                }

                string month = "";
                string Weekday = "";

                Weekday = ShowDayOfWeek ? GetShamsiDayOfWeek(pc.GetDayOfWeek(Miladi.Value)) : "";
                month = GetShamsiMonth(pc.GetMonth(Miladi.Value));

                return Weekday + " " + date.Substring(8, 2) + " " + month + " " + date.Substring(0, 4);
            }
            else
                return "";
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        ///تاریخ یک روز در هفته را میگیرد و تاریخ ابتدای این هفته را میدهد
        ///پیش فرض ابتدای هفته جاری را برمیگرداند
        /// </summary>
        /// <returns></returns>
        public static string GetStartDateOfWeek(string AdateInWeek = "")
        {
            if (AdateInWeek == "")
                AdateInWeek = GetCurrentDate();

            DateTime? Mdate = GetMiladiDate(AdateInWeek);
            if (Mdate != null)
            {
                DayOfWeek weekDay = Mdate.Value.DayOfWeek;
                int diff = weekDay - DayOfWeek.Saturday;
                if (diff < 0)
                    diff += 7;

                return ConvertMiladiDateToPersionDate(Mdate.Value.AddDays((-1) * diff));
            }
            return string.Empty;

        }
        /// <summary>
        /// متدي جهت تبديل تاريخ ميلادي به تاريخ فارسي
        /// </summary>
        /// <param name="miladiDate">تاريخ ميلادي</param>
        /// <returns>تاريخ فارسي</returns>
        public static string ConvertMiladiDateToPersionDate(DateTime miladiDate)
        {
            if (miladiDate != null)
            {
                System.Globalization.PersianCalendar cal = new System.Globalization.PersianCalendar();
                string year = cal.GetYear(miladiDate).ToString("0000");
                string mounth = cal.GetMonth(miladiDate).ToString("00");
                string day = cal.GetDayOfMonth(miladiDate).ToString("00");
                return year + "/" + mounth + "/" + day;
            }
            return null;
        }
        /// <summary>
        /// تاریخ جاری را بر می گرداند
        /// </summary>
        /// <returns></returns>
        public static string GetCurrentDate()
        {
            System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();
            string year = pc.GetYear(DateTime.Now).ToString("0000");
            string month = pc.GetMonth(DateTime.Now).ToString("00");
            string day = pc.GetDayOfMonth(DateTime.Now).ToString("00");
            return year + "/" + month + "/" + day;
        }
        /// <summary>
        /// تاریخ جاری را با جدا کننده دلخواه کاربر بر می گرداند
        /// </summary>
        /// <param name="sep">رشته جدا کننده</param>
        /// <returns></returns>
        public static string GetCurrentDate(string sep)
        {
            System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();
            string year = pc.GetYear(DateTime.Now).ToString("0000");
            string month = pc.GetMonth(DateTime.Now).ToString("00");
            string day = pc.GetDayOfMonth(DateTime.Now).ToString("00");
            return year + sep + month + sep + day;
        }
        /// <summary>
        /// یک تاریخ میلادی را گرفته با جدا کننده و تاریخ همان روز را به شمسی با جدا کننده دلخواه بر می گرداند
        /// </summary>
        /// <param name="dt">تاریخ میلادی</param>
        /// <param name="seprator">جدا کننده</param>
        /// <returns></returns>
        public static string GetDate(DateTime dt, string seprator)
        {

            System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();
            string year = pc.GetYear(dt).ToString();
            string month = pc.GetMonth(dt) < 10 ? ("0" + pc.GetMonth(dt).ToString()) : pc.GetMonth(dt).ToString();
            string day = pc.GetDayOfMonth(dt) < 10 ? ("0" + pc.GetDayOfMonth(dt).ToString()) : pc.GetDayOfMonth(dt).ToString();
            return year + seprator + month + seprator + day;

        }
        /// <summary>
        /// زمان جاری را بر می گرداند (ثانیه:دقیقه:ساعت)
        /// </summary>
        /// <param name="seprator">جدا کننده زمان</param>
        /// <returns></returns>
        public static string GetCurrentHour(string seprator = ":")
        {

            System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();
            string hour = pc.GetHour(DateTime.Now).ToString("00");
            string min = pc.GetMinute(DateTime.Now).ToString("00");
            string sec = pc.GetSecond(DateTime.Now).ToString("00");
            return hour + seprator + min + seprator + sec;
        }
        /// <summary>
        /// یک تاریخ شمسی گرفته و به میزان مورد نظر تاریخ را به جلو یا عقب بر می گرداند مثلا 2 سال 4 ماه یک روز می توان تاریخ را به جلو برد
        /// </summary>
        /// <param name="date">تاریخ شمسی</param>
        /// <param name="year">سال</param>
        /// <param name="mon">ماه</param>
        /// <param name="day">روز</param>
        /// <returns></returns>
        public static string AddDaysToShamsiDate(string date, int year, int mon, int day)
        {
            //لازم نیست حتما تاریخ فرمتش به صورت 01/01/1389 باشد
            try
            {
                int _year = Convert.ToInt32(date.Split('/')[0]);
                int _mon = Convert.ToInt32(date.Split('/')[1]);
                int _day = Convert.ToInt32(date.Split('/')[2]);

                if (_year < 100)
                    _year += 1300;
                System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();
                DateTime MiladiDate = pc.ToDateTime(_year, _mon, _day, 0, 0, 0, 0);
                MiladiDate = MiladiDate.AddYears(year).AddMonths(mon).AddDays(day);
                string strYear = pc.GetYear(MiladiDate).ToString("0000");
                string strMon = pc.GetMonth(MiladiDate).ToString("00");
                string strDay = pc.GetDayOfMonth(MiladiDate).ToString("00");
                return strYear + "/" + strMon + "/" + strDay;
            }
            catch
            {
                return "";
            }
        }
        /// <summary>
        /// مشخص می کند که در این سال ماه وارد شده چند روز داشته است
        /// </summary>
        /// <param name="year">سال</param>
        /// <param name="month">ماه</param>
        /// <returns>تعداد روز در ماه </returns>
        public static int GetDay_EndOfMonth(int year, int month)
        {
            System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();

            if (month <= 6)
                return 31;
            else if (month <= 11)
                return 30;
            else if (pc.IsLeapYear(year))
                return 30;
            else
                return 29;

        }
        /// <summary>
        /// یک تاریخ گرفته و تاریخ شروع آن ماه را بر می گرداند
        /// </summary>
        /// <param name="date">تاریخ شمسی</param>
        /// <returns></returns>
        public static string GetStartOfMonth(string date)
        {

            try
            {
                string month = date.Split('/')[1];
                string year = date.Split('/')[0];
                string str = year + "/" + month + "/01";
                return DateShamsi.GetShamsiDateString(str);
            }
            catch
            {
                return "";
            }
        }
        /// <summary>
        /// یک تاریخ شمسی گرفته و تاریخ آخرین روز آن ماه را بر می گرداند
        /// </summary>
        /// <param name="date">تاریخ شمسی</param>
        /// <returns></returns>
        public static string GetEndOfMonth(string date)
        {
            try
            {
                string month = date.Split('/')[1];
                string year = date.Split('/')[0];
                string str = year + "/" + month + "/" + GetDay_EndOfMonth(int.Parse(year), int.Parse(month)).ToString();
                return DateShamsi.GetShamsiDateString(str);
            }
            catch
            {
                return "";
            }
        }
        /// <summary>
        /// ساعت ، دقیقه ، ثانیه را گرفته و در صورتی که داده های وارد شده ایرادی نداشته باشند فرمت کامل با جدا کننده ارسالی را بر می گرداند
        /// ساعت به فرمت 24 می باشد
        /// </summary>
        /// <param name="hour">ساعت</param>
        /// <param name="min">دقیقه</param>
        /// <param name="second">ثانیه</param>
        /// <param name="seprator">جدا کننده</param>
        /// <returns></returns>
        public static string GetTimeString(string hour, string min, string second, string seprator = ":")
        {
            int tmp = 0;
            if (
                (hour == null || hour.Trim() == "" || !int.TryParse("0" + hour.Trim(), out tmp))
                ||
                (min == null || min.Trim() == "" || !int.TryParse("0" + min.Trim(), out tmp))
                ||
                 (second == null || second.Trim() == "" || !int.TryParse("0" + second.Trim(), out tmp))
                )
                return "";

            int Ihour = int.Parse("0" + hour);
            int Imin = int.Parse("0" + min);
            int ISecond = int.Parse("0" + second);

            if (Ihour < 0 || Ihour >= 24 || Imin < 0 || Imin >= 60 || ISecond < 0 || ISecond >= 60)
                return "";

            return Ihour.ToString("00") + seprator + Imin.ToString("00") + seprator + ISecond.ToString("00");

        }
        /// <summary>
        /// فاصله زمانی بین دو زمان را بر می گرداند
        /// به صورت دقیقه:ساعت
        /// </summary>
        /// <param name="BeginTime">زمان شروع</param>
        /// <param name="EndTime">زمان پایان</param>
        /// <returns></returns>
        public static string GetDurationBetWeen2Time(string BeginTime, string EndTime)
        {

            if (BeginTime == null || BeginTime.Trim() == "" || EndTime == null || EndTime.Trim() == "")
                return "";

            TimeSpan tStart = new TimeSpan(int.Parse(BeginTime.ToString().Split(':')[0]), int.Parse(BeginTime.ToString().Split(':')[1]), 0);
            TimeSpan tEnd = new TimeSpan(int.Parse(EndTime.ToString().Split(':')[0]), int.Parse(EndTime.ToString().Split(':')[1]), 0);

            if (tEnd >= tStart)
            {
                TimeSpan TSub = tEnd.Subtract(tStart);

                return TSub.Hours.ToString("00") + ":" + TSub.Minutes.ToString("00");
            }
            TimeSpan TSub2 = (tEnd.Subtract(new TimeSpan(0, 0, 0)) + (new TimeSpan(24, 0, 0).Subtract(tStart)));
            return TSub2.Hours.ToString("00") + ":" + TSub2.Minutes.ToString("00");
        }
        /// <summary>
        /// این تابع یک سال را گرفته و تاریخ شروع هفته، اخرین هفته های هر ماه از آن سال را بر می گرداند
        /// </summary>
        /// <param name="year">سال</param>
        /// <returns></returns>
        public static List<string> GetStartLastDateWeekOfMonth(int? year)
        {
            List<string> last = new List<string>();
            List<string> tmp = new List<string>();
            tmp = DateShamsi.GetListOfStartWeek(null, year);

            last.Add(tmp.Where(p => p.Contains(year.ToString() + "/01")).OrderByDescending(p => p).FirstOrDefault());
            last.Add(tmp.Where(p => p.Contains(year.ToString() + "/02")).OrderByDescending(p => p).FirstOrDefault());
            last.Add(tmp.Where(p => p.Contains(year.ToString() + "/03")).OrderByDescending(p => p).FirstOrDefault());
            last.Add(tmp.Where(p => p.Contains(year.ToString() + "/04")).OrderByDescending(p => p).FirstOrDefault());
            last.Add(tmp.Where(p => p.Contains(year.ToString() + "/05")).OrderByDescending(p => p).FirstOrDefault());
            last.Add(tmp.Where(p => p.Contains(year.ToString() + "/06")).OrderByDescending(p => p).FirstOrDefault());
            last.Add(tmp.Where(p => p.Contains(year.ToString() + "/07")).OrderByDescending(p => p).FirstOrDefault());
            last.Add(tmp.Where(p => p.Contains(year.ToString() + "/08")).OrderByDescending(p => p).FirstOrDefault());
            last.Add(tmp.Where(p => p.Contains(year.ToString() + "/09")).OrderByDescending(p => p).FirstOrDefault());
            last.Add(tmp.Where(p => p.Contains(year.ToString() + "/10")).OrderByDescending(p => p).FirstOrDefault());
            last.Add(tmp.Where(p => p.Contains(year.ToString() + "/11")).OrderByDescending(p => p).FirstOrDefault());
            last.Add(tmp.Where(p => p.Contains(year.ToString() + "/12")).OrderByDescending(p => p).FirstOrDefault());

            return last.OrderBy(p => p).ToList();


        }
        /// <summary>
        /// فاصله تاریخ اول از تاریخ دوم کمتر مساوی از یک مقدار خاصی است
        /// مقدار خاص به صورت روز ماه سال وارد شده است به طور مثال  نشان می دهد که فاصله زمانی تاریخ اول از تاریخ دوم از یکسال کمتر است  
        /// </summary>
        /// <param name="firstdate">تاریخ اول</param>
        /// <param name="seconddate">تاریخ دوم</param>
        /// <param name="year">سال</param>
        /// <param name="mon">ماه </param>
        /// <param name="day">روز</param>
        /// <returns></returns>
        public static bool IsFaseleZamaniKamtarAz(string firstdate, string seconddate, int year, int mon, int day)
        {
            string firstDate = DateShamsi.GetShamsiDateString(firstdate);
            string secendDate = DateShamsi.GetShamsiDateString(seconddate);

            if (secendDate == "" || firstDate == "")
                return false;

            string date = DateShamsi.AddDaysToShamsiDate(secendDate, year, mon, day);
            if (date.CompareTo(firstDate) >= 0)
                return true;
            return false;
        }
        /// <summary>
        /// فاصله تاریخ اول از تاریخ دوم بیشتر مساوی از یک مقدار خاصی است
        /// مقدار خاص به صورت روز ماه سال وارد شده است به طور مثال  نشان می دهد که فاصله زمانی تاریخ اول از تاریخ دوم از یکسال بیشتر است  
        /// </summary>
        /// <param name="firstdate">تاریخ اول</param>
        /// <param name="seconddate">تاریخ دوم</param>
        /// <param name="year">سال</param>
        /// <param name="mon">ماه </param>
        /// <param name="day">روز</param>
        /// <returns></returns>
        public static bool IsFaseleZamaniBishtarAz(string firstdate, string seconddate, int year, int mon, int day)
        {
            string firstDate = DateShamsi.GetShamsiDateString(firstdate);
            string secendDate = DateShamsi.GetShamsiDateString(seconddate);

            if (secendDate == "" || firstDate == "")
                return false;

            string date = DateShamsi.AddDaysToShamsiDate(secendDate, year, mon, day);
            if (firstDate.CompareTo(date) >= 0)
                return true;
            return false;
        }

    }
}