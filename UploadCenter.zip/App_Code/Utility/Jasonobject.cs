﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Utility
{
    public class Jasonobject
    {
        public string Username = "";
        public string Password = "";
        public string WUsername = "partakwsdl";
        public string WPassword = "rahapartak120";
        public string AdslTel = "";
    }

    public class AnsJasonObject
    {
        public string code = "";
        public Customer customer = null;
        public string message = "";
    };

    public class Customer
    {
        public string name = "";
        public string tel = "";
        public string servicename = "";
        public string servicereservename = "";
        public string credit = "";
        public string deposit = "";
        public string exp_date = "";
        public string online = "";
        public string @lock = "";
    };
}
