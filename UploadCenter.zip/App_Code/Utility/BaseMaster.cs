﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DataAccsess;
using Utility;
using Newtonsoft.Json;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Drawing;
using System.Web.UI;

using System.Data;
using System.Web.Caching;
using System.Threading;

/// <summary>
/// Summary description for BaseMaster
/// </summary>
public class BaseMaster : System.Web.UI.MasterPage
{
    public _User CurrentUser
    {
        get
        {
            return Session["userhamyartv"] == null ? null : (_User)Session["userhamyartv"];
        }
    }
    protected override void OnInit(EventArgs e)
    {
        if (CurrentUser == null || (CurrentUser.UserTypeId != (int)UserTypeIds.KarbarSystem && CurrentUser.IsActive && CurrentUser.UserTypeId != (int)UserTypeIds.Modirsystem))
            Response.Redirect("~/login.aspx");
        base.OnInit(e);
    }
    #region Message
    private  Control FindMsgBoxControl()
    {
        Control uc = this.FindControl("ucmodeldialog");

        if (uc == null)
        {
            MasterPage mstr = this.Master;
            while (mstr != null)
            {
                uc = (Control)mstr.FindControl("ucmodeldialog");
                if (uc == null)
                    mstr = mstr.Master;
                else
                    break;
            }
        }
        return uc;

    }
    public void ShowSeccessMessage(string msg)
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[1];
        Type[0] = typeof(string);
        MethodInfo method = uc.GetType().GetMethod("ShowSeccessMessage", Type.ToArray());

        object[] prms = new object[1];
        prms[0] = msg;
        method.Invoke(uc, prms);
    }
    public void ShowErrorMessage(string msg)
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[1];
        Type[0] = typeof(string);
        MethodInfo method = uc.GetType().GetMethod("ShowErrorMessage", Type.ToArray());

        object[] prms = new object[1];
        prms[0] = msg;
        method.Invoke(uc, prms);
    }
    public void ShowInfoMessage(string msg)
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[1];
        Type[0] = typeof(string);
        MethodInfo method = uc.GetType().GetMethod("ShowInfoMessage", Type.ToArray());

        object[] prms = new object[1];
        prms[0] = msg;
        method.Invoke(uc, prms);
    }
    public string GetEmailFromForgatPassword()
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[0];
       
        MethodInfo method = uc.GetType().GetMethod("GetEmailFromForgatPassword", Type.ToArray());

        object[] prms = new object[0];
        
        
        return ((string)method.Invoke(uc, prms)).Trim();
    }
    public string GetTextArea()
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[0];

        MethodInfo method = uc.GetType().GetMethod("GetTextArea", Type.ToArray());

        object[] prms = new object[0];


        return ((string)method.Invoke(uc, prms)).Trim();
    }

    public string GET_Hajm_EDITLINK()
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[0];

        MethodInfo method = uc.GetType().GetMethod("GET_Hajm_EDITLINK", Type.ToArray());

        object[] prms = new object[0];


        return ((string)method.Invoke(uc, prms)).Trim();
    }
    public string GET_Priority_EDITLINK()
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[0];

        MethodInfo method = uc.GetType().GetMethod("GET_Priority_EDITLINK", Type.ToArray());

        object[] prms = new object[0];


        return ((string)method.Invoke(uc, prms)).Trim();
    }
    public string GET_AdressLink_EDITLINK()
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[0];

        MethodInfo method = uc.GetType().GetMethod("GET_AdressLink_EDITLINK", Type.ToArray());

        object[] prms = new object[0];


        return ((string)method.Invoke(uc, prms)).Trim();
    }
    public string GET_Onvan_EDITLINK()
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[0];

        MethodInfo method = uc.GetType().GetMethod("GET_Onvan_EDITLINK", Type.ToArray());

        object[] prms = new object[0];


        return ((string)method.Invoke(uc, prms)).Trim();
    }
    public string GET_QualityID_EDITLINK()
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[0];

        MethodInfo method = uc.GetType().GetMethod("GET_QualityID_EDITLINK", Type.ToArray());

        object[] prms = new object[0];


        return ((string)method.Invoke(uc, prms)).Trim();
    }
    public bool GET_NAmayeshDarVidio_EDITLINK()
    {
        Control uc = FindMsgBoxControl();
        var Type = new Type[0];

        MethodInfo method = uc.GetType().GetMethod("GET_NAmayeshDarVidio_EDITLINK", Type.ToArray());

        object[] prms = new object[0];


        return ((bool)method.Invoke(uc, prms));
    }
    #endregion



}