﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utility;

/// <summary>
/// Summary description for ArssPayamUtility
/// </summary>
public class ArssPayamUtility
{
    /// <summary>
    /// پیدا کردن پارامتر و برگرداندن مقدار آن
    /// </summary>
    /// <param name="key">پارامتر</param>
    /// <param name="argsQueryString">کوری فرستاده شده</param>
    /// <returns></returns>
    public static string GetQueryString(string key, string argsQueryString)
    {

        Dictionary<string, string> result = new Dictionary<string, string>();
        Utility.EncryptedQueryString args = new Utility.EncryptedQueryString(argsQueryString);
        if (args.Keys.Contains(key))
            return HttpUtility.HtmlEncode(args[key]).ToLower();

        return null;
    }
    /// <summary>
    /// کد کردن اطلاعات ادرس بار
    /// </summary>
    /// <param name="Address">آدرس</param>
    /// <param name="QueryString">پارامترها</param>
    /// <returns></returns>
    public static string GetEncodedQueryString(string Address, string QueryString)
    {
        EncryptedQueryString args = new EncryptedQueryString();
        foreach (string KeyVal in QueryString.Split('&'))
        {
            string[] s = KeyVal.Split('=');
            args[s[0]] = s[1];
        }

        return string.Format(Address, args.ToString());
    }



    public static string[] AllowedFileMimeType()
    {
        //string[] str = { ".pdf", ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx", ".txt", ".zip", ".rar", ".jpg", ".jpeg", ".png" };

        string[] str = { "application/pdf", "application/msword ", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "text/plain",/*startZip*/ "application/zip", "application/x-zip-compressed"/*End Zip*/,/*start rar*/ "application/octet-stream", "application/x-rar-compressed"/*End rar*/, "image/jpeg", "image/pjpeg", "image/png", "image/x-png" };
        return str;
    }
    public static string[] AllowedPictureMimeType()
    {
        //string[] str = { ".jpg", ".jpeg", ".png" };
        string[] str = { "image/jpeg", "image/pjpeg", "image/png" };

        return str;
    }
}



