﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Web;
using DataAccsess;
namespace Utility
{
    public class EventLoger
    {


        public static void LogEvent(string dsc, int eventTypeId, Guid userid)
        {
            try
            {
                dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
                Event log = new Event();
                log.UID = Guid.NewGuid();
                log.Dsc = dsc;
                log.EventTypeId = eventTypeId;
                log.IP = GetLocalIPAddress();
                log.UserID = userid;
                log.Date = DateShamsi.GetCurrentDate();
                log.Time = DateShamsi.GetCurrentHour(":");
                log.En_DateTime = DateTime.Now;

                dc.Events.InsertOnSubmit(log);
                dc.SubmitChanges();
            }
            catch
            {
            }
        }

        public static string GetLocalIPAddress()
        {
            try
            {
                string IPAddress = string.Empty;
                System.Net.IPHostEntry host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());

                foreach (System.Net.IPAddress ip in host.AddressList)
                {
                    if (ip.AddressFamily.ToString() == "InterNetwork")
                    {
                        IPAddress = ip.ToString();
                    }
                }
                return IPAddress;
            }
            catch
            {
                return "";
            }
        }

    }



}