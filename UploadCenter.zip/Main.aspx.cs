﻿using DataAccsess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



public partial class Main : System.Web.UI.Page
{
    string Filter = "/Site/Images/Master/Filter.png";
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            SetUrlOfButton();
        }
        SetScriptForFlipFlop();

        LoadHotest();
        LoadNewest();

        BindVideoStrip((int)DastebandiTypeIds.FilmHayKhareji
                        , (int)DastebandiTypeIds.Animation
                        , (int)DastebandiTypeIds.FilmHayIrani_);

    }

    /// <summary>
    /// دکمه های داغترین و جدید ترین را آدرس دهی میکند
    /// </summary>
    private void SetUrlOfButton()
    {
        btn_more_Hotest.PostBackUrl = ArssPayamUtility.GetEncodedQueryString("Site/Pages/ListShow.aspx?args={0}", "mode=" + (int)DastebandiTypeIds.Daghtarin);
        btn_more_Newst.PostBackUrl = ArssPayamUtility.GetEncodedQueryString("Site/Pages/ListShow.aspx?args={0}", "mode=" + (int)DastebandiTypeIds.Jadidtarin);
    }

    /// <summary>
    /// اسکریپت مربوط به فلیپ فلاپ شدن را قرارمیدهد، در صورتی که بروزر اینترنت اکسپلورر 9 به پایین باشد از کدی استفاده می شود که 
    /// نمی تواند چرخش را کامل انجام دهد
    /// </summary>
    private void SetScriptForFlipFlop()
    {
        litflipflopScript.Text = "";
        if (IsBrowserIEVersoinLower9())
        {

            litflipflopScript.Text += "    <script type=\"text/javascript\">  "
                + " $(function () { "
                // for performance first init the quickFlip
                + " $('.quickFlip').quickFlip(); "

                //// set up a hover effect for each of the quickflip wrappers
                //for (var i = 0; i < $.quickFlip.wrappers.length; i++) {
                //    var thisOne = $.quickFlip.wrappers[i];
                //    $(thisOne.wrapper).hover(function (ev) {
                //        var $target = $(ev.target);
                //        // make sure it isn't a child node
                //        if (!$target.hasClass('quickFlip')) $target = $target.parent();

                //        $target.quickFlipper();

                //    }, function () { });
                //}

            /*
                Although the code here is faster, it could be made a lot simpler, since $.quickFlipper() will attach the quickFlip if it doesn't exist.  Replace the above with:
             */
                + "   $('.quickFlip').hover(function (ev) { "
                + "      var $target = $(ev.target);  "
                + "        if ($target.hasClass('FILTERFLIPFLOPTEMpCLASS_JASTISNAME')) { "
                + "             $target = $target.parent(); "
                + "        } "
                + "     if (!$target.hasClass('quickFlip')) $target = $target.parent(); "
                + "     $target.quickFlipper(); "
                + "  }, function () { }); "

                + "   }); "
                + "  </script> ";
        }
        else
        {
            litflipflopScript.Text += "    <script type=\"text/javascript\"> "
                                   + " $(function () { "
                                   + "   $(\".quickFlip\").flip({ "
                                   + "    trigger: \"hover\" "
                                   + "     }); "
                                   + " }); "
                                   + " </script> ";
        }
    }
    /// <summary>
    /// بررسی میکند که ورژن بروزر استفاده شده است اینترنت اکسپلرور کمتر از از 9 است یانه
    /// زیرا زیر این ورزن بعضی از کدها جواب داده نمی شود
    /// </summary>
    /// <returns></returns>
    bool IsBrowserIEVersoinLower9()
    {

        if (Request.Browser.Type.ToUpper().Contains("IE")) // replace with your check
        {
            if (Request.Browser.MajorVersion < 9)
            {
                return true;
            }
        }
        return false;
    }
    /// <summary>
    /// بارگزاری داغترین ها
    /// </summary>
    private void LoadHotest()
    {
        List<Media> tt = Loaditem((int)DastebandiTypeIds.Daghtarin).Take(9).ToList();
        int counter = 0;
        Div_Slide_Hotest_Conttainer.InnerHtml = "";
        for (int i = 0; i < 3; i++)///Slide
        {
            if (counter >= tt.Count)
                break;
            Div_Slide_Hotest_Conttainer.InnerHtml += " <div class=\"slide\"> ";
            for (int j = 0; j < 3; j++)///Item in slide
            {
                if (counter >= tt.Count)
                    break;
                string Address = ArssPayamUtility.GetEncodedQueryString("Site/Pages/ShowTime.aspx?args={0}", "ID=" + tt[counter].UID + "&TEMP__=" + Guid.NewGuid());
                Div_Slide_Hotest_Conttainer.InnerHtml += " <div class=\"Div-Panel-Item\"> ";
                Div_Slide_Hotest_Conttainer.InnerHtml += " <a href=\"" + Address + "\"> ";
                Div_Slide_Hotest_Conttainer.InnerHtml += " <div class=\"quickFlip\"> ";

                Div_Slide_Hotest_Conttainer.InnerHtml += " <div class=\"panel1 front\" style=\"background-image: url('"
                    + ArssPayamUtility.GetEncodedQueryString("Site/Pages/ShowImage.aspx?args={0}", "URL="
                    + (tt[counter].UrlAxJeloCard == null ? "" : tt[counter].UrlAxJeloCard)
                    + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image")
                    + "'); \"> ";
                Div_Slide_Hotest_Conttainer.InnerHtml += "   &nbsp; ";
                Div_Slide_Hotest_Conttainer.InnerHtml += " </div> ";

                Div_Slide_Hotest_Conttainer.InnerHtml += " <div class=\"panel2 back\" style=\"background-image: url('"
                    + ArssPayamUtility.GetEncodedQueryString("Site/Pages/ShowImage.aspx?args={0}", "URL="
                    + (tt[counter].UrlAxPoshtCard == null ? "" : tt[counter].UrlAxPoshtCard)
                    + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image")
                    + "'); \"> ";
                if (tt[counter].IsUseFilterForPoshtJesld)
                    Div_Slide_Hotest_Conttainer.InnerHtml += "<div class=\"FILTERFLIPFLOPTEMpCLASS_JASTISNAME\" style=\"background-image: url('" + Filter + "');width:100%;height:100% \" >";
                Div_Slide_Hotest_Conttainer.InnerHtml += " &nbsp; " + (tt[counter].Dsc_PoshtCard == null ? "" : tt[counter].Dsc_PoshtCard.Replace("\n", "</br>"));
                if (tt[counter].IsUseFilterForPoshtJesld)
                    Div_Slide_Hotest_Conttainer.InnerHtml += " </div> ";
                Div_Slide_Hotest_Conttainer.InnerHtml += " </div> ";

                Div_Slide_Hotest_Conttainer.InnerHtml += " </div> ";
                Div_Slide_Hotest_Conttainer.InnerHtml += " <div class=\"BreakDiv1\"></div> ";
                Div_Slide_Hotest_Conttainer.InnerHtml += " <div class=\"Div_Panel_Item_Label\">";
                Div_Slide_Hotest_Conttainer.InnerHtml += tt[counter].Name;
                Div_Slide_Hotest_Conttainer.InnerHtml += " </div> ";
                Div_Slide_Hotest_Conttainer.InnerHtml += " </a> ";
                Div_Slide_Hotest_Conttainer.InnerHtml += " </div> ";
                counter++;
            }
            Div_Slide_Hotest_Conttainer.InnerHtml += " </div> ";
        }
    }
    /// <summary>
    /// بارگزار جدیدترین
    /// </summary>
    private void LoadNewest()
    {
        List<Media> tt = Loaditem((int)DastebandiTypeIds.Jadidtarin).Take(9).ToList();
        int counter = 0;
        Div_Slide_Newst_Conttainer.InnerHtml = "";
        for (int i = 0; i < 3; i++)///Slide
        {
            if (counter >= tt.Count)
                break;
            Div_Slide_Newst_Conttainer.InnerHtml += " <div class=\"slide\"> ";
            for (int j = 0; j < 3; j++)///Item in slide
            {
                if (counter >= tt.Count)
                    break;

                string Address = ArssPayamUtility.GetEncodedQueryString("Site/Pages/ShowTime.aspx?args={0}", "ID=" + tt[counter].UID + "&TEMP__=" + Guid.NewGuid());

                Div_Slide_Newst_Conttainer.InnerHtml += " <div class=\"Div-Panel-Item\"> ";
                Div_Slide_Newst_Conttainer.InnerHtml += " <a href=\"" + Address + "\"> ";
                Div_Slide_Newst_Conttainer.InnerHtml += " <div class=\"quickFlip\"> ";
                Div_Slide_Newst_Conttainer.InnerHtml += " <div class=\"panel1 front\" style=\"background-image: url('"
                    + ArssPayamUtility.GetEncodedQueryString("Site/Pages/ShowImage.aspx?args={0}", "URL="
                    + (tt[counter].UrlAxJeloCard == null ? "" : tt[counter].UrlAxJeloCard)
                    + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image")
                    + "'); \"> ";
                Div_Slide_Newst_Conttainer.InnerHtml += "   &nbsp; ";
                Div_Slide_Newst_Conttainer.InnerHtml += " </div> ";

                Div_Slide_Newst_Conttainer.InnerHtml += " <div class=\"panel2 back\"style=\"background-image: url('"
                    + ArssPayamUtility.GetEncodedQueryString("Site/Pages/ShowImage.aspx?args={0}", "URL="
                    + (tt[counter].UrlAxPoshtCard == null ? "" : tt[counter].UrlAxPoshtCard)
                    + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image")
                    + "'); \"> ";
                if (tt[counter].IsUseFilterForPoshtJesld)
                    Div_Slide_Newst_Conttainer.InnerHtml += " <div class=\"FILTERFLIPFLOPTEMpCLASS_JASTISNAME\"  style=\"background-image: url('" + Filter + "'); width: 170px; height:250px;\" > ";
                Div_Slide_Newst_Conttainer.InnerHtml += " &nbsp; " + (tt[counter].Dsc_PoshtCard == null ? "" : tt[counter].Dsc_PoshtCard.Replace("\n", "</br>"));
                if (tt[counter].IsUseFilterForPoshtJesld)
                    Div_Slide_Newst_Conttainer.InnerHtml += " </div> ";
                Div_Slide_Newst_Conttainer.InnerHtml += " </div> ";

                Div_Slide_Newst_Conttainer.InnerHtml += " </div> ";
                Div_Slide_Newst_Conttainer.InnerHtml += " <div class=\"BreakDiv1\"></div> ";
                Div_Slide_Newst_Conttainer.InnerHtml += " <div class=\"Div_Panel_Item_Label\">";
                Div_Slide_Newst_Conttainer.InnerHtml += tt[counter].Name;
                Div_Slide_Newst_Conttainer.InnerHtml += " </div> ";
                Div_Slide_Newst_Conttainer.InnerHtml += " </a> ";
                Div_Slide_Newst_Conttainer.InnerHtml += " </div> ";
                counter++;
            }
            Div_Slide_Newst_Conttainer.InnerHtml += " </div> ";
        }
    }


    private void BindVideoStrip(params int[] lstDastebanditypeid)
    {
        DIV_VideoStrip.InnerHtml = "  ";
        if (!lstDastebanditypeid.Any())
            return;
        foreach (var dastebanditypeid in lstDastebanditypeid)
        {
            LoadVideoStrip(dastebanditypeid);
        }


        DIV_VideoStrip.InnerHtml += " <script src=\"Site/slide4/jquery.bxslider.min.js\"></script> ";
        DIV_VideoStrip.InnerHtml += " <link href=\"Site/slide4/jquery.bxslider.css\" rel=\"stylesheet\" /> ";
        DIV_VideoStrip.InnerHtml += "<script language=\"javascript\" type=\"text/javascript\">";
        foreach (var dastebanditypeid in lstDastebanditypeid)
        {
            DIV_VideoStrip.InnerHtml += " var VideoStrip_" + dastebanditypeid + " ; ";
        }
        DIV_VideoStrip.InnerHtml += "$(document).ready(function () {";
        foreach (var dastebanditypeid in lstDastebanditypeid)
        {
            DIV_VideoStrip.InnerHtml += "      VideoStrip_" + dastebanditypeid + " = $('.FilmStrip_" + dastebanditypeid + "').bxSlider({ ";
            DIV_VideoStrip.InnerHtml += "      slideWidth: 230, ";
            DIV_VideoStrip.InnerHtml += "      minSlides: 1, ";
            DIV_VideoStrip.InnerHtml += "      maxSlides: 5, ";
            DIV_VideoStrip.InnerHtml += "      moveSlides: 1, ";
            DIV_VideoStrip.InnerHtml += "      auto: true, ";
            DIV_VideoStrip.InnerHtml += "      autoStart: true, ";
            DIV_VideoStrip.InnerHtml += "      autoHover: true, ";
            DIV_VideoStrip.InnerHtml += "      pause: 5000, ";
            DIV_VideoStrip.InnerHtml += "      randomStart: false, ";
            DIV_VideoStrip.InnerHtml += "      autoControls: false, ";
            DIV_VideoStrip.InnerHtml += "      autoControlsCombine: false, ";
            DIV_VideoStrip.InnerHtml += "      onSlideNext: function () { VideoStrip_" + dastebanditypeid + ".startAuto(); }, ";
            DIV_VideoStrip.InnerHtml += "      onSlidePrev: function () { VideoStrip_" + dastebanditypeid + ".startAuto(); }, ";
            DIV_VideoStrip.InnerHtml += "      onSlideBefore: function () { VideoStrip_" + dastebanditypeid + ".startAuto(); }, ";
            DIV_VideoStrip.InnerHtml += "      onSlideAfter: function () { VideoStrip_" + dastebanditypeid + ".startAuto(); }, ";
            DIV_VideoStrip.InnerHtml += "      slideMargin: 7, ";
            DIV_VideoStrip.InnerHtml += "      pager: false ";
            DIV_VideoStrip.InnerHtml += "  }); ";
        }
        DIV_VideoStrip.InnerHtml += " }); ";
        DIV_VideoStrip.InnerHtml += " </script> ";

    }
    private void LoadVideoStrip(int dastebanditypeid)
    {
        List<Media> tt = Loaditem(dastebanditypeid).OrderBy(s => s.Priority).ToList();
        if (!tt.Any())
            return;

        string ListShowItem = ArssPayamUtility.GetEncodedQueryString("Site/Pages/ListShow.aspx?args={0}", "mode=" + dastebanditypeid);
        DIV_VideoStrip.InnerHtml += "    <div class=\"BreakDiv1\" style=\"height: 10px\"></div> ";
        DIV_VideoStrip.InnerHtml += "  <div style=\"float: right; width: 155px; height: 30px; padding-right: 10px\"> ";
        DIV_VideoStrip.InnerHtml += " <a href=\"" + ListShowItem + "\"> ";
        DIV_VideoStrip.InnerHtml += " <img src=\"" + GetImageDastebandi(dastebanditypeid) + "\" /> ";
        DIV_VideoStrip.InnerHtml += " </a>";
        DIV_VideoStrip.InnerHtml += "  </div> ";
        DIV_VideoStrip.InnerHtml += "  <div style=\"float: left; width: 100px; height: 30px; padding-left: 20px\"> ";
        DIV_VideoStrip.InnerHtml += " <a href=\"" + ListShowItem + "\"> " + " <a href=\"" + ListShowItem + "\"> ";
        DIV_VideoStrip.InnerHtml += " <img src=\"" + "Site/Images/text_control/Bishtar.png" + "\" /> ";
        DIV_VideoStrip.InnerHtml += " </a>";
        DIV_VideoStrip.InnerHtml += "  </div> ";
        DIV_VideoStrip.InnerHtml += "  <div class=\"BreakDiv1\" style=\"height: 3px\"></div> ";
        DIV_VideoStrip.InnerHtml += "  <div id=\"FilmStrip_" + dastebanditypeid + "\" class=\"FilmStrip_" + dastebanditypeid + "\" > ";

        foreach (var video in tt)///Slide
        {
            string Address = ArssPayamUtility.GetEncodedQueryString("Site/Pages/ShowTime.aspx?args={0}", "ID=" + video.UID + "&TEMP__=" + Guid.NewGuid());
            DIV_VideoStrip.InnerHtml += " <div class=\"slidebxlider\"> ";

            DIV_VideoStrip.InnerHtml += " <div class=\"Div_Panel_230_150\"> ";
            DIV_VideoStrip.InnerHtml += " <a href=\"" + Address + "\"> ";
            DIV_VideoStrip.InnerHtml += " <div class=\"Div_Panel_Item_230_120\"> ";
            DIV_VideoStrip.InnerHtml += " <div id=\"dimg_" + video.UID.ToString().Replace("-", "_") + "\" class=\"Div_Panel_230_150_Item_Image\"> ";
            DIV_VideoStrip.InnerHtml += " <img src=\"" +
                ArssPayamUtility.GetEncodedQueryString("Site/Pages/ShowImage.aspx?args={0}", "URL="
                + (video.UrlAxVideoStrip == null ? "" : video.UrlAxVideoStrip)
                + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image&useslidebar=true")
                + "\" /> ";
            DIV_VideoStrip.InnerHtml += " </div> ";

            DIV_VideoStrip.InnerHtml += " </div> ";
            DIV_VideoStrip.InnerHtml += " <div class=\"BreakDiv1\"></div> ";
            DIV_VideoStrip.InnerHtml += " <div class=\"Div_Panel_230_150_Item_text\">";
            DIV_VideoStrip.InnerHtml += video.Name;

            DIV_VideoStrip.InnerHtml += " </div> ";
            DIV_VideoStrip.InnerHtml += " </a> ";
            DIV_VideoStrip.InnerHtml += " </div> ";
            DIV_VideoStrip.InnerHtml += " </div> ";
        }
        DIV_VideoStrip.InnerHtml += "  </div> ";
    }
    private List<Media> Loaditem(int dastebanditypeid)
    {
        List<Media> l = dc.Medias.Where(s => s.IsShowMediaInSite == true && s.Dastebandis.Any(t => t.DastebandiTypeId == dastebanditypeid && t.IsShowOnSite)).ToList();
        return l;
    }

    private string GetImageDastebandi(int dastebanditypeid)
    {
        string TITLEnAME = ArssPayamHelp.GetNameOfDatebandiTitleImage(dastebanditypeid);
        string path = "Site/Images/text_control/" + TITLEnAME;

        return string.IsNullOrEmpty(TITLEnAME) ? "" : path;
    }



}