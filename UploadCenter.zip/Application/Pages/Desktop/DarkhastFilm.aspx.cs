﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccsess;
using Utility;

public partial class Application_Pages_Desktop_DarkhastFilm : BasePage
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
    public int OldIndex
    {

        get
        {
            if (Request.Cookies["DarkhstFilmSearchCookie"] != null && Request.Cookies["DarkhstFilmSearchCookie"]["OldIndex"] != null)
            {

                return Convert.ToInt32(Request.Cookies["DarkhstFilmSearchCookie"]["OldIndex"]);
            }

            return 0;
        }
        set
        {
            Response.Cookies["DarkhstFilmSearchCookie"]["OldIndex"] = value.ToString();
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void liSearch_Grid_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }
    protected void gvResult_PageIndexChanged(object sender, EventArgs e)
    {

        this.OldIndex = gvResult.PageIndex;

    }
    protected void gvResult_DataBound(object sender, EventArgs e)
    {
        string index = ArssPayamUtility.GetQueryString("index", Request.QueryString["args"]);
        if (!string.IsNullOrEmpty(index))
        {
            if (index == "old")
                gvResult.PageIndex = OldIndex;

        }
    }
    protected void gvResult_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "DeleteRow")
        {
            DeleteRecord(e.CommandArgument.ToString());
            liSearch_Grid.RaiseViewChanged();
        }
        if (e.CommandName == "EditRow")
        {
            Response.Redirect(ArssPayamUtility.GetEncodedQueryString("DarkhastFilmSpec.aspx?args={0}", "ID=" + e.CommandArgument));
        }
    }

    private void DeleteRecord(string id)
    {
        var obj = dc.DarkhastFilms.SingleOrDefault(s => s.UID.ToString() == id);
        if (obj == null)
        {
            ShowErrorMessage("</br>" + "این رکورد قبلا حذف شده است.");
            return;
        }

        dc.DarkhastFilms.DeleteOnSubmit(obj);
        string dsc = "درخواست فیلمی با نام '" + obj.NamFilm + "' نام عوامل فیلم '" + obj.AvamelFilm + "' سال ساخت '" + obj.SalSakht + "' توضیحات '" + obj.Dsc + "' که در زمان '" + obj.Date + "[" + obj.Time + "]" + "' ثبت شده بود حذف گردید.";
        dc.SubmitChanges();
        EventLoger.LogEvent(dsc, (int)EventTypeIds.Hazf, CurrentUser.UID);
        ShowSeccessMessage("</br>" + "درخواست فیلم با موفقیت حذف گردید.");

    }

    private object Search()
    {
        var query = (from p in dc.DarkhastFilms
                     select new
                         {
                             UID = p.UID,
                             namefilm = p.NamFilm,
                             avamelfilm = p.AvamelFilm,
                             salsakht = p.SalSakht,
                             dsc = p.Dsc,
                             date = p.Date + " [ " + p.Time + " ] ",
                             p.IsRead,
                             editurl = p.IsRead ? "~/Application/Images/Grid/read.png" : "~/Application/Images/Grid/UnRead.png",
                             edittooltip = p.IsRead ? "خوانده شده" : "درخواست جدید",
                         }).OrderBy(s => s.IsRead == false).ThenBy(s => s.date);

        lbltedad.Text = query.Count().ToString();
        return query;
    }

}