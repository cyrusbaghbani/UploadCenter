﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccsess;
using Utility;

public partial class Application_Pages_Desktop_Comments : BasePage
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
    public int OldIndex
    {

        get
        {
            if (Request.Cookies["CommentSearchCookie"] != null && Request.Cookies["CommentSearchCookie"]["OldIndex"] != null)
            {

                return Convert.ToInt32(Request.Cookies["CommentSearchCookie"]["OldIndex"]);
            }

            return 0;
        }
        set
        {
            Response.Cookies["CommentSearchCookie"]["OldIndex"] = value.ToString();
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void liSearch_Grid_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }
    protected void gvResult_PageIndexChanged(object sender, EventArgs e)
    {

        this.OldIndex = gvResult.PageIndex;

    }
    protected void gvResult_DataBound(object sender, EventArgs e)
    {
        string index = ArssPayamUtility.GetQueryString("index", Request.QueryString["args"]);
        if (!string.IsNullOrEmpty(index))
        {
            if (index == "old")
                gvResult.PageIndex = OldIndex;

        }
    }
    protected void gvResult_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "EditRow")
        {
            Response.Redirect(ArssPayamUtility.GetEncodedQueryString("CommentSpec.aspx?args={0}", "ID=" + e.CommandArgument));
        }
    }



    private object Search()
    {
        var query_comment = (from p in dc.Comments

                             select new
                                 {
                                     UID = p.UID,
                                     namefilm = p.Media.Name,
                                     p.MediaId,
                                     p.IsShowOnSite,
                                     p.IsRead,

                                 }).ToList();
        var query = (from p in query_comment.GroupBy(s => new { s.MediaId, s.namefilm })
                     select new
                     {
                         UID = p.Key.MediaId,
                         namefilm = p.Key.namefilm,
                         countreg = p.Count(),
                         read = p.Any(s => s.IsRead == false),
                         countnoread = p.Count(s => s.IsRead == false),
                         countshow = p.Count(s => s.IsRead == true && s.IsShowOnSite == true),
                         countnoshow = p.Count(s => s.IsRead == true && s.IsShowOnSite == false),
                         editurl = p.Any(s => s.IsRead == false) ? "~/Application/Images/Grid/UnRead.png" : "~/Application/Images/Grid/read.png",
                         edittooltip = p.Any(s => s.IsRead == false) ? "نظرهای خوانده نشده" : "خوانده شده",
                     }).OrderBy(s => s.read == true);
        lbltedad.Text = query.Count().ToString();
        return query;
    }

}