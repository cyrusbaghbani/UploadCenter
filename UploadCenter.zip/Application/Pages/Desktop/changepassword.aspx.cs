﻿using DataAccsess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Application_Pages_Desktop_changepassword : BasePage
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        Form.DefaultButton = btnsave.UniqueID;
        if (!IsPostBack)
            txtfoldPass.Focus();
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (CheckValidate())
        {
            Save();
            ShowSeccessMessage("</br>" + "رمز عبور با موفقیت تغییر یافت.");
        }
    }
    private bool CheckValidate()
    {
        string Msg = "لطفا به نکات زیر توجه نمایید :" + "</br>";
        bool result = true;
        int i = 0;

        if (CurrentUser.Password != EncryptedQueryString.GetMD5Hash(txtfoldPass.Text))
        {
            result = false;
            Msg += (++i).ToString() + " - " + "کلمه عبور قبلی اشتباه می باشد." + "</br>";
        }

        if (txtPassnew.Text == "" && txtRePassnew.Text == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "کلمه عبور جدید را وارد نمایید." + "</br>";
        }
        else if (txtPassnew.Text.Length < 6)
        {
            result = false;
            Msg += (++i).ToString() + " - " + "کلمه عبور جدید باید حداقل دارای 6 حرف باشد." + "</br>";
        }
        else if (txtPassnew.Text != txtRePassnew.Text)
        {
            result = false;
            Msg += (++i).ToString() + " - " + "کلمه عبور جدید با تکرار آن برابر نمی باشد." + "</br>";
        }



        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }
    /// <summary>
    /// ذخیره کاربر 
    /// </summary>
    private void Save()
    {

        var obj = dc._Users.FirstOrDefault(s => s.UID == CurrentUser.UID);

        obj.Password = EncryptedQueryString.GetMD5Hash(txtPassnew.Text);


        dc.SubmitChanges();
        Session["userhamyartv"] = obj;
        EventLoger.LogEvent("کاربر به نام '" + CurrentUser.FullName + "' با نام کاربری '" + CurrentUser.UserName + "' رمز عبور خودرا ویرای نمود", (int)EventTypeIds.virayesh, CurrentUser.UID);

    }

}