﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccsess;
using Utility;

public partial class Application_Pages_Desktop_CommentSpec : BasePage
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadComments();
            Display();

        }
    }

    protected void btnSabtNazarJadid_Click(object sender, EventArgs e)
    {
        string message = "";
        if (GetTextArea().Trim() == "")
        {
            message = "ShowErrorMessage('</br>  لطفا نظر خود را وارد نمایید');";
            ScriptManager.RegisterClientScriptBlock(sender as Control, this.GetType(), "alert", message, true);
            return;
        }
        SaveNazar();
        LoadComments();
        message = "ShowSeccessMessage('نظر شما با موفقیت ثبت گردید.</br> ');";
        ScriptManager.RegisterClientScriptBlock(sender as Control, this.GetType(), "alert", message, true);
    }
    protected void lstviewNazarat_DataBound(object sender, EventArgs e)
    {
        AddbtnToUploadPannel_Commnets();
    }
    protected void lstviewNazarat_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        if (e.CommandName == "PASOKH")
        {
            string message = "";
            if (GetTextArea().Trim() == "")
            {
                message = "ShowErrorMessage('</br>  لطفا نظر خود را وارد نمایید');";
                ScriptManager.RegisterClientScriptBlock(sender as Control, this.GetType(), "alert", message, true);
                return;
            }
            SaveNazar(e.CommandArgument.ToString());
            LoadComments();
            message = "ShowSeccessMessage('نظر شما با موفقیت ثبت گردید.');";
            ScriptManager.RegisterClientScriptBlock(sender as Control, this.GetType(), "alert", message, true);
        }
        else if (e.CommandName == "DELETEROW")
        {
            var obj = dc.Comments.SingleOrDefault(s => s.UID.ToString() == e.CommandArgument.ToString());
            if (obj == null)
            {
                LoadComments();
                string message = "ShowErrorMessage('رکورد مورد نظر یافت نشد.');";
                ScriptManager.RegisterClientScriptBlock(sender as Control, this.GetType(), "alert", message, true);
            }
            else if (obj.childs_Comments.Any())
            {
                LoadComments();
                string message = "ShowErrorMessage('به دلیل اطلاعات وابسطه امکان حذف وجود ندارد.');";
                ScriptManager.RegisterClientScriptBlock(sender as Control, this.GetType(), "alert", message, true);
            }
            else
            {
                dc.Comments.DeleteOnSubmit(obj);
                dc.SubmitChanges();
                EventLoger.LogEvent("نظری با محتوای '" + obj.Dsc + "' که در زمان '" + (obj.Date + "[" + obj.Time + "]") + "' توسط کاربری با نام '" + (obj.UserId == null ? "" : obj._User.FullName) + "' و نام کاربری '" + (obj.UserId == null ? "" : obj._User.UserName) + "' ثبت شده بود حذف گردید.", (int)EventTypeIds.Hazf, CurrentUser.UID);
                LoadComments();
                string message = "ShowSeccessMessage('نظر شما با موفقیت حذف گردید.');";
                ScriptManager.RegisterClientScriptBlock(sender as Control, this.GetType(), "alert", message, true);
            }
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ReturnToPage();
    }
    private void AddbtnToUploadPannel_Commnets()
    {
        foreach (ListViewDataItem q in lstviewNazarat.Items)
        {
            ListView lstviewPasokhNazarat = (ListView)q.FindControl("lstviewPasokhNazarat");
            LinkButton btn = (LinkButton)q.FindControl("btnSabtNazarJadid");
            LinkButton btndel = (LinkButton)q.FindControl("btnDelete");
            scriptManager_Comments.RegisterAsyncPostBackControl(btn);
            scriptManager_Comments.RegisterAsyncPostBackControl(btndel);
            scriptManager_Comments.RegisterAsyncPostBackControl(lstviewPasokhNazarat);
            foreach (ListViewDataItem row in lstviewPasokhNazarat.Items)
            {
                LinkButton btnSabtNazarJadid = (LinkButton)row.FindControl("btnSabtNazarJadid");
                LinkButton btndelete = (LinkButton)row.FindControl("btnchildDelete");
                scriptManager_Comments.RegisterAsyncPostBackControl(btnSabtNazarJadid);
                scriptManager_Comments.RegisterAsyncPostBackControl(btndelete);
            }
        }
    }

    private void Display()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc.Medias.SingleOrDefault(s => s.UID.ToString() == ID);
        if (obj == null)
            ReturnToPage();
        lblnamfilm.Text = obj.Name;

        var query = dc.Comments.Where(s => s.MediaId.ToString() == ID && s.IsRead == false);
        foreach (var q in query)
            q.IsRead = true;
        dc.SubmitChanges();

    }
    private void LoadComments()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var media = dc.Medias.SingleOrDefault(s => s.UID.ToString() == ID);

        var Query_comments = (from p in dc.Comments
                              where
                              p.CommentTypeId == (int)CommentTypeIds.comment
                              &&
                              p.ParentId == null
                              &&
                              p.MediaId.ToString() == ID
                              select new
                              {
                                  p.UID,
                                  Like = p.childs_Comments.Count(s => s.CommentTypeId == (int)CommentTypeIds.agree),
                                  DisLike = p.childs_Comments.Count(s => s.CommentTypeId == (int)CommentTypeIds.agree),
                                  chkShowPayam = (p.IsShowOnSite == null || p.IsShowOnSite == false) ? false : true,
                                  scriptchmaster = "SetvalueID('" + p.UID + "');",
                                  datasource = p.childs_Comments.Where(s => s.CommentTypeId == (int)CommentTypeIds.comment).Select(s => new
                                  {
                                      childchkShowPayam = (s.IsShowOnSite == null || s.IsShowOnSite == false) ? false : true,
                                      childscriptchmaster = "SetvalueID('" + s.UID + "');",
                                      UID = p.UID,
                                      childIDs = s.UID,
                                      childDsc = s.Dsc,
                                      childLike = s.childs_Comments.Count(t => t.CommentTypeId == (int)CommentTypeIds.agree),
                                      DisLike = s.childs_Comments.Count(t => t.CommentTypeId == (int)CommentTypeIds.agree),
                                      child_user_fullName = s.UserId == null ? "ناشناس" : ((s._User.UserTypeId == (int)UserTypeIds.Modirsystem || s._User.UserTypeId == (int)UserTypeIds.KarbarSystem) ? "سینما همیار" : s._User.FullName),
                                      childTime = s.Time,
                                      childDate = s.Date,
                                      childbgcolor = s.IsRead ? "transparent" : "#fafbd6",
                                      s.SabtDate,
                                      childonclientclick = "if(ShowTextArea(this)) return false;",// : ("ShowErrorMessage('</br>" + "برای ثبت نظر خود ابتدا باید وارد سایت شوید" + "'); return false"),
                                  }).OrderBy(s => s.childDate).ThenBy(s => s.childTime),
                                  FullName = p.UserId == null ? "ناشناس" : ((p._User.UserTypeId == (int)UserTypeIds.Modirsystem || p._User.UserTypeId == (int)UserTypeIds.KarbarSystem) ? "سینما همیار" : p._User.FullName),
                                  Time = p.Time,
                                  Date = p.Date,
                                  p.Dsc,
                                  p.SabtDate,
                                  bgcolor = p.IsRead ? "transparent" : "#fafbd6",
                                  onclientclick = "if(ShowTextArea(this)) return false;",// : ("ShowErrorMessage('</br>" + "برای ثبت نظر خود ابتدا باید وارد سایت شوید" + "'); return false"),
                              }).OrderByDescending(s => s.Date).ThenByDescending(s => s.Time);

        lstviewNazarat.DataSource = Query_comments;
        lstviewNazarat.DataBind();
    }
    private void SaveNazar(string parentId = null)
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = new Comment();
        obj.UID = Guid.NewGuid();
        obj.Time = DateShamsi.GetCurrentHour();
        obj.Date = DateShamsi.GetCurrentDate();
        obj.CommentTypeId = (int)CommentTypeIds.comment;
        obj.Dsc = GetTextArea().Trim().Replace("\n", "</br>");
        obj.IsRead = true;
        obj.IsShowOnSite = true;
        obj.Media = dc.Medias.FirstOrDefault(s => s.UID.ToString() == ID);
        obj.UserId = CurrentUser == null ? (Guid?)null : CurrentUser.UID;
        obj.ParentId = parentId == null ? (Guid?)null : Guid.Parse(parentId);
        dc.Comments.InsertOnSubmit(obj);
        dc.SubmitChanges();
        if (CurrentUser != null)
        {
            EventLoger.LogEvent("کاربر با نام '" + CurrentUser.FullName + "" + "' و نام کاربری '" + CurrentUser.UserName + "' نظر خود را در رابطه با برنامه '" + obj.Media.Name + "' ثبت نمود.", (int)EventTypeIds.Darj, CurrentUser.UID);
        }


    }

    private void ReturnToPage()
    {
        Response.Redirect(ArssPayamUtility.GetEncodedQueryString("Comments.aspx?args={0}", "index=old"));
    }

    protected void chkMaster_CheckedChanged(object sender, EventArgs e)
    {
        string ID = hfvalueCheckbox.Value;
        hfvalueCheckbox.Value = "";
        var obj = dc.Comments.SingleOrDefault(s => s.UID.ToString() == ID);
        if (obj != null)
        {
            obj.IsShowOnSite = obj.IsShowOnSite == null ? true : (!obj.IsShowOnSite.Value);
            dc.SubmitChanges();
        }
    }
}