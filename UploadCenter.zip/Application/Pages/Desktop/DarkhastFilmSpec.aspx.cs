﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccsess;
using Utility;

public partial class Application_Pages_Desktop_DarkhastFilmSpec : BasePage
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Display();
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ReturnToPage();
    }

    private void Display()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc.DarkhastFilms.SingleOrDefault(s => s.UID.ToString() == ID);
        if (obj == null)
            ReturnToPage();

        txtAvamelFilm.Text = obj.AvamelFilm;
        txtdarkhastdahande.Text = obj._User.FullName + " [ " + obj._User.UserName + " ]";
        txtDateDarkhast.Text = obj.Date + " [" + obj.Time + "]";

        txtDsc.Text = obj.Dsc;
        txtnamfilm.Text = obj.NamFilm;
        txtSalSakht.Text = obj.SalSakht;
        obj.IsRead = true;
        dc.SubmitChanges();

    }


    private void ReturnToPage()
    {
        Response.Redirect(ArssPayamUtility.GetEncodedQueryString("DarkhastFilm.aspx?args={0}", "index=old"));
    }
}