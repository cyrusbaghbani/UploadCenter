﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccsess;
using Utility;

public partial class Application_Pages_Security_UserSpec : BasePage
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Display();
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ReturnToListKarbaran();
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (CheckValidate())
        {
            Save();
            ReturnToListKarbaran();
        }

    }

    private void Display()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc._Users.SingleOrDefault(s => s.UID.ToString() == ID);
        if (obj == null)
            return;

        txtfirstName.Text = obj.FirstName;
        txtlastname.Text = obj.LastName;
        txtUsername.Text = obj.UserName;
        cboActive.SelectedIndex = obj.IsActive == true ? 0 : 1;
        txtShomareTel.Text = obj.Telephone;
        txtEmail.Text = obj.Email;
        txtAddress.Text = obj.Address;

    }

    private void Save()
    {
        EventTypeIds Eventtype = EventTypeIds.virayesh;
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc._Users.SingleOrDefault(s => s.UID.ToString() == ID);
        if (obj == null)
        {
            obj = new _User();
            obj.UID = Guid.NewGuid();
            obj.UserTypeId = (int)UserTypeIds.KarbarSystem;
            obj.IsLogin = true;
            dc._Users.InsertOnSubmit(obj);
            obj.DateTimeSabtNam = DateTime.Now;
            Eventtype = EventTypeIds.Darj;
        }
        obj.FirstName = txtfirstName.Text.Trim();
        obj.LastName = txtlastname.Text.Trim();
        obj.UserName = txtUsername.Text.Trim();
        obj.IsActive = cboActive.SelectedIndex == 0;
        if (txtPass.Text != "")
            obj.Password = EncryptedQueryString.GetMD5Hash(txtPass.Text);
        obj.Telephone = obj.Mobile = txtShomareTel.Text.Trim();
        obj.Email = txtEmail.Text.Trim();
        obj.Address = txtAddress.Text.Trim();

        bool ischange = dc.GetChangeSet().Updates.Any();
        dc.SubmitChanges();
        if (Eventtype == EventTypeIds.Darj)
        {
            EventLoger.LogEvent("کاربر با نام '" + obj.FullName + "' نام کاربری '" + obj.UserName + "' درج گردید", (int)Eventtype, CurrentUser.UID);
        }
        else if (ischange)
        {
            EventLoger.LogEvent("کاربر با نام '" + obj.FullName + "' نام کاربری '" + obj.UserName + "' ویرایش گردید", (int)Eventtype, CurrentUser.UID);
        }
        if (obj.UID == CurrentUser.UID)
            Session["userhamyartv"] = obj;

    }

    private bool CheckValidate()
    {
        string Msg = "لطفا به نکات زیر توجه نمایید :" + "</br>";
        bool result = true;
        int i = 0;

        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);

        if (txtfirstName.Text.Trim() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "نام را وارد نمایید." + "</br>";
        }

        if (txtlastname.Text.Trim() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "نام خانوادگی را وارد نمایید." + "</br>";
        }
        if (txtUsername.Text.Trim() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "نام کاربری را وارد نمایید." + "</br>";
        }
        else if (dc._Users.Any(s => s.UserName == txtUsername.Text.Trim() && s.UID.ToString() != ID))
        {
            result = false;
            Msg += (++i).ToString() + " - " + "نام کاربری تکراری است." + "</br>";
        }
        if (string.IsNullOrEmpty(ID) || txtPass.Text != "" || txtRePass.Text != "")
        {
            if (txtPass.Text == "")
            {
                result = false;
                Msg += (++i).ToString() + " - " + "رمز عبور را وارد نمایید." + "</br>";
            }
            else if (txtPass.Text.Length < 6)
            {
                result = false;
                Msg += (++i).ToString() + " - " + "رمز عبور باید حداقل دارای 6 حرف باشد." + "</br>";
            }
            else if (txtPass.Text != txtRePass.Text)
            {
                result = false;
                Msg += (++i).ToString() + " - " + "رمز عبور با تکرار آن برابر نمی باشد." + "</br>";
            }
        }



        if (txtShomareTel.Text.Trim() != ""
            &&
            txtShomareTel.Text.Trim().Length != 11
            )
        {
            result = false;
            Msg += (++i).ToString() + " - " + "شماره همراه را صحیح و کامل وارد نمایید." + "</br>";
        }


        if (txtEmail.Text.Trim() != "" && !Validation.IsEmail(txtEmail.Text.Trim()))
        {
            result = false;
            Msg += (++i).ToString() + " - " + "ایمیل را صحیح وارد نمایید." + "</br>";
        }
        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }


    private void ReturnToListKarbaran()
    {
        Response.Redirect(ArssPayamUtility.GetEncodedQueryString("user.aspx?args={0}", "index=old"));
    }
}