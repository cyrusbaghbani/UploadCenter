﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccsess;
using Utility;

public partial class Application_Pages_Security_User : BasePage
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
    public int OldIndex
    {

        get
        {
            if (Request.Cookies["UserSearchCookie"] != null && Request.Cookies["UserSearchCookie"]["OldIndex"] != null)
            {

                return Convert.ToInt32(Request.Cookies["UserSearchCookie"]["OldIndex"]);
            }

            return 0;
        }
        set
        {
            Response.Cookies["UserSearchCookie"]["OldIndex"] = value.ToString();
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void liSearch_Grid_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }
    protected void gvResult_PageIndexChanged(object sender, EventArgs e)
    {

        this.OldIndex = gvResult.PageIndex;

    }
    protected void gvResult_DataBound(object sender, EventArgs e)
    {
        string index = ArssPayamUtility.GetQueryString("index", Request.QueryString["args"]);
        if (!string.IsNullOrEmpty(index))
        {
            if (index == "old")
                gvResult.PageIndex = OldIndex;

        }
    }
    protected void gvResult_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "DeleteRow")
        {
            DeleteRecord(e.CommandArgument.ToString());
            liSearch_Grid.RaiseViewChanged();
        }
        if (e.CommandName == "EditRow")
        {
            Response.Redirect(ArssPayamUtility.GetEncodedQueryString("UserSpec.aspx?args={0}", "ID=" + e.CommandArgument));
        }
    }

   
    protected void btnNew_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserSpec.aspx");
    }
    private void DeleteRecord(string id)
    {
        var obj = dc._Users.SingleOrDefault(s => s.UID.ToString() == id);
        if (obj == null)
        {
            ShowErrorMessage("</br>" + "این رکورد قبلا حذف شده است.");
            return;
        }
        if (obj.UID == CurrentUser.UID)
        {
            ShowErrorMessage("</br>" + "شما نمی توانید کاربری خود را حذف کنید.");
            return;
        }
        //if (obj.DarkhastFilms.Any() || obj.Comments.Any() || obj.FaaliatKarbarans.Any() || obj.Events.Any())
        //{
        //    ShowErrorMessage("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد.");
        //    return;
        //}

       
        if ( obj.DarkhastFilms.Any())
            dc.DarkhastFilms.DeleteAllOnSubmit(obj.DarkhastFilms);
        dc.SubmitChanges();
        if (obj.Comments.Any())
            dc.Comments.DeleteAllOnSubmit(obj.Comments);
        dc.SubmitChanges();
        if (obj.FaaliatKarbarans.Any())
            dc.FaaliatKarbarans.DeleteAllOnSubmit(obj.FaaliatKarbarans);
        dc.SubmitChanges();
        if (obj.Events.Any())
            dc.Events.DeleteAllOnSubmit(obj.Events);
        dc.SubmitChanges();

        dc._Users.DeleteOnSubmit(obj);
        string dsc = "کاربری با نام '" + obj.UserName + "' نام کاربری '" + obj.FullName + "' حذف گردید.";
        dc.SubmitChanges();
        EventLoger.LogEvent(dsc, (int)EventTypeIds.Hazf, CurrentUser.UID);
        ShowSeccessMessage("</br>" + "کاربر با موفقیت حذف گردید.");

    }
    private object Search()
    {
        var query = from p in dc._Users
                    select new
                        {
                            UID = p.UID,
                            fullname = p.FullName,
                            username = p.UserName,
                            usertype = p.UserTypeId == null ? "" : p.UserType.Name,
                            urlactive = p.IsActive ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                            tooltipactive = p.IsActive ? "فعال" : "غیرفعال"
                        };

        lbltedad.Text = query.Count().ToString();
        return query;
    }

}