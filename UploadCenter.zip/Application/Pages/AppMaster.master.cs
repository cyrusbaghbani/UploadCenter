﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccsess;
using Utility;

public partial class Application_Pages_AppMaster : BaseMaster
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        Display();
        ActiveMenu();
    }
    protected void liExit_Click(object sender, EventArgs e)
    {
        EventLoger.LogEvent("کاربر یا نام '" + CurrentUser.FullName + "' نام کاربری '" + CurrentUser.UserName + "' از سامانه مدیریت خارج گردید", (int)EventTypeIds.KhorojAzSystem, CurrentUser.UID);
        Session.RemoveAll();
        Response.Redirect("~/login.aspx");
    }
    private void Display()
    {
        dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
        lblFullname.Text = " نام و نام خانوادگی : " + CurrentUser.FullName;
        lblcurrentDate.Text = "تاریخ جاری : " + DateShamsi.GetShamsiDayOfWeek((DayOfWeek)DateShamsi.GetDayOfWeek(DateShamsi.GetCurrentDate()))
            + " " + DateShamsi.GetCurrentDate().Split('/')[2]
            + " " + DateShamsi.GetShamsiMonth(int.Parse(DateShamsi.GetCurrentDate().Split('/')[1]))
            + " " + DateShamsi.GetCurrentDate().Split('/')[0];

        int count = dc.DarkhastFilms.Count(s => s.IsRead == false);
        liDarkhastFilm.Text = "درخواست فیلم " + (count == 0 ? "" : ("(" + count + ")"));

        int countNazarat = dc.Comments.Count(s => s.IsRead == false);
        liNazarat.Text = "نظرات " + (countNazarat == 0 ? "" : ("(" + countNazarat + ")"));
    }
    private void ActiveMenu()
    {
        string currenturl = HttpContext.Current.Request.Url.AbsolutePath;
        if (currenturl.ToLower().Contains("appmain.aspx"))
        {
            liMenu.CssClass = "active";
        }
        else if (currenturl.ToLower().Contains("user.aspx") || currenturl.ToLower().Contains("userspec.aspx"))
        {
            liKarbaran.CssClass = "active";
        }
        else if (currenturl.ToLower().Contains("videoupload.aspx") || currenturl.ToLower().Contains("uploadspec.aspx"))
        {
            liuploadFile.CssClass = "active";
        }
        else if (currenturl.ToLower().Contains("showmediaonsite.aspx"))
        {
            liShowMedia.CssClass= "active";
        }
        else if (currenturl.ToLower().Contains("darkhastfilm.aspx") || currenturl.ToLower().Contains("darkhastfilmspec.aspx"))
        {
            liDarkhastFilm.CssClass = "active";
        }
        else if (currenturl.ToLower().Contains("comments.aspx") || currenturl.ToLower().Contains("commentspec.aspx"))
        {
            liNazarat.CssClass = "active";
        }
            
        else if (currenturl.ToLower().Contains("changepassword.aspx"))
        {
            lichangePassword.CssClass = "active";
        }
        
    }

}
