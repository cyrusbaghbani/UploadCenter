﻿using DataAccsess;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Application_Pages_Upload_videoupload : BasePage
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
    public int OldIndex
    {

        get
        {
            if (Request.Cookies["uploadvideoSearchCookie"] != null && Request.Cookies["uploadvideoSearchCookie"]["OldIndex"] != null)
            {

                return Convert.ToInt32(Request.Cookies["uploadvideoSearchCookie"]["OldIndex"]);
            }

            return 0;
        }
        set
        {
            Response.Cookies["uploadvideoSearchCookie"]["OldIndex"] = value.ToString();
        }

    }
    public string _OldNameFilm
    {

        get
        {
            if (Request.Cookies["uploadvideoSearchCookie"] != null && Request.Cookies["uploadvideoSearchCookie"]["_OldNameFilm"] != null)
            {

                return Request.Cookies["uploadvideoSearchCookie"]["_OldNameFilm"];
            }

            return "";
        }
        set
        {
            Response.Cookies["uploadvideoSearchCookie"]["_OldNameFilm"] = value.ToString();
        }

    }
    public string _OldCamboZhanrValue
    {

        get
        {
            if (Request.Cookies["uploadvideoSearchCookie"] != null && Request.Cookies["uploadvideoSearchCookie"]["_OldCamboZhanrValue"] != null)
            {

                return Request.Cookies["uploadvideoSearchCookie"]["_OldCamboZhanrValue"];
            }

            return "";
        }
        set
        {
            Response.Cookies["uploadvideoSearchCookie"]["_OldCamboZhanrValue"] = value.ToString();
        }

    }
    public string _OldCamboDastebandiValue
    {

        get
        {
            if (Request.Cookies["uploadvideoSearchCookie"] != null && Request.Cookies["uploadvideoSearchCookie"]["_OldCamboDastebandiValue"] != null)
            {

                return Request.Cookies["uploadvideoSearchCookie"]["_OldCamboDastebandiValue"];
            }

            return "";
        }
        set
        {
            Response.Cookies["uploadvideoSearchCookie"]["_OldCamboDastebandiValue"] = value.ToString();
        }

    }



    protected void Page_Load(object sender, EventArgs e)
    {
        cboDastebandi.Focus();
        this.Form.DefaultButton = btnSearch.UniqueID;
        if (!IsPostBack)
        {
            Cambobox();
            SetOldParametr();
        }
    }
    protected void liSearch_Grid_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }
    protected void gvResult_PageIndexChanged(object sender, EventArgs e)
    {

        this.OldIndex = gvResult.PageIndex;

    }
    protected void gvResult_DataBound(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string index = ArssPayamUtility.GetQueryString("index", Request.QueryString["args"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                    gvResult.PageIndex = OldIndex;

            }
        }
    }
    protected void gvResult_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "DeleteRow")
        {
            DeleteRecord(e.CommandArgument.ToString());
            liSearch_Grid.RaiseViewChanged();
        }
        if (e.CommandName == "EditRow")
        {
            Response.Redirect(ArssPayamUtility.GetEncodedQueryString("UploadSpec.aspx?args={0}", "ID=" + e.CommandArgument));
        }
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        Response.Redirect("UploadSpec.aspx");
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        gvResult.PageIndex = 0;
        liSearch_Grid.RaiseViewChanged();
        
    }

    private void SetOldParametr()
    {
        string index = ArssPayamUtility.GetQueryString("index", Request.QueryString["args"]);
        if (!string.IsNullOrEmpty(index))
        {
            if (index == "old")
            {
                gvResult.PageIndex = OldIndex;
                txtfilmname.Text = _OldNameFilm;
                cboDastebandi.SelectedValue = _OldCamboDastebandiValue;
                cboZhanr.SelectedValue = _OldCamboZhanrValue;
            }
        }
    }
    private void Cambobox()
    {
        cboZhanr.DataSource = dc.Zhanrs.OrderBy(s => s.Priority).ToList();
        cboZhanr.DataBind();
        cboZhanr.Items.Insert(0, new ListItem("همه", ""));

        cboDastebandi.DataSource = dc.DastebandiTypes.OrderBy(s => s.Priority).ToList();
        cboDastebandi.DataBind();
        cboDastebandi.Items.Insert(0, new ListItem("همه", ""));
    }
    private void DeleteRecord(string id)
    {
        var obj = dc.Medias.SingleOrDefault(s => s.UID.ToString() == id);
        if (obj == null)
        {
            ShowErrorMessage("</br>" + "این رکورد قبلا حذف شده است.");
            return;
        }
        if (obj.Comments.Any() || obj.MediaLinks.Any())
        {
            ShowErrorMessage("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد.");
            return;
        }
        if (obj.Dastebandis.Any())
            dc.Dastebandis.DeleteAllOnSubmit(obj.Dastebandis);
        List<string> urlimage = new List<string>();
        if (obj.MediaGalleries.Any())
        {
            urlimage = obj.MediaGalleries.Select(s => s.ImageUrl).ToList();
            dc.MediaGalleries.DeleteAllOnSubmit(obj.MediaGalleries);
        }
        if (obj.MediaZhanrs.Any())
            dc.MediaZhanrs.DeleteAllOnSubmit(obj.MediaZhanrs);


        dc.Medias.DeleteOnSubmit(obj);
        string dsc = "فیلمی با نام '" + obj.Name + "' حذف گردید.";
        dc.SubmitChanges();
        EventLoger.LogEvent(dsc, (int)EventTypeIds.Hazf, CurrentUser.UID);
        ShowSeccessMessage("</br>" + "فیلم با موفقیت حذف گردید.");

        foreach (string url in urlimage)
        {
            try
            {
                if (File.Exists(url))
                    File.Delete(url);
            }
            catch { }
        }

    }
    private object Search()
    {
        _OldNameFilm = txtfilmname.Text.Trim();
        _OldCamboDastebandiValue = cboDastebandi.SelectedValue;
        _OldCamboZhanrValue = cboZhanr.SelectedValue;
        OldIndex = gvResult.PageIndex;

        List<string> lstname = txtfilmname.Text.Trim().Split(' ').ToList();

        int Jadidtarinid = (int)DastebandiTypeIds.Jadidtarin;
        int Daghtarinid = (int)DastebandiTypeIds.Daghtarin;

        var query1 = (from p in dc.Medias

                      where

                      (cboZhanr.SelectedIndex == 0 || p.MediaZhanrs.Any(s => s.ZhanrId.ToString() == cboZhanr.SelectedValue))
                      &&
                      (cboDastebandi.SelectedIndex == 0 || p.Dastebandis.Any(s => s.DastebandiTypeId.ToString() == cboDastebandi.SelectedValue))
                      select new
                      {
                          UID = p.UID,
                          filmname = p.Name,
                          salsakht = p.IsShowSalSakhtMiadi ? p.SalSakhtMiladi : p.SalSakht,
                          zhanrname = p.MediaZhanrs,
                          dastebandiname = p.Dastebandis,
                          ShowInNewst = p.Dastebandis.Any(t => t.DastebandiTypeId == Jadidtarinid && t.IsShowOnSite),
                          ShowonSlide = p.Dastebandis.Any(t => t.DastebandiType.IsShowOnMenu && t.IsShowOnSite),
                          ShowonDaghtarin = p.Dastebandis.Any(t => t.DastebandiTypeId == Daghtarinid && t.IsShowOnSite),
                          showgallery=p.MediaGalleries.Any(),
                          haslink=p.MediaLinks.Any(),
                          p.IsShowMediaInSite,
                          p.NameKeyword,
                      }).ToList();
        var query = (from p in query1
                     where
                     (txtfilmname.Text.Trim() == "" || lstname.Any(s => p.NameKeyword.ToLower().Contains(s.ToLower())))

                     select new
                     {
                         p.UID,
                         p.filmname,
                         p.salsakht,
                         zhanrname = p.zhanrname.Any() == false ? "" : p.zhanrname.Select(s => s.Zhanr.Name).Aggregate((a, b) => a + ", " + b),
                         dastebandiname = p.dastebandiname.Any() == false ? "" : p.dastebandiname.Select(s => s.DastebandiType.Name).Aggregate((a, b) => a + ", " + b),
                         ShowonSlideurlactive = p.ShowonSlide ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowonSlidetooltipactive = p.ShowonSlide ? "فعال" : "غیرفعال",
                         ShowonNewurlactive = p.ShowInNewst ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowonNewtooltipactive = p.ShowInNewst ? "فعال" : "غیرفعال",
                         ShowonHoturlactive = p.ShowonDaghtarin ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowonHottooltipactive = p.ShowonDaghtarin ? "فعال" : "غیرفعال",
                         Showonlinkurlactive = p.haslink ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         Showonlinktooltipactive = p.haslink ? "لینک فیلم وجود دارد" : "لینک فیلم وجود ندارد",
                         Showongalleryurlactive = p.showgallery ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         Showongallerytooltipactive = p.showgallery ? "گالری عکس دارد" : "گالری عکس ندارد",

                         ShowonSiteurlactive = p.IsShowMediaInSite ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowonSitetooltipactive = p.IsShowMediaInSite ? "فعال" : "غیرفعال",
                     }).ToList();
        lbltedad.Text = query.Count().ToString();
        return query;
    }



}