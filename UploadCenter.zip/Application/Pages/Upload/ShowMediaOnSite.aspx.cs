﻿using DataAccsess;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Application_Pages_Upload_ShowMediaOnSite : BasePage
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();


    protected void Page_Load(object sender, EventArgs e)
    {
        cboDastebandi.Focus();
        this.Form.DefaultButton = btnSearch.UniqueID;
        if (!IsPostBack)
        {
            Cambobox();

        }
    }
    protected void liSearch_Grid_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }
    protected void gvResult_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "EditDasteBandi")
        {
            Edit(e.CommandArgument.ToString().Split(';')[0], e.CommandArgument.ToString().Split(';')[1]);
            liSearch_Grid.RaiseViewChanged();
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        gvResult.PageIndex = 0;
        liSearch_Grid.RaiseViewChanged();

    }

    private void Cambobox()
    {
        cboZhanr.DataSource = dc.Zhanrs.OrderBy(s => s.Priority).ToList();
        cboZhanr.DataBind();
        cboZhanr.Items.Insert(0, new ListItem("همه", ""));

        cboDastebandi.DataSource = dc.DastebandiTypes.OrderBy(s => s.Priority).ToList();
        cboDastebandi.DataBind();
        cboDastebandi.Items.Insert(0, new ListItem("همه", ""));
    }
    private object Search()
    {

        List<string> lstname = txtfilmname.Text.Trim().Split(' ').ToList();

        int Jadidtarinid = (int)DastebandiTypeIds.Jadidtarin;
        int Daghtarinid = (int)DastebandiTypeIds.Daghtarin;
        int _Amozeshiid = (int)DastebandiTypeIds.Amozeshi;
        int _Animationid = (int)DastebandiTypeIds.Animation;
        int _ClipMoshghiid = (int)DastebandiTypeIds.ClipMoshghi;
        int _FilmHayIrani_id = (int)DastebandiTypeIds.FilmHayIrani_;
        int _FilmHayKharejiid = (int)DastebandiTypeIds.FilmHayKhareji;
        int _Mazhabiid = (int)DastebandiTypeIds.Mazhabi;
        int _Mostanadid = (int)DastebandiTypeIds.Mostanad;
        int _Sargarmiid = (int)DastebandiTypeIds.Sargarmi;
        int _SerialIraniid = (int)DastebandiTypeIds.SerialIrani;
        int _SerialKharejiid = (int)DastebandiTypeIds.SerialKhareji;
        int _Varzeshiid = (int)DastebandiTypeIds.Varzeshi;


        var query1 = (from p in dc.Medias

                      where
                     
                      
                      (cboZhanr.SelectedIndex == 0 || p.MediaZhanrs.Any(s => s.ZhanrId.ToString() == cboZhanr.SelectedValue))
                      &&
                      (cboDastebandi.SelectedIndex == 0 || p.Dastebandis.Any(s => s.DastebandiTypeId.ToString() == cboDastebandi.SelectedValue))
                      select new
                      {
                          UID = p.UID,
                          filmname = p.Name,
                          p.NameKeyword,

                          UID_Hotest = p.UID.ToString() + ";" + Daghtarinid,
                          IsShowHotest = p.Dastebandis.Any(t => t.DastebandiTypeId == Daghtarinid),
                          ShowInHotest = p.Dastebandis.Any(t => t.DastebandiTypeId == Daghtarinid && t.IsShowOnSite),

                          UID_Newest = p.UID.ToString() + ";" + Jadidtarinid,
                          IsShowNewest = p.Dastebandis.Any(t => t.DastebandiTypeId == Jadidtarinid),
                          ShowInNewest = p.Dastebandis.Any(t => t.DastebandiTypeId == Jadidtarinid && t.IsShowOnSite),

                          UID_FilmIrani = p.UID.ToString() + ";" + _FilmHayIrani_id,
                          IsShowFilmIrani = p.Dastebandis.Any(t => t.DastebandiTypeId == _FilmHayIrani_id),
                          ShowInFilmIrani = p.Dastebandis.Any(t => t.DastebandiTypeId == _FilmHayIrani_id && t.IsShowOnSite),

                          UID_Animation = p.UID.ToString() + ";" + _Animationid,
                          IsShowAnimation = p.Dastebandis.Any(t => t.DastebandiTypeId == _Animationid),
                          ShowInAnimation = p.Dastebandis.Any(t => t.DastebandiTypeId == _Animationid && t.IsShowOnSite),

                          UID_FilmKhareji = p.UID.ToString() + ";" + _FilmHayKharejiid,
                          IsShowFilmKhareji = p.Dastebandis.Any(t => t.DastebandiTypeId == _FilmHayKharejiid),
                          ShowInFilmKhareji = p.Dastebandis.Any(t => t.DastebandiTypeId == _FilmHayKharejiid && t.IsShowOnSite),

                          UID_SerialIrani = p.UID.ToString() + ";" + _SerialIraniid,
                          IsShowSerialIrani = p.Dastebandis.Any(t => t.DastebandiTypeId == _SerialIraniid),
                          ShowInSerialIrani = p.Dastebandis.Any(t => t.DastebandiTypeId == _SerialIraniid && t.IsShowOnSite),

                          UID_SerialKhareji = p.UID.ToString() + ";" + _SerialIraniid,
                          IsShowSerialKhareji = p.Dastebandis.Any(t => t.DastebandiTypeId == _SerialKharejiid),
                          ShowInSerialKhareji = p.Dastebandis.Any(t => t.DastebandiTypeId == _SerialKharejiid && t.IsShowOnSite),

                          UID_Mostanad = p.UID.ToString() + ";" + _Mostanadid,
                          IsShowMostanad = p.Dastebandis.Any(t => t.DastebandiTypeId == _Mostanadid),
                          ShowInMostanad = p.Dastebandis.Any(t => t.DastebandiTypeId == _Mostanadid && t.IsShowOnSite),

                          UID_Amozeshi = p.UID.ToString() + ";" + _Amozeshiid,
                          IsShowAmozeshi = p.Dastebandis.Any(t => t.DastebandiTypeId == _Amozeshiid),
                          ShowInAmozeshi = p.Dastebandis.Any(t => t.DastebandiTypeId == _Amozeshiid && t.IsShowOnSite),

                          UID_ClipMosheghi = p.UID.ToString() + ";" + _ClipMoshghiid,
                          IsShowClipMosheghi = p.Dastebandis.Any(t => t.DastebandiTypeId == _ClipMoshghiid),
                          ShowInClipMosheghi = p.Dastebandis.Any(t => t.DastebandiTypeId == _ClipMoshghiid && t.IsShowOnSite),

                          UID_Varzeshi = p.UID.ToString() + ";" + _Varzeshiid,
                          IsShowVarzeshi = p.Dastebandis.Any(t => t.DastebandiTypeId == _Varzeshiid),
                          ShowInVarzeshi = p.Dastebandis.Any(t => t.DastebandiTypeId == _Varzeshiid && t.IsShowOnSite),

                          UID_Mazhabi = p.UID.ToString() + ";" + _Mazhabiid,
                          IsShowMazhabi = p.Dastebandis.Any(t => t.DastebandiTypeId == _Mazhabiid),
                          ShowInMazhabi = p.Dastebandis.Any(t => t.DastebandiTypeId == _Mazhabiid && t.IsShowOnSite),

                          UID_Sargarmi = p.UID.ToString() + ";" + _Sargarmiid,
                          IsShowSargarmi = p.Dastebandis.Any(t => t.DastebandiTypeId == _Sargarmiid),
                          ShowInSargarmi = p.Dastebandis.Any(t => t.DastebandiTypeId == _Sargarmiid && t.IsShowOnSite),

                          sal = p.IsShowSalSakhtMiadi == true ? (p.SalSakhtMiladi == null ? "" : p.SalSakhtMiladi.Value.ToString()) : (p.SalSakht == null ? "" : p.SalSakht.Value.ToString()),
                          
                           p.IsShowMediaInSite 
                      }).ToList();
        var query = (from p in query1
                     where
                     (txtfilmname.Text.Trim() == "" || lstname.Any(s => p.NameKeyword.ToLower().Contains(s.ToLower())))

                     select new
                     {
                         p.UID,
                         p.filmname,

                         p.UID_Hotest,
                         p.IsShowHotest,
                         ShowHotest_Url = p.ShowInHotest ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowHotest_tooltip = p.IsShowHotest ? (p.ShowInHotest ? "نمایش" : "عدم نمایش") : "غیر فعال",

                         p.UID_Newest,
                         p.IsShowNewest,
                         ShowNewest_Url = p.ShowInNewest ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowNewest_tooltip = p.IsShowNewest ? (p.ShowInNewest ? "نمایش" : "عدم نمایش") : "غیر فعال",

                         p.UID_FilmIrani,
                         p.IsShowFilmIrani,
                         ShowFilmIrani_Url = p.ShowInFilmIrani ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowFilmIrani_tooltip = p.IsShowFilmIrani ? (p.ShowInFilmIrani ? "نمایش" : "عدم نمایش") : "غیر فعال",

                         p.UID_Animation,
                         p.IsShowAnimation,
                         ShowAnimation_Url = p.ShowInAnimation ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowAnimation_tooltip = p.IsShowAnimation ? (p.ShowInAnimation ? "نمایش" : "عدم نمایش") : "غیر فعال",

                         p.UID_FilmKhareji,
                         p.IsShowFilmKhareji,
                         ShowFilmKhareji_Url = p.ShowInFilmKhareji ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowFilmKhareji_tooltip = p.IsShowFilmKhareji ? (p.ShowInFilmKhareji ? "نمایش" : "عدم نمایش") : "غیر فعال",

                         p.UID_SerialIrani,
                         p.IsShowSerialIrani,
                         ShowSerialIrani_Url = p.ShowInSerialIrani ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowSerialIrani_tooltip = p.IsShowSerialIrani ? (p.ShowInSerialIrani ? "نمایش" : "عدم نمایش") : "غیر فعال",

                         p.UID_SerialKhareji,
                         p.IsShowSerialKhareji,
                         ShowSerialKhareji_Url = p.ShowInSerialKhareji ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowSerialKhareji_tooltip = p.IsShowSerialKhareji ? (p.ShowInSerialKhareji ? "نمایش" : "عدم نمایش") : "غیر فعال",

                         p.UID_Mostanad,
                         p.IsShowMostanad,
                         ShowMostanad_Url = p.ShowInMostanad ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowMostanad_tooltip = p.IsShowMostanad ? (p.ShowInMostanad ? "نمایش" : "عدم نمایش") : "غیر فعال",

                         p.UID_Amozeshi,
                         p.IsShowAmozeshi,
                         ShowAmozeshi_Url = p.ShowInAmozeshi ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowAmozeshi_tooltip = p.IsShowAmozeshi ? (p.ShowInAmozeshi ? "نمایش" : "عدم نمایش") : "غیر فعال",

                         p.UID_ClipMosheghi,
                         p.IsShowClipMosheghi,
                         ShowClipMosheghi_Url = p.ShowInClipMosheghi ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowClipMosheghi_tooltip = p.IsShowClipMosheghi ? (p.ShowInClipMosheghi ? "نمایش" : "عدم نمایش") : "غیر فعال",

                         p.UID_Varzeshi,
                         p.IsShowVarzeshi,
                         ShowVarzeshi_Url = p.ShowInVarzeshi ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowVarzeshi_tooltip = p.IsShowVarzeshi ? (p.ShowInVarzeshi ? "نمایش" : "عدم نمایش") : "غیر فعال",

                         p.UID_Mazhabi,
                         p.IsShowMazhabi,
                         ShowMazhabi_Url = p.ShowInMazhabi ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowMazhabi_tooltip = p.IsShowMazhabi ? (p.ShowInMazhabi ? "نمایش" : "عدم نمایش") : "غیر فعال",

                         p.UID_Sargarmi,
                         p.IsShowSargarmi,
                         ShowSargarmi_Url = p.ShowInSargarmi ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         ShowSargarmi_tooltip = p.IsShowSargarmi ? (p.ShowInSargarmi ? "نمایش" : "عدم نمایش") : "غیر فعال",

                         Show_Url = p.IsShowMediaInSite ? "~/Application/Images/Grid/Active.png" : "~/Application/Images/Grid/InActive.png",
                         Show_tooltip = p.IsShowMediaInSite ? (p.IsShowMediaInSite ? "نمایش" : "عدم نمایش") : "غیر فعال",

                          
                         p.sal,

                     }).ToList();
        lbltedad.Text = query.Count().ToString();
        return query;
    }
    private void Edit(string UID, string DastebandiId)
    {
        var obj = dc.Dastebandis.FirstOrDefault(s => s.MediaId.ToString().ToLower() == UID.ToLower() && s.DastebandiTypeId.ToString() == DastebandiId);
        if (obj == null)
            return;
        obj.IsShowOnSite = !obj.IsShowOnSite;
        dc.SubmitChanges();
        string dsc = "فیلمی با نام '" + obj.Media.Name + "' نمایش دسته بندی '" + obj.DastebandiType.Name + "' " + (obj.IsShowOnSite ? " فعال گردید." : "غیر فعال گردید");
        EventLoger.LogEvent(dsc, (int)EventTypeIds.virayesh, CurrentUser.UID);
    }


}