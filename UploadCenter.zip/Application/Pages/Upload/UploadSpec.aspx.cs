﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccsess;
using System.IO;
using Utility;
using System.Web.UI.HtmlControls;

public partial class Application_Pages_Upload_UploadSpec : BasePage
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        Form.DefaultButton = btnsave.UniqueID;

        if (!IsPostBack)
        {
            BindCambo();
            Dislplay();
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ReturnToLastPage();
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (ChechValidate())
        {
            Save();
            ReturnToLastPage();
        }
    }

    protected void btnSendAXROYJELD_Click(object sender, EventArgs e)
    {
        BindFileUploadImage(fuImageROYJELD, HfImageROYJELDUrl, DIV_AX_ROYJELD, btnDeleteImageAXROYJELD, false);
    }
    protected void btnDeleteImageAXROYJELD_Click(object sender, ImageClickEventArgs e)
    {
        DeleteAx(fuImageROYJELD, HfImageROYJELDUrl, DIV_AX_ROYJELD, btnDeleteImageAXROYJELD);
    }
    protected void btnSendAXPOSHTJELD_Click(object sender, EventArgs e)
    {
        BindFileUploadImage(fuImagePOSHTJELD, hfImagePOSHTJELDUrl, DIV_AX_POSHTJELD, btnDeleteImageAXPOSHTJELD, false);
        string url = DIV_AX_POSHTJELD.Style["background-image"];
        if (url != null)
            DIV_TXT_POSHTCARD.Style.Add("background-image", url);
        else
            DIV_TXT_POSHTCARD.Style.Add("background-image", "");
    }
    protected void btnDeleteImageAXPOSHTJELD_Click(object sender, ImageClickEventArgs e)
    {
        DeleteAx(fuImagePOSHTJELD, hfImagePOSHTJELDUrl, DIV_AX_POSHTJELD, btnDeleteImageAXPOSHTJELD);
        string url = DIV_AX_POSHTJELD.Style["background-image"];
        if (url != null)
            DIV_TXT_POSHTCARD.Style.Add("background-image", url);
        else
            DIV_TXT_POSHTCARD.Style.Add("background-image", "");
    }
    protected void btnDeleteImageAXFilmStrip_Click(object sender, ImageClickEventArgs e)
    {
        DeleteAx(fuImageFilmStrip, hfFilmStripUrl, DIV_AX_FilmStrip, btnDeleteImageAXFilmStrip);
    }
    protected void btnSendAXFilmStrip_Click(object sender, EventArgs e)
    {
        BindFileUploadImage(fuImageFilmStrip, hfFilmStripUrl, DIV_AX_FilmStrip, btnDeleteImageAXFilmStrip, false);
    }
    protected void btnSendAXFilmhayMoshabe_Click(object sender, EventArgs e)
    {
        BindFileUploadImage(fuImageFilmhayMoshabe, hfFilmMoshabeUrl, DIV_AX_FilmhayMoshabe, btnDeleteImageAXFilmhayMoshabe, false);
    }
    protected void btnDeleteImageAXFilmhayMoshabe_Click(object sender, ImageClickEventArgs e)
    {
        DeleteAx(fuImageFilmhayMoshabe, hfFilmMoshabeUrl, DIV_AX_FilmhayMoshabe, btnDeleteImageAXFilmhayMoshabe);
    }
    protected void btnSendGalleryImage_Click(object sender, EventArgs e)
    {
        BindFileUploadImage(fuImage, hfImageIds, null, null, true);

    }
    protected void ldsresultImage_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = Search();
    }
    protected void lstImagegallery_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (e.CommandName == "DeleteImage")
        {
            DeleteImage(e.CommandArgument.ToString());
            ldsresultImage.RaiseViewChanged();
        }
    }
    protected void btnSaveLink_Click(object sender, EventArgs e)
    {
        if (checkValidate_VideoURL())
        {
            SaveTempVideoUrl();
            ClearVideioUrl();
            liMediaResult.RaiseViewChanged();
        }
    }


    protected void liMediaResult_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = SearchMediaLink();
    }
    protected void gvResult_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "EditRow")
        {
            if (CheckValidateEditUrl())
            {
                EDitLink(e.CommandArgument.ToString());
                liMediaResult.RaiseViewChanged();
            }
        }
        if (e.CommandName == "DeleteRow")
        {
            Deleteurl(e.CommandArgument.ToString());
            liMediaResult.RaiseViewChanged();
        }
    }

    private bool CheckValidateEditUrl()
    {
        bool result = true;
        string Msg = "به نکات زیر توجه نمایید" + "</br>";
        int i = 0;
        decimal Itmp = 0;
        int tmp = 0;

        string Hajm = GET_Hajm_EDITLINK();
        string priority = GET_Priority_EDITLINK();
        if (Hajm == "" || !decimal.TryParse("0" + Hajm, out Itmp))
        {
            result = false;
            Msg += (++i).ToString() + " - " + " حجم لینک ویدیو را وارد نمایید" + "</br>";
        }
        if (GET_QualityID_EDITLINK() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + " کیفیت لینک ویدیو را انتخاب نمایید" + "</br>";
        }
        if (priority != "" && !int.TryParse("0" + priority, out tmp))
        {
            result = false;
            Msg += (++i).ToString() + " - " + " الویت نمایش لینک را صحیح وارد نمایید" + "</br>";
        }
        if (GET_AdressLink_EDITLINK() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "آدرس لینک ویدیو را وارد نمایید" + "</br>";
        }


        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }

    private void EDitLink(string Id)
    {
        string Hajm = GET_Hajm_EDITLINK();
        string priority = GET_Priority_EDITLINK();

        if (Id.StartsWith("Temp"))
        {
            Id = Id.Replace("Temp", "");
            var obj = dc.TempSaves.SingleOrDefault(s => s.UID.ToString() == Id);
            if (obj == null)
                return;
            obj.Address = GET_AdressLink_EDITLINK().Replace("/", "\\"); ;
            obj.Hajm = decimal.Parse("0" + Hajm);
            obj.IsShowOnVideo = GET_NAmayeshDarVidio_EDITLINK();
            obj.OnvanNamayeshFilm = GET_Onvan_EDITLINK();
            obj.priority = priority == "" ? (int?)null : int.Parse("0" + priority);
            obj.Quality = dc.Qualities.SingleOrDefault(s => s.Id.ToString() == GET_QualityID_EDITLINK());
            dc.SubmitChanges();
        }
        else
        {
            var obj = dc.MediaLinks.SingleOrDefault(s => s.UID.ToString() == Id);
            if (obj == null)
                return;

            obj.UrlName = GET_AdressLink_EDITLINK().Replace("/", "\\"); ;
            obj.Hajm = decimal.Parse("0" + Hajm);
            obj.IsShowOnVideo = GET_NAmayeshDarVidio_EDITLINK();
            obj.OnvanNamayeshFilm = GET_Onvan_EDITLINK();
            obj.priority = priority == "" ? (int?)null : int.Parse("0" + priority);
            obj.Quality = dc.Qualities.SingleOrDefault(s => s.Id.ToString() == GET_QualityID_EDITLINK());
            obj.MediaName = Path.GetFileName(obj.UrlName);
            obj.ExtentionMedia = Path.GetExtension(obj.UrlName);
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (ischange)
                EventLoger.LogEvent("کاربری با نام '" + CurrentUser.FullName + "' با نام کاربری '" + CurrentUser.UserName + "' لینک فیلم '" + obj.Media.Name + "' با آدرس" + ("") + "' ویرایش گردید.", (int)EventTypeIds.virayesh, CurrentUser.UID);
        }
        ShowSeccessMessage("</br>لینک ویرایش گردید");
    }


    /// <summary>
    /// بارگذاری اطلاعات
    /// </summary>
    private void BindCambo()
    {
        chklistDastebandi.DataSource = dc.DastebandiTypes.OrderBy(s => s.Priority);
        chklistDastebandi.DataBind();

        chklistShowOnDarDastebandi.DataSource = dc.DastebandiTypes.OrderBy(s => s.Priority);
        chklistShowOnDarDastebandi.DataBind();

        chklistzhanr.DataSource = dc.Zhanrs.OrderBy(s => s.Priority);
        chklistzhanr.DataBind();

        cboQuality.DataSource = dc.Qualities.OrderBy(s => s.Priority);
        cboQuality.DataBind();
        cboQuality.Items.Insert(0, new ListItem("انتخاب کنید...", ""));

    }
    /// <summary>
    /// نمایش اطلاعات
    /// </summary>
    private void Dislplay()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc.Medias.FirstOrDefault(s => s.UID.ToString() == ID);

        btnDeleteImageAXFilmhayMoshabe.Visible = false;
        btnDeleteImageAXROYJELD.Visible = false;
        btnDeleteImageAXPOSHTJELD.Visible = false;
        btnDeleteImageAXFilmStrip.Visible = false;

        hfDastebandiCheck.Value = "";
        foreach (var q in dc.DastebandiTypes)
        {
            ListItem chk = chklistDastebandi.Items.FindByValue(q.Id.ToString());
            if (obj == null && (q.Id == (int)DastebandiTypeIds.Daghtarin || q.Id == (int)DastebandiTypeIds.Jadidtarin))
            {
                hfDastebandiCheck.Value += "_" + q.Id + ",";
            }
            ListItem chknamayesh = chklistShowOnDarDastebandi.Items.FindByValue(q.Id.ToString());
            chk.Attributes.Add("onclick", "EnableCheckboxDastebandi(this, '" + q.Id.ToString() + "'); BindCheckListShow('chklistDastebandi', 'chklistShowOnDarDastebandi');");
            chknamayesh.Attributes.Add("onclick", "EnableCheckboxDastebandiShow(this, '" + q.Id.ToString() + "');");
        }

        if (obj == null)
        {

            return;
        }

        txtpishfarzdownload.Text = obj.Pishfarz_Download.ToString();
        txtpishfarztbazdid.Text = obj.Pishfarz_Bazdid.ToString();
        chkIsShowOnMedia.Checked = obj.IsShowMediaInSite;
        txtfilmname.Text = obj.Name;
        txtAvamelFilm.Text = obj.AvamelFilm;
        txtSalShamsi.Text = obj.SalSakht == null ? "" : obj.SalSakht.ToString();
        txtSalMiladi.Text = obj.SalSakhtMiladi == null ? "" : obj.SalSakhtMiladi.ToString();
        rdShowSalMiladi.Checked = obj.IsShowSalSakhtMiadi;
        rdShowSalShamsi.Checked = !obj.IsShowSalSakhtMiadi;
        if (obj.MediaTime != null && obj.MediaTime.Trim() != "")
        {

            if (obj.MediaTime.Length > 5)
            {
                txtSec.Text = obj.MediaTime.Split(':')[2];
                txtmin.Text = obj.MediaTime.Split(':')[1];
                txthour.Text = obj.MediaTime.Split(':')[0];
            }
            else
            {
                txtSec.Text = obj.MediaTime.Split(':')[1];
                txtmin.Text = obj.MediaTime.Split(':')[0];

            }
        }
        chkFilter.Checked = obj.IsUseFilterForPoshtJesld;
        txtprioroty.Text = obj.Priority == null ? "" : obj.Priority.Value.ToString();
        txtDsc.Text = obj.Dsc;
        txtDsc_poshtcart.Text = obj.Dsc_PoshtCard;
        txtavamelfilmkeyword.Text = obj.AvamelFilmKeyword;
        txtNamekeyword.Text = obj.NameKeyword;

        if (obj.UrlAxJeloCard != null && obj.UrlAxJeloCard.Trim() != "")
        {
            btnDeleteImageAXROYJELD.Visible = true;
            DIV_AX_ROYJELD.Style.Add("background-image", "url('" + ArssPayamUtility.GetEncodedQueryString("/Site/Pages/ShowImage.aspx?args={0}", "URL="
                    + obj.UrlAxJeloCard
                    + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image") + "')");
        }

        if (obj.UrlAxPoshtCard != null && obj.UrlAxPoshtCard.Trim() != "")
        {
            btnDeleteImageAXPOSHTJELD.Visible = true;
            DIV_AX_POSHTJELD.Style.Add("background-image", "url('" + ArssPayamUtility.GetEncodedQueryString("/Site/Pages/ShowImage.aspx?args={0}", "URL="
                    + obj.UrlAxPoshtCard
                    + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image") + "')");
            DIV_TXT_POSHTCARD.Style.Add("background-image", "url('" + ArssPayamUtility.GetEncodedQueryString("/Site/Pages/ShowImage.aspx?args={0}", "URL="
                    + obj.UrlAxPoshtCard
                    + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image") + "')");
        }

        if (obj.UrlAxVideoStrip != null && obj.UrlAxVideoStrip.Trim() != "")
        {
            btnDeleteImageAXFilmStrip.Visible = true;
            DIV_AX_FilmStrip.Style.Add("background-image", "url('" + ArssPayamUtility.GetEncodedQueryString("/Site/Pages/ShowImage.aspx?args={0}", "URL="
                    + obj.UrlAxVideoStrip
                    + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image") + "')");

        }

        if (obj.UrlAxFilmhayMoshabe != null && obj.UrlAxFilmhayMoshabe.Trim() != "")
        {
            btnDeleteImageAXFilmhayMoshabe.Visible = true;
            DIV_AX_FilmhayMoshabe.Style.Add("background-image", "url('" + ArssPayamUtility.GetEncodedQueryString("/Site/Pages/ShowImage.aspx?args={0}", "URL="
                    + obj.UrlAxFilmhayMoshabe
                    + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image") + "')");
        }

        if (obj.MediaLinks.Any())
            hfurlvideo.Value = obj.MediaLinks.Select(s => s.UID.ToString().ToLower()).Aggregate((a, b) => a + "," + b) + ",";
        else
            hfurlvideo.Value = "";


        foreach (var q in dc.MediaZhanrs.Where(s => s.MediaId == obj.UID))
        {
            ListItem chk = chklistzhanr.Items.FindByValue(q.ZhanrId.ToString());
            chk.Selected = true;
        }

        hfDastebandiCheck.Value = (dc.Dastebandis.Any(s => s.MediaId == obj.UID) ? dc.Dastebandis.Where(s => s.MediaId == obj.UID).ToList().Select(s => "_" + s.DastebandiTypeId.ToString()).Aggregate((a, b) => a + "," + b) : "") + ",";
        hfDastebandiShowCheck.Value = (dc.Dastebandis.Any(s => s.MediaId == obj.UID && s.IsShowOnSite) ? dc.Dastebandis.Where(s => s.MediaId == obj.UID && s.IsShowOnSite).ToList().Select(s => "_" + s.DastebandiTypeId.ToString()).Aggregate((a, b) => a + "," + b) : "") + ",";


        if (obj.MediaGalleries.Any())
            hfImageIds.Value = obj.MediaGalleries.Select(s => s.UID.ToString().ToLower()).Aggregate((a, b) => a + "," + b) + ",";
        else
            hfImageIds.Value = "";
    }
    /// <summary>
    /// تمام عکسها و لینک هایی که به صورت موقت ثبت شده است حذف شود
    /// </summary>
    private void ReturnToLastPage()
    {
        List<string> LstTempid_image = new List<string>();
        foreach (var q in hfImageIds.Value.Split(','))
        {
            if (q.StartsWith("Temp"))
            {
                LstTempid_image.Add(q.Replace("Temp", ""));
            }
        }
        if (hfFilmMoshabeUrl.Value.StartsWith("Temp"))
        {
            LstTempid_image.Add(hfFilmMoshabeUrl.Value.Replace("Temp", ""));
        }
        if (hfFilmStripUrl.Value.StartsWith("Temp"))
        {
            LstTempid_image.Add(hfFilmStripUrl.Value.Replace("Temp", ""));
        }
        if (hfImagePOSHTJELDUrl.Value.StartsWith("Temp"))
        {
            LstTempid_image.Add(hfImagePOSHTJELDUrl.Value.Replace("Temp", ""));
        }
        if (HfImageROYJELDUrl.Value.StartsWith("Temp"))
        {
            LstTempid_image.Add(HfImageROYJELDUrl.Value.Replace("Temp", ""));
        }
        List<string> addresslst = dc.TempSaves.Where(s => LstTempid_image.Contains(s.UID.ToString())).Select(s => s.Address).ToList();
        DeleteList(addresslst);
        Response.Redirect(ArssPayamUtility.GetEncodedQueryString("videoupload.aspx?args={0}", "index=old"));
    }
    /// <summary>
    /// حذف عکس ها
    /// </summary>
    /// <param name="lstadr"></param>
    private void DeleteList(List<string> lstadr)
    {
        foreach (var str in lstadr)
        {
            try
            {
                string path = str;
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
            }
            catch
            {
            }
        }
    }
    /// <summary>
    /// بررسی اطلاعات وارد شده
    /// </summary>
    /// <returns></returns>
    private bool ChechValidate()
    {
        bool result = true;
        string Msg = "به نکات زیر توجه نمایید" + "</br>";
        int i = 0;
        int Itmp = 0;
        if (txtfilmname.Text.Trim() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + " نام فیلم را وارد نمایید" + "</br>";
        }
        if (!int.TryParse("0" + txtSalShamsi.Text.Trim(), out Itmp))
        {
            result = false;
            Msg += (++i).ToString() + " - " + " سال شمسی را به صورت صحیح و بیشتر از 1300 وارد نمایید" + "</br>";
        }
        else if (Itmp < 1300)
        {
            result = false;
            Msg += (++i).ToString() + " - " + " سال شمسی را به صورت صحیح و بیشتر از 1300 وارد نمایید" + "</br>";
        }

        if (!int.TryParse("0" + txtSalMiladi.Text.Trim(), out Itmp))
        {
            result = false;
            Msg += (++i).ToString() + " - " + " سال میلادی را به صورت صحیح و بیشتر از 1900 وارد نمایید" + "</br>";
        }
        else if (Itmp < 1900)
        {
            result = false;
            Msg += (++i).ToString() + " - " + " سال میلادی را به صورت صحیح و بیشتر از 1900 وارد نمایید" + "</br>";
        }
        if (txtSec.Text.Trim() == "" || txtmin.Text.Trim() == "" || txthour.Text.Trim() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + " زمان فیلم را وارد نمایید" + "</br>";
        }
        else
        {
            if (txtSec.Text.Trim() != "" && !int.TryParse("0" + txtSec.Text.Trim(), out Itmp))
            {
                result = false;
                Msg += (++i).ToString() + " - " + " ثانیه را به صورت عددی و بین عدد 0 تا 59 وارد نمایید" + "</br>";
            }
            else if (Itmp < 0 || Itmp > 59)
            {
                result = false;
                Msg += (++i).ToString() + " - " + " ثانیه را به صورت عددی و بین عدد 0 تا 59 وارد نمایید" + "</br>";
            }
            if (txtmin.Text.Trim() != "" && !int.TryParse("0" + txtmin.Text.Trim(), out Itmp))
            {
                result = false;
                Msg += (++i).ToString() + " - " + " دقیقه را به صورت عددی و بین عدد 0 تا 59 وارد نمایید" + "</br>";
            }
            else if (Itmp < 0 || Itmp > 59)
            {
                result = false;
                Msg += (++i).ToString() + " - " + " دقیقه را به صورت عددی و بین عدد 0 تا 59 وارد نمایید" + "</br>";
            }
            if (txthour.Text.Trim() != "" && !int.TryParse("0" + txthour.Text.Trim(), out Itmp))
            {
                result = false;
                Msg += (++i).ToString() + " - " + " دقیقه را به صورت عددی وارد نمایید" + "</br>";
            }
        }
        if (txtprioroty.Text.Trim() != "" && !int.TryParse("0" + txtprioroty.Text.Trim(), out Itmp))
        {
            result = false;
            Msg += (++i).ToString() + " - " + " اولویت را به صورت عددی و صحیح وارد نمایید" + "</br>";
        }
        if (!int.TryParse("0" + txtpishfarztbazdid.Text.Trim(), out Itmp))
        {
            result = false;
            Msg += (++i).ToString() + " - " + " پیش فرض تعداد بازدید را به صورت عددی و صحیح وارد نمایید" + "</br>";
        }
        if (!int.TryParse("0" + txtpishfarzdownload.Text.Trim(), out Itmp))
        {
            result = false;
            Msg += (++i).ToString() + " - " + " پیش فرض تعداد دانلود را به صورت عددی و صحیح وارد نمایید" + "</br>";
        }

        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }
    /// <summary>
    /// ذخیره اطلاعات
    /// </summary>
    private void Save()
    {
        List<string> lstimagedelete = new List<string>();
        bool isUpdate = false;
        EventTypeIds Eventtype = EventTypeIds.virayesh;
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = dc.Medias.SingleOrDefault(s => s.UID.ToString() == ID);
        if (obj == null)
        {
            obj = new Media();
            obj.UID = Guid.NewGuid();
            obj.ZamanSabt = DateTime.Now;
            dc.Medias.InsertOnSubmit(obj);
            Eventtype = EventTypeIds.Darj;
        }

        obj.Pishfarz_Bazdid = int.Parse("0" + txtpishfarztbazdid.Text.Trim());
        obj.Pishfarz_Download = int.Parse("0" + txtpishfarzdownload.Text.Trim());
        obj.IsShowMediaInSite = chkIsShowOnMedia.Checked;
        obj.AvamelFilm = txtAvamelFilm.Text.Trim();

        obj.AvamelFilmKeyword = txtavamelfilmkeyword.Text.Trim() == "" ? obj.AvamelFilm : txtavamelfilmkeyword.Text.Trim();

        foreach (ListItem dastebandiItem in chklistDastebandi.Items)
        {
            var obj_dastebandi = obj.Dastebandis.FirstOrDefault(s => s.DastebandiTypeId.ToString() == dastebandiItem.Value);

            if (dastebandiItem.Selected == true)
            {
                ListItem chknamayesh = chklistShowOnDarDastebandi.Items.FindByValue(dastebandiItem.Value);
                if (obj_dastebandi == null)
                {
                    obj_dastebandi = new Dastebandi();
                    obj_dastebandi.UID = Guid.NewGuid();
                    obj_dastebandi.Media = obj;
                    obj_dastebandi.DastebandiType = dc.DastebandiTypes.SingleOrDefault(s => s.Id.ToString() == dastebandiItem.Value);
                    dc.Dastebandis.InsertOnSubmit(obj_dastebandi);
                    isUpdate = true;
                }
                obj_dastebandi.IsShowOnSite = chknamayesh.Selected;
            }
            else
            {
                if (obj_dastebandi != null)
                {
                    dc.Dastebandis.DeleteOnSubmit(obj_dastebandi);
                    isUpdate = true;
                }
            }
        }

        obj.Dsc = txtDsc.Text.Trim();
        obj.Dsc_PoshtCard = txtDsc_poshtcart.Text.Trim();

        obj.IsShowSalSakhtMiadi = rdShowSalMiladi.Checked;
        obj.IsUseFilterForPoshtJesld = chkFilter.Checked;

        List<string> lstOldMediaGalleryId = hfImageIds.Value.Split(',').Where(s => s.StartsWith("Temp") == false).ToList();
        List<MediaGallery> lstMediaGallerryDelete = obj.MediaGalleries.Where(s => !lstOldMediaGalleryId.Contains(s.UID.ToString())).ToList();
        foreach (var obj_del in lstMediaGallerryDelete)
        {
            lstimagedelete.Add(obj_del.ImageUrl);
            dc.MediaGalleries.DeleteOnSubmit(obj_del);
            isUpdate = true;
        }

        List<string> lstTempMediaGalleryId = hfImageIds.Value.Split(',').Where(s => s.StartsWith("Temp") == true).Select(s => s.Replace("Temp", "")).ToList();

        foreach (string str in lstTempMediaGalleryId)
        {
            var obj_temp = dc.TempSaves.SingleOrDefault(s => s.UID.ToString() == str);
            if (obj_temp != null)
            {
                var media_gallery = new MediaGallery();
                media_gallery.UID = Guid.NewGuid();
                media_gallery.Media = obj;

                string path = Server.MapPath("~" + ImagePath + media_gallery.UID.ToString().Replace("-", "_") + Path.GetExtension(obj_temp.Address));
                try
                {
                    if (File.Exists(obj_temp.Address))
                        File.Move(obj_temp.Address, path);
                }
                catch { }
                media_gallery.ImageUrl = path;
                dc.MediaGalleries.InsertOnSubmit(media_gallery);
                dc.TempSaves.DeleteOnSubmit(obj_temp);
                isUpdate = true;
            }
        }

        List<string> lstOldMediaLinkId = hfurlvideo.Value.Split(',').Where(s => s.StartsWith("Temp") == false).ToList();
        List<MediaLink> lstMediaLinkDelete = obj.MediaLinks.Where(s => !lstOldMediaLinkId.Contains(s.UID.ToString())).ToList();
        foreach (var obj_del in lstMediaLinkDelete)
        {
            if (obj_del.FaaliatKarbarans.Any())
                dc.FaaliatKarbarans.DeleteAllOnSubmit(dc.FaaliatKarbarans.Where(s => s.MediaLinkId == obj_del.UID));
            dc.MediaLinks.DeleteOnSubmit(obj_del);
            isUpdate = true;
        }

        List<string> lstTempMedialINKId = hfurlvideo.Value.Split(',').Where(s => s.StartsWith("Temp") == true).Select(s => s.Replace("Temp", "")).ToList();

        foreach (string str in lstTempMedialINKId)
        {
            var obj_temp = dc.TempSaves.SingleOrDefault(s => s.UID.ToString() == str);
            if (obj_temp != null)
            {
                var media_LINK = new MediaLink();
                media_LINK.UID = Guid.NewGuid();
                media_LINK.Media = obj;
                media_LINK.UrlName = obj_temp.Address;
                media_LINK.ExtentionMedia = Path.GetExtension(obj_temp.Address).Replace(".", "");
                media_LINK.Hajm = obj_temp.Hajm;
                media_LINK.OnvanNamayeshFilm = obj_temp.OnvanNamayeshFilm;
                media_LINK.priority = obj_temp.priority;
                media_LINK.IsShowOnVideo = obj_temp.IsShowOnVideo == null ? false : obj_temp.IsShowOnVideo.Value;
                media_LINK.Quality = dc.Qualities.SingleOrDefault(s => s.Id == obj_temp.qualityId);
                media_LINK.MediaName = Path.GetFileNameWithoutExtension(obj_temp.Address);
                dc.MediaLinks.InsertOnSubmit(media_LINK);
                dc.TempSaves.DeleteOnSubmit(obj_temp);
                isUpdate = true;
            }
        }

        obj.MediaTime = (txthour.Text.Trim() == "" ? "" : (txthour.Text.Trim() + ":")) + int.Parse("0" + txtmin.Text.Trim()).ToString("00") + ":" + int.Parse("0" + txtSec.Text.Trim()).ToString("00");

        foreach (ListItem o in chklistzhanr.Items)
        {
            var t = obj.MediaZhanrs.FirstOrDefault(s => s.ZhanrId.ToString() == o.Value);
            if (o.Selected == true)
            {
                if (t == null)
                {
                    t = new MediaZhanr();
                    t.Zhanr = dc.Zhanrs.SingleOrDefault(s => s.Id.ToString() == o.Value);
                    t.Media = obj;
                    t.UID = Guid.NewGuid();
                    dc.MediaZhanrs.InsertOnSubmit(t);
                    isUpdate = true;
                }
            }
            else
            {
                if (t != null)
                {
                    dc.MediaZhanrs.DeleteOnSubmit(t);
                    isUpdate = true;
                }
            }

        }

        string oldFilmName = "";
        if (obj.Name == txtfilmname.Text.Trim())
            oldFilmName = obj.Name;
        obj.Name = txtfilmname.Text.Trim();
        obj.NameKeyword = txtNamekeyword.Text.Trim() == "" ? obj.Name : txtNamekeyword.Text.Trim();

        obj.Priority = txtprioroty.Text.Trim() == "" ? (int?)null : int.Parse("0" + txtprioroty.Text.Trim());

        obj.PosterAxUrl = "";

        obj.SalSakht = int.Parse("0" + txtSalShamsi.Text.Trim());
        obj.SalSakhtMiladi = int.Parse("0" + txtSalMiladi.Text.Trim());

        if (hfFilmMoshabeUrl.Value.Trim() == "DELETE_NO_IMAGE")
        {
            lstimagedelete.Add(obj.UrlAxFilmhayMoshabe);
            obj.UrlAxFilmhayMoshabe = "";
        }
        if (hfFilmMoshabeUrl.Value.Trim().StartsWith("Temp"))
        {
            var o = dc.TempSaves.SingleOrDefault(s => s.UID.ToString() == hfFilmMoshabeUrl.Value.Trim().Replace("Temp", ""));
            if (o != null)
            {
                string path = Server.MapPath("~" + ImagePath + "AXMOSHABEH" + obj.UID.ToString().Replace("-", "_") + Path.GetExtension(o.Address));
                try
                {
                    if (File.Exists(path))
                        File.Delete(path);
                    if (File.Exists(o.Address))
                        File.Move(o.Address, path);
                }
                catch { }
                obj.UrlAxFilmhayMoshabe = path;
                dc.TempSaves.DeleteOnSubmit(o);
            }
        }

        if (HfImageROYJELDUrl.Value.Trim() == "DELETE_NO_IMAGE")
        {
            lstimagedelete.Add(obj.UrlAxJeloCard);
            obj.UrlAxJeloCard = "";
        }
        if (HfImageROYJELDUrl.Value.Trim().StartsWith("Temp"))
        {
            var o = dc.TempSaves.SingleOrDefault(s => s.UID.ToString() == HfImageROYJELDUrl.Value.Trim().Replace("Temp", ""));
            if (o != null)
            {
                string path = Server.MapPath("~" + ImagePath + "AXJELOCARD" + obj.UID.ToString().Replace("-", "_") + Path.GetExtension(o.Address));
                try
                {
                    if (File.Exists(path))
                        File.Delete(path);
                    if (File.Exists(o.Address))
                        File.Move(o.Address, path);
                }
                catch { }
                obj.UrlAxJeloCard = path;
                dc.TempSaves.DeleteOnSubmit(o);
            }
        }

        if (hfImagePOSHTJELDUrl.Value.Trim() == "DELETE_NO_IMAGE")
        {
            lstimagedelete.Add(obj.UrlAxPoshtCard);
            obj.UrlAxPoshtCard = "";
        }
        if (hfImagePOSHTJELDUrl.Value.Trim().StartsWith("Temp"))
        {
            var o = dc.TempSaves.SingleOrDefault(s => s.UID.ToString() == hfImagePOSHTJELDUrl.Value.Trim().Replace("Temp", ""));
            if (o != null)
            {
                string path = Server.MapPath("~" + ImagePath + "AXPOSHTCARD" + obj.UID.ToString().Replace("-", "_") + Path.GetExtension(o.Address));
                try
                {
                    if (File.Exists(path))
                        File.Delete(path);
                    if (File.Exists(o.Address))
                        File.Move(o.Address, path);
                }
                catch { }
                obj.UrlAxPoshtCard = path;
                dc.TempSaves.DeleteOnSubmit(o);
            }
        }

        if (hfFilmStripUrl.Value.Trim() == "DELETE_NO_IMAGE")
        {
            lstimagedelete.Add(obj.UrlAxVideoStrip);
            obj.UrlAxVideoStrip = "";
        }
        if (hfFilmStripUrl.Value.Trim().StartsWith("Temp"))
        {
            var o = dc.TempSaves.SingleOrDefault(s => s.UID.ToString() == hfFilmStripUrl.Value.Trim().Replace("Temp", ""));
            if (o != null)
            {
                string path = Server.MapPath("~" + ImagePath + "AXSTRIPVIDEO" + obj.UID.ToString().Replace("-", "_") + Path.GetExtension(o.Address));
                try
                {
                    if (File.Exists(path))
                        File.Delete(path);
                    if (File.Exists(o.Address))
                        File.Move(o.Address, path);
                }
                catch { }
                obj.UrlAxVideoStrip = path;
                dc.TempSaves.DeleteOnSubmit(o);
            }
        }




        bool ischange = dc.GetChangeSet().Updates.Any() || isUpdate;
        dc.SubmitChanges();
        if (Eventtype == EventTypeIds.Darj)
        {
            EventLoger.LogEvent("کاربری با نام '" + CurrentUser.FullName + "' با نام کاربری '" + CurrentUser.UserName + "' فیلم '" + obj.Name + "' درج گردید", (int)Eventtype, CurrentUser.UID);
        }
        else if (ischange)
        {
            EventLoger.LogEvent("کاربری با نام '" + CurrentUser.FullName + "' با نام کاربری '" + CurrentUser.UserName + "' فیلم '" + obj.Name + "' ویرایش گردید." + (oldFilmName.Trim() == "" ? "" : ("(عنوان قبلی فیلم '" + oldFilmName + "')")), (int)Eventtype, CurrentUser.UID);
        }

        DeleteList(lstimagedelete);
    }
    /// <summary>
    /// عکس گالری و بقیه عکس بارگزاری یا خذف می کند
    /// </summary>
    /// <param name="fu"></param>
    /// <param name="Hf"></param>
    /// <param name="DIV_"></param>
    /// <param name="btnDel"></param>
    private void BindFileUploadImage(FileUpload fu, HiddenField Hf, HtmlGenericControl DIV_, ImageButton btnDel, bool isimagegallery)
    {
        if (fu.HasFile)
        {
            CheckSelectedFile(fu, 204800, isimagegallery, Hf, DIV_, btnDel);
        }
    }
    /// <summary>
    /// چک می کند که آیا فایل آپلود شده با فرمت های خواسته شده تطابق دارد یا خیر
    /// </summary>
    /// <param name="fu">کامپوننت فایل آپلودی که از آن استفاده شده تا عکس را انتخاب کند</param>
    /// <param name="lenght">اندازه ی عکس</param>
    /// <param name="message">نام عکس</param>
    /// <param name="sessionName">پارامتری که اگر عکس به صورت موقت وجود داشته باشد در آن است</param>
    /// <param name="img">کامپوننت عکس که قرار است عکس روی آن نمایش داده شود</param>
    /// <param name="btn">دکمه حذف عکس</param>
    /// <param name="lnk">لینک مخصوص به دانلود عکس</param>
    private void CheckSelectedFile(FileUpload fu, int lenght, bool IsGallery, HiddenField hf, HtmlGenericControl DIV_, ImageButton btnDel)
    {
        string[] contentTypes = { "image/pjpeg", "image/jpeg", "image/x-png", "image/png" };//فرمت های مجاز
        string[] extention = { ".jpg", ".jpeg", ".png" };//پسوند های مجاز

        if (!fu.HasFile)//اگر فایل آپلود آدرس عکس را داشت
            ShowErrorMessage("لطفا تصویر " + "مورد نظر" + " را انتخاب نمایید.");
        else if (fu.HasFile && !contentTypes.Contains(fu.PostedFile.ContentType.ToString()))//اگر عکس وجود دارد آیا فرمت ها را رعایت کرده است
            ShowErrorMessage("لطفا تصویر " + "مورد نظر" + " را متناسب با ویژگی های داده شده انتخاب نمایید.");
        else
        {

            var obj = new TempSave();
            obj.UID = Guid.NewGuid();
            obj.Datetime = DateTime.Now;
            obj.Type = "IMAGE";
            obj.Address = Server.MapPath("~" + ImagePath + "Temp" + obj.UID + Path.GetExtension(fu.FileName));
            dc.TempSaves.InsertOnSubmit(obj);
            dc.SubmitChanges();
            fu.SaveAs(obj.Address);//به صورت موقت عکس را ذخیره کرد'
            if (IsGallery)
            {
                hf.Value += "Temp" + obj.UID + ",";
                ldsresultImage.RaiseViewChanged();
            }
            else
            {
                if (hf.Value.StartsWith("Temp"))
                {

                    var objdel = dc.TempSaves.SingleOrDefault(s => s.UID.ToString() == hf.Value.Replace("Temp", ""));
                    if (objdel != null)
                    {
                        try
                        {
                            if (File.Exists(objdel.Address))
                                File.Delete(objdel.Address);
                        }
                        catch { }
                        dc.TempSaves.DeleteOnSubmit(objdel);
                        dc.SubmitChanges();
                    }
                }
                DIV_.Style.Add("background-image", "url('" + ArssPayamUtility.GetEncodedQueryString("/Site/Pages/ShowImage.aspx?args={0}", "URL="
                    + obj.Address
                    + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image") + "')");
                btnDel.Visible = true;
                hf.Value = "Temp" + obj.UID;

            }
        }
    }
    /// <summary>
    /// حذف عکس های تکی
    /// </summary>
    /// <param name="fuImageROYJELD"></param>
    /// <param name="HfImageROYJELDUrl"></param>
    /// <param name="DIV_AX_ROYJELD"></param>
    /// <param name="btnDeleteImageAXROYJELD"></param>
    private void DeleteAx(FileUpload fu, HiddenField hf, HtmlGenericControl DIV_, ImageButton btnDel)
    {
        if (hf.Value.StartsWith("Temp"))
        {

            var objdel = dc.TempSaves.SingleOrDefault(s => s.UID.ToString() == hf.Value.Replace("Temp", ""));
            if (objdel != null)
            {
                try
                {
                    if (File.Exists(objdel.Address))
                        File.Delete(objdel.Address);
                }
                catch { }
                dc.TempSaves.DeleteOnSubmit(objdel);
                dc.SubmitChanges();
            }
        }
        DIV_.Style.Add("background-image", "");
        btnDel.Visible = false;
        hf.Value = "DELETE_NO_IMAGE";

    }
    /// <summary>
    /// خذف عکس با شناسه تکی
    /// </summary>
    /// <param name="Id"></param>
    private void DeleteImage(string Id)
    {
        hfImageIds.Value = hfImageIds.Value.Replace(Id + ",", "");
        if (!Id.StartsWith("Temp"))
        {
            ldsresultImage.RaiseViewChanged();
            return;
        }
        Id = Id.Replace("Temp", "");
        var obj = dc.TempSaves.SingleOrDefault(s => s.UID.ToString() == Id);
        if (obj != null)
        {
            try
            {
                string path = obj.Address;
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
                dc.TempSaves.DeleteOnSubmit(obj);
            }
            catch { }
        }
        dc.SubmitChanges();
        ldsresultImage.RaiseViewChanged();
    }
    /// <summary>
    /// جستجو برای گالری عکس
    /// </summary>
    /// <returns></returns>
    private object Search()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        List<string> Lstid_image = new List<string>();
        List<string> LstTempid_image = new List<string>();
        foreach (var q in hfImageIds.Value.Split(','))
        {
            if (q.StartsWith("Temp"))
            {
                LstTempid_image.Add(q.Replace("Temp", ""));
            }
            else
            {
                Lstid_image.Add(q);
            }
        }


        var queryTempImages = (from p in dc.TempSaves
                               where
                                LstTempid_image.Contains(p.UID.ToString())
                                &&
                                p.Type == "IMAGE"
                               select new
                               {
                                   Url = SetImageAddress(p.Address, false),
                                   UID = "Temp" + p.UID.ToString().ToLower()
                               }).ToList();
        var queryImages = (from p in dc.MediaGalleries
                           where
                            Lstid_image.Contains(p.UID.ToString())
                            &&
                            p.MediaId.ToString() == ID
                           select new
                           {
                               Url = SetImageAddress(p.ImageUrl, false),
                               UID = p.UID.ToString().ToLower()
                           }).ToList();

        fuImage.Visible = queryTempImages.Count <= 9;
        return queryTempImages.Concat(queryImages);
    }
    /// <summary>
    /// آدرس عکس را بر می گرداند
    /// </summary>
    /// <param name="adr"></param>
    /// <param name="ishtml"></param>
    /// <returns></returns>
    private string SetImageAddress(string adr, bool ishtml)
    {
        return ArssPayamUtility.GetEncodedQueryString((ishtml ? "~" : "") + "/Site/Pages/ShowImage.aspx?args={0}", "URL="
                         + adr
                         + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image");
    }
    /// <summary>
    /// جستجو برای نمایش لینک
    /// </summary>
    /// <returns></returns>
    private object SearchMediaLink()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);

        List<string> Lstid_ = new List<string>();
        List<string> LstTempid_ = new List<string>();
        foreach (var q in hfurlvideo.Value.Split(','))
        {
            if (q.StartsWith("Temp"))
            {
                LstTempid_.Add(q.Replace("Temp", ""));
            }
            else
            {
                Lstid_.Add(q);
            }
        }


        var queryTemp = (from p in dc.TempSaves
                         where
                          LstTempid_.Contains(p.UID.ToString())
                          &&
                          p.Type == "MEDIALINK"
                         select new
                         {
                             UID = "Temp" + p.UID.ToString().ToLower(),
                             IsNamayesh = p.IsShowOnVideo == true ? "بلی" : "خیر",
                             p.Hajm,
                             QULITY = p.qualityId == null ? "" : p.Quality.Name,
                             adr = p.Address,
                             p.priority,
                             p.OnvanNamayeshFilm,
                             onclientclicktemp = " if(ShowEDITLINK_MODELDIALOG(this,'" + (p.IsShowOnVideo == true ? 1 : 0) + "','" + (p.Hajm == null ? "" : ((int)p.Hajm.Value).ToString()) + "','" + (p.qualityId == null ? "" : p.qualityId.ToString()) + "','" + (p.Address == null ? "" : p.Address.Replace("\\", "\\\\")) + "','" + (p.priority == null ? "" : p.priority.ToString()) + "','" + (p.OnvanNamayeshFilm == null ? "" : p.OnvanNamayeshFilm) + "')) return false;"

                         }).ToList();

        var item_ds = (from p in dc.MediaLinks
                       where
                       p.MediaId.ToString() == ID
                       &&
                      Lstid_.Contains(p.UID.ToString())

                       select new
                       {
                           UID = p.UID.ToString().ToLower(),
                           IsNamayesh = p.IsShowOnVideo == true ? "بلی" : "خیر",
                           p.Hajm,
                           QULITY = p.qualityId == null ? "" : p.Quality.Name,
                           adr = p.UrlName,
                           p.priority,
                           p.OnvanNamayeshFilm,
                           onclientclicktemp = " if(ShowEDITLINK_MODELDIALOG(this,'" + (p.IsShowOnVideo == true ? 1 : 0) + "','" + (p.Hajm == null ? "" : ((int)p.Hajm.Value).ToString()) + "','" + (p.qualityId == null ? "" : p.qualityId.ToString()) + "','" + (p.UrlName == null ? "" : p.UrlName.Replace("\\", "\\\\")) + "','" + (p.priority == null ? "" : p.priority.ToString()) + "','" + (p.OnvanNamayeshFilm == null ? "" : p.OnvanNamayeshFilm) + "')) return false;"
                       }).ToList();
        var tempds = item_ds.Concat(queryTemp);
        return tempds.OrderByDescending(s => s.priority);
    }
    /// <summary>
    /// حذف ادرس فیلم
    /// </summary>
    /// <param name="p"></param>
    private void Deleteurl(string Id)
    {

        if (!Id.StartsWith("Temp"))
        {
            //var tmp = dc.MediaLinks.SingleOrDefault(s => s.UID.ToString() == Id);
            //if (tmp != null && (tmp.FaaliatKarbarans.Any()))
            //{
            //    ShowErrorMessage("</br>" + "به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
            //    return;
            //}
            hfurlvideo.Value = hfurlvideo.Value.Replace(Id + ",", "");
            return;
        }
        hfurlvideo.Value = hfurlvideo.Value.Replace(Id + ",", "");
        Id = Id.Replace("Temp", "");
        var obj = dc.TempSaves.SingleOrDefault(s => s.UID.ToString() == Id);
        if (obj != null)
        {
            dc.TempSaves.DeleteOnSubmit(obj);
        }
        dc.SubmitChanges();

    }

    private void ClearVideioUrl()
    {
        txtHajm.Text = "";
        cboQuality.SelectedIndex = 0;
        cboNamayeshMediaLink.SelectedIndex = 0;
        txtAddressVideoLink.Text = "";
        txtPriorityLink.Text = "";
        txtOnvanLink.Text = "";
    }

    private void SaveTempVideoUrl()
    {

        {
            var obj = new TempSave();
            obj.UID = Guid.NewGuid();
            obj.Datetime = DateTime.Now;
            obj.Hajm = decimal.Parse("0" + txtHajm.Text.Trim());
            obj.IsShowOnVideo = cboNamayeshMediaLink.SelectedIndex == 1;
            obj.priority = txtPriorityLink.Text.Trim() == "" ? (int?)null : int.Parse("0" + txtPriorityLink.Text.Trim());
            obj.OnvanNamayeshFilm = txtOnvanLink.Text.Trim();
            obj.Quality = dc.Qualities.SingleOrDefault(s => s.Id.ToString() == cboQuality.SelectedValue);
            obj.Type = "MEDIALINK";
            obj.Address = txtAddressVideoLink.Text.Trim().Replace("/", "\\");

            dc.TempSaves.InsertOnSubmit(obj);
            dc.SubmitChanges();
            hfurlvideo.Value += "Temp" + obj.UID + ",";
        }

    }
    /// <summary>
    /// بررسی اطلاعات لینک ویدیو
    /// </summary>
    /// <returns></returns>
    private bool checkValidate_VideoURL()
    {
        bool result = true;
        string Msg = "به نکات زیر توجه نمایید" + "</br>";
        int i = 0;
        decimal Itmp = 0;
        int tmp = 0;
        if (txtHajm.Text.Trim() == "" || !decimal.TryParse("0" + txtHajm.Text.Trim(), out Itmp))
        {
            result = false;
            Msg += (++i).ToString() + " - " + " حجم لینک ویدیو را وارد نمایید" + "</br>";
        }
        if (cboQuality.SelectedIndex == 0)
        {
            result = false;
            Msg += (++i).ToString() + " - " + " کیفیت لینک ویدیو را انتخاب نمایید" + "</br>";
        }
        if (txtPriorityLink.Text.Trim() != "" && !int.TryParse("0" + txtPriorityLink.Text.Trim(), out tmp))
        {
            result = false;
            Msg += (++i).ToString() + " - " + " الویت نمایش لینک را صحیح وارد نمایید" + "</br>";
        }
        if (txtAddressVideoLink.Text.Trim() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "آدرس لینک ویدیو را وارد نمایید" + "</br>";
        }


        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }




}