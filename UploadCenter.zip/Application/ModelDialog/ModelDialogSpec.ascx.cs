﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccsess;

public partial class Application_ModelDialog_ModelDialogSpec : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        litScript_Show_Dialog.Text = "";
        if (!IsPostBack)
        {
            BindCamboBox();
        }
    }

    private void BindCamboBox()
    {
        dbhamyarnetTvDataContext dc=new dbhamyarnetTvDataContext();
        cboQuality_LINKEDIT_DIALOG.DataSource = dc.Qualities.OrderBy(s => s.Priority).ToList();
        cboQuality_LINKEDIT_DIALOG.DataBind();
        cboQuality_LINKEDIT_DIALOG.Items.Insert(0, new ListItem("انتخاب کنید...", ""));
    }
    public void ShowErrorMessage(string msg)
    {
        DIV_CONTENT_TEXT.InnerHtml = msg;
        DIV_TITLE_TEXT.InnerHtml = "خطا";
        DIV_TITLE_TEXT.Style.Add("color", "#f44619");
        DIVLINE_HEADER_CONTENT.Style.Add("background-color", "#f44619");
        Img_Help_ICON_Dialog.ImageUrl = "~/Application/Images/DialogIcon/error-64.png";
        litScript_Show_Dialog.Text = " <script type=\"text/javascript\">   setTimeout(ShowModelDialog, 200); </script> ";
        DIV_FORGOT_PASSWORD_DIALOG_INFO.Style.Add("display", "none");
    }
    public void ShowInfoMessage(string msg)
    {
        DIV_CONTENT_TEXT.InnerHtml = msg;
        DIV_TITLE_TEXT.InnerHtml = "اطلاعات";
        DIV_TITLE_TEXT.Style.Add("color", "#19b2e8");
        DIVLINE_HEADER_CONTENT.Style.Add("background-color", "#19b2e8");
        Img_Help_ICON_Dialog.ImageUrl = "~/Application/Images/DialogIcon/help-64.png";
        litScript_Show_Dialog.Text = " <script type=\"text/javascript\">   setTimeout(ShowModelDialog, 200); </script> ";
        DIV_FORGOT_PASSWORD_DIALOG_INFO.Style.Add("display", "none");
    }
    public void ShowSeccessMessage(string msg)
    {

        DIV_CONTENT_TEXT.InnerHtml = msg;
        DIV_TITLE_TEXT.InnerHtml = "پیام";
        DIV_TITLE_TEXT.Style.Add("color", "green");
        DIVLINE_HEADER_CONTENT.Style.Add("background-color", "green");
        Img_Help_ICON_Dialog.ImageUrl = "~/Application/Images/DialogIcon/ok-64.png";
        litScript_Show_Dialog.Text = " <script type=\"text/javascript\">   setTimeout(ShowModelDialog, 200); </script> ";
        DIV_FORGOT_PASSWORD_DIALOG_INFO.Style.Add("display", "none");
    }

    public string GetEmailFromForgatPassword()
    {
        return txtbox_EMAIL_DIALOG.Text.Trim();
    }
    public string GetTextArea()
    {

        return txtMessage.InnerText.Trim();
    }

    public string GET_Hajm_EDITLINK()
    {
        return txtHajm_LINKEDIT_DIALOG.Text.Trim();
    }
    public string GET_Priority_EDITLINK()
    {
        return txtPriorityLink_LINKEDIT_DIALOG.Text.Trim();
    }
    public string GET_AdressLink_EDITLINK()
    {
        return txtAddressVideoLink_LINKEDIT_DIALOG.Text.Trim();
    }
    public string GET_Onvan_EDITLINK()
    {
        return txtOnvanLink_LINKEDIT_DIALOG.Text.Trim();
    }
    public string GET_QualityID_EDITLINK()
    {
        return cboQuality_LINKEDIT_DIALOG.SelectedValue;
    }
    public bool GET_NAmayeshDarVidio_EDITLINK()
    {
        return cboNamayeshMediaLink_LINKEDIT_DIALOG.SelectedIndex==1;
    }

}