﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccsess;
public partial class convert : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
        int cnt = 0;

        foreach (var q in dc.MediaLinks)
        {
            cnt++;
            if (q.UrlName != null)
                q.UrlName = q.UrlName.Trim().Replace("/", "\\");

            if (cnt > 300)
            {
                cnt = 0;
                dc.SubmitChanges();

            }
        }
        dc.SubmitChanges();


    }
}