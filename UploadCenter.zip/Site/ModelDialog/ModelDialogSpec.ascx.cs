﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Site_ModelDialog_ModelDialogSpec : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        litScript_Show_Dialog.Text = "";
       
    }
    public void ShowErrorMessage(string msg)
    {
        DIV_CONTENT_TEXT.InnerHtml = msg;
        DIV_TITLE_TEXT.InnerHtml = "خطا";
        DIV_TITLE_TEXT.Style.Add("color", "#f44619");
        DIVLINE_HEADER_CONTENT.Style.Add("background-color", "#f44619");
        Img_Help_ICON_Dialog.ImageUrl = "~/Site/Images/DialogIcon/error-64.png";
        litScript_Show_Dialog.Text = " <script type=\"text/javascript\">   setTimeout(ShowModelDialog, 200); </script> ";
        DIV_FORGOT_PASSWORD_DIALOG_INFO.Style.Add("display", "none");
    }
    public void ShowInfoMessage(string msg)
    {
        DIV_CONTENT_TEXT.InnerHtml = msg;
        DIV_TITLE_TEXT.InnerHtml = "اطلاعات";
        DIV_TITLE_TEXT.Style.Add("color", "#19b2e8");
        DIVLINE_HEADER_CONTENT.Style.Add("background-color", "#19b2e8");
        Img_Help_ICON_Dialog.ImageUrl = "~/Site/Images/DialogIcon/help-64.png";
        litScript_Show_Dialog.Text = " <script type=\"text/javascript\">   setTimeout(ShowModelDialog, 200); </script> ";
        DIV_FORGOT_PASSWORD_DIALOG_INFO.Style.Add("display", "none");
    }
    public void ShowSeccessMessage(string msg)
    {

        DIV_CONTENT_TEXT.InnerHtml = msg;
        DIV_TITLE_TEXT.InnerHtml = "پیام";
        DIV_TITLE_TEXT.Style.Add("color", "green");
        DIVLINE_HEADER_CONTENT.Style.Add("background-color", "green");
        Img_Help_ICON_Dialog.ImageUrl = "~/Site/Images/DialogIcon/ok-64.png";
        litScript_Show_Dialog.Text = " <script type=\"text/javascript\">   setTimeout(ShowModelDialog, 200); </script> ";
        DIV_FORGOT_PASSWORD_DIALOG_INFO.Style.Add("display", "none");
    }

    public string GetEmailFromForgatPassword()
    {
        return txtbox_EMAIL_DIALOG.Text.Trim();
    }
    public string GetTextArea()
    {

        return txtMessage.InnerText.Trim();
    }

}