﻿using DataAccsess;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Site_Pages_ShowImage : System.Web.UI.Page
{

    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        string mode = ArssPayamUtility.GetQueryString("mode", Request.QueryString["args"]);
        string url = ArssPayamUtility.GetQueryString("URL", Request.QueryString["args"]);
        string useslidebar = ArssPayamUtility.GetQueryString("useslidebar", Request.QueryString["args"]);

        if (mode == "image" && useslidebar == "true" && (url == null || string.IsNullOrEmpty(url.Trim()) || !File.Exists(url)))
        {
            url = Server.MapPath("~/Site/Images/Master/transparent.png");
        }
        WriteFile(mode, url);


    }

    private void WriteFile(string mode, string url)
    {
        if (mode == "image")
        {
            if (!string.IsNullOrEmpty(url))
                if (File.Exists(url))
                    Response.WriteFile(url);
        }
        else if (mode == "video")
        {
            PlayVideo(url);




        }
    }

    private void PlayVideo(string url)
    {
       // url = @"D:\shervin\Hamyarnet\WEB\UploadCenter\s.mp4";
        if (!string.IsNullOrEmpty(url) && File.Exists(url))
        {
            
            System.IO.FileInfo fileInfo_tmp = new System.IO.FileInfo(url);
            int bufferRead_ = fileInfo_tmp.Length > 700612245 ? 40960000 : (fileInfo_tmp.Length > 40612245 ? 409600 : 40960);
            ////Response.AppendHeader("content-disposition", "attachment; filename=" + "hi.mp4");
            //Response.ContentType = "application/octet-stream";

            //Response.WriteFile(url);
            //Response.End();

            if (fileInfo_tmp.Length < 100612245)
            {
                System.IO.FileInfo fileInfo = new System.IO.FileInfo(url);
                string MediaName = Path.GetFileName(url);
                Response.Clear();
                Response.AppendHeader("content-disposition",
                " filename=" + MediaName.Replace(" ", "_"));
                Response.AddHeader("Content-Length", fileInfo.Length.ToString());
                Response.ContentType = "application/octet-stream";//"video/mp4";//
                Response.Flush();
                Response.TransmitFile(fileInfo.FullName);
                Response.End();

            }
            else
            {
                System.IO.Stream iStream = null;
                byte[] buffer = new Byte[bufferRead_];
                int length;
                long dataToRead;

                try
                {
                    // Open the file.
                    iStream = new System.IO.FileStream(url, System.IO.FileMode.Open,
                                System.IO.FileAccess.Read, System.IO.FileShare.Read);


                    // Total bytes to read:
                    dataToRead = iStream.Length;


                    HttpContext.Current.Response.AddHeader("Accept-Ranges", "bytes");
                    HttpContext.Current.Response.ContentType = "video/mp4";//MimeType.GetMIMEType(Path.GetFileName(url));

                    int startbyte = 0;

                    if (!String.IsNullOrEmpty(Request.Headers["Range"]))
                    {
                        string[] range = Request.Headers["Range"].Split(new char[] { '=', '-' });
                        startbyte = Int32.Parse(range[1]);
                        iStream.Seek(startbyte, SeekOrigin.Begin);

                        HttpContext.Current.Response.StatusCode = 206;
                        HttpContext.Current.Response.AddHeader("Content-Range", String.Format(" bytes {0}-{1}/{2}", startbyte, dataToRead - 1, dataToRead));

                    }

                    if (Validation.IsBrowser("Chrome"))
                    {
                        if (dataToRead > 0)
                        {
                            // Verify that the client is connected.
                            if (HttpContext.Current.Response.IsClientConnected)
                            {

                                // Read the data in buffer.
                                length = iStream.Read(buffer, 0, buffer.Length);

                                // Write the data to the current output stream.
                                HttpContext.Current.Response.OutputStream.Write(buffer, 0, buffer.Length);
                                // Flush the data to the HTML output.

                                HttpContext.Current.Response.Flush();


                                buffer = new Byte[buffer.Length];
                                dataToRead = dataToRead - buffer.Length;
                            }
                            else
                            {
                                //prevent infinite loop if user disconnects
                                dataToRead = -1;
                            }
                        }
                    }
                    else
                    {
                        //Firefox, opera, safari,IE
                        while (dataToRead > 0)
                        {
                            // Verify that the client is connected.
                            if (HttpContext.Current.Response.IsClientConnected)
                            {

                                // Read the data in buffer.
                                length = iStream.Read(buffer, 0, buffer.Length);

                                // Write the data to the current output stream.
                                HttpContext.Current.Response.OutputStream.Write(buffer, 0, buffer.Length);
                                // Flush the data to the HTML output.

                                HttpContext.Current.Response.Flush();


                                buffer = new Byte[buffer.Length];
                                dataToRead = dataToRead - buffer.Length;
                            }
                            else
                            {
                                //prevent infinite loop if user disconnects
                                dataToRead = -1;
                            }
                        }

                    }


                }
                catch (Exception ex)
                {
                    // Trap the error, if any.
                    HttpContext.Current.Response.Write("Error : " + ex.Message);
                }
                finally
                {
                    if (iStream != null)
                    {
                        //Close the file.
                        iStream.Close();
                    }
                    HttpContext.Current.Response.Close();
                    HttpContext.Current.Response.End();
                }
            }
        }
    }
}