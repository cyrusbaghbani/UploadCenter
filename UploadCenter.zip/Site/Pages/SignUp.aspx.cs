﻿using DataAccsess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Site_Pages_SignUp : PrimeryPage
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            Display();
        }
         Access();
    }
    protected void btnSabt_Click(object sender, ImageClickEventArgs e)
    {
        if (CheckValidate())
        {
            Save();
            ShowSeccessMessage("اطلاعات با موفقیت ثبت گردید");
        }
    }

    private void Access()
    {
        if (CurrentUser == null)
            Response.Redirect("~/main.aspx");

        DIV_UserHamyarnet.Visible = CurrentUser.UserTypeId == (int)UserTypeIds.MoshtarakHamyarnet;
        Div_UserHamyarTV.Visible = CurrentUser.UserTypeId != (int)UserTypeIds.MoshtarakHamyarnet;
    }
    private void Display()
    {
        if (CurrentUser == null)
            return;
        if (CurrentUser.UserTypeId == (int)UserTypeIds.MoshtarakHamyarnet)
        {
            Form.DefaultButton = btnDosentWork.UniqueID;
            txt_Email_Hamyarnet.Text = CurrentUser.Email;
            txt_FullName_Hamyarnet.Text = CurrentUser.FullName;
            txt_ShomareTel_Hamyarnet.Text = CurrentUser.Telephone;
            txt_Username_Hamyarnet.Text = CurrentUser.UserName;

        }
        else
        {
            Form.DefaultButton = btnSabt.UniqueID;
            txt_Username_HamyarTv.Text = CurrentUser.UserName;
            txt_Name_HamyarTV.Text = CurrentUser.FirstName;
            txt_Family_HamyarTV.Text = CurrentUser.LastName;
            txt_ShomareTel_HamyarTv.Text = CurrentUser.Mobile;
        }
    }

    /// <summary>
    /// بررسی ثبت نام
    /// </summary>
    /// <returns></returns>
    private bool CheckValidate()
    {
        string Msg = "لطفا به نکات زیر توجه نمایید :" + "</br>";
        bool result = true;
        int i = 0;
        if (txt_Name_HamyarTV.Text.Trim() == "" || txt_Name_HamyarTV.Text.Trim() == "اجباری")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "نام را وارد نمایید." + "</br>";
        }
        if (txt_Family_HamyarTV.Text.Trim() == "" || txt_Family_HamyarTV.Text.Trim() == "اجباری")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "نام خانوادگی را وارد نمایید." + "</br>";
        }
        if (txt_ShomareTel_HamyarTv.Text.Trim() != ""
            &&
            txt_ShomareTel_HamyarTv.Text.Trim().Length != 11
            )
        {
            result = false;
            Msg += (++i).ToString() + " - " + "شماره همراه را صحیح و کامل وارد نمایید." + "</br>";
        }

        if (txt_Password_New.Text != "" || txt_PassWord_Old.Text != "" || txt_RePassword_New.Text != "")
        {
            if (CurrentUser.Password != EncryptedQueryString.GetMD5Hash(txt_PassWord_Old.Text))
            {
                result = false;
                Msg += (++i).ToString() + " - " + "کلمه عبور قبلی اشتباه می باشد." + "</br>";
            }
            if (txt_Password_New.Text == "" && txt_RePassword_New.Text == "")
            {
                result = false;
                Msg += (++i).ToString() + " - " + "کلمه عبور جدید را وارد نمایید." + "</br>";
            }
            else if (txt_Password_New.Text.Length < 6)
            {
                result = false;
                Msg += (++i).ToString() + " - " + "کلمه عبور جدید باید حداقل دارای 6 حرف باشد." + "</br>";
            }
            else if (txt_Password_New.Text != txt_RePassword_New.Text )
            {
                result = false;
                Msg += (++i).ToString() + " - " + "کلمه عبور جدید با تکرار آن برابر نمی باشد." + "</br>";
            }
            
        }

        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }
    /// <summary>
    /// ذخیره کاربر 
    /// </summary>
    private void Save()
    {

        var obj = dc._Users.FirstOrDefault(s => s.UID == CurrentUser.UID);
        obj.FirstName = txt_Name_HamyarTV.Text.Trim();
        obj.LastName = txt_Family_HamyarTV.Text.Trim();
        obj.Telephone = obj.Mobile = txt_ShomareTel_HamyarTv.Text.Trim();
        if (txt_Password_New.Text != "")
            obj.Password = EncryptedQueryString.GetMD5Hash(txt_Password_New.Text);

        bool Ischange = dc.GetChangeSet().Updates.Any();
        dc.SubmitChanges();
        Session["userhamyartv"] = obj;
        if (Ischange)
            EventLoger.LogEvent("کاربر '" + obj.FullName + "' با نام کاربری '" + obj.UserName + "' مشخصات خود را ویرایش نمود.", (int)EventTypeIds.virayesh, CurrentUser.UID);



    }
}