﻿using DataAccsess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Site_Pages_Downloadspec : PrimeryPage
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        if (!string.IsNullOrEmpty(ID))
        {
            Downlaod(ID);
        }
    }

    private void Downlaod(string linkid)
    {
        var link = dc.MediaLinks.SingleOrDefault(s => s.UID.ToString() == linkid);
        if (link != null)
        {

            System.IO.FileInfo fileInfo = new System.IO.FileInfo(link.UrlName);
            if (fileInfo.Exists)
            {
                

                Response.Clear();
                Response.AppendHeader("content-disposition",
                "attachment; filename=" + link.MediaName.Replace(" ", "_") + "." + link.ExtentionMedia);
                Response.AddHeader("Content-Length", fileInfo.Length.ToString());
                Response.ContentType = "application/octet-stream";//"video/mp4";//
                Response.Flush();
                Response.TransmitFile(fileInfo.FullName);
                Response.End();
            }
        }
    }
}