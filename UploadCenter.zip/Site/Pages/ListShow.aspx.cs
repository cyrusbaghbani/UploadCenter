﻿using DataAccsess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Site_Pages_ListShow : System.Web.UI.Page
{
    public static string Filter = "/Site/Images/Master/Filter.png";

    public string mode = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        hfvalueskape.Value = "0";
        SetParametrAvalie();
        SetScriptForFlipFlop();
        SetImageOfTitle();
    }

    private void SetImageOfTitle()
    {
        int tmp = 0;
        imgtitle.ImageUrl = "~/site/images/text_control/" + ArssPayamHelp.GetNameOfDatebandiTitleImage(int.TryParse(mode, out tmp) ? tmp : (int?)null);

    }

    private void SetScriptForFlipFlop()
    {
        litflipflopScript.Text = "";
        liscript_Top.Text = "";
        if (IsBrowserIEVersoinLower9())
        {
            hfBrowserIsLowerDownIe9.Value = "true";

            liscript_Top.Text = " <script src=\"../CardJq/jquery.js\"></script> "
                            + "     <script src=\"../CardJq/jquery.quickflip.min.js\"></script> ";

            litflipflopScript.Text += " <script type=\"text/javascript\"> "
                                    + " function quickFliphoverevent() { "
                                    + "    $('.quickFlip').hover(function (ev) { "
                                    + "        var $target = $(ev.target); "
                                    + "        if ($target.hasClass('FILTERFLIPFLOPTEMpCLASS_JASTISNAME')) { "
                                    + "             $target = $target.parent(); "
                                    + "        } "
                                    + "       if (!$target.hasClass('quickFlip')) $target = $target.parent(); "
                                    + "      $target.quickFlipper(); "
                                    + "   }, function () { }); "
                                    + " } "
                                    + "  </script> ";
        }
        else
        {
            hfBrowserIsLowerDownIe9.Value = "false";
            liscript_Top.Text = " <script src=\"../FlipFlopCardIE9/jquery.flip.js\"></script> "
                            + "     <script src=\"../FlipFlopCardIE9/flip.js\"></script> ";

            litflipflopScript.Text += " <script type=\"text/javascript\"> "
                                   + " function quickFliphoverevent() { "
                //    + " $(function () {  "
                                   + "   $(\".quickFlip\").flip({ "
                                   + "    trigger: \"hover\" "
                                   + "     }); "
                //  + " }); "
                                   + " } "
                                   + " </script> ";

        }
    }
    /// <summary>
    /// بررسی میکند که ورژن بروزر استفاده شده است اینترنت اکسپلرور کمتر از از 9 است یانه
    /// زیرا زیر این ورزن بعضی از کدها جواب داده نمی شود
    /// </summary>
    /// <returns></returns>
    bool IsBrowserIEVersoinLower9()
    {

        if (Request.Browser.Type.ToUpper().Contains("IE")) // replace with your check
        {
            if (Request.Browser.MajorVersion < 9)
            {
                return true;
            }
        }
        return false;
    }

    /// <summary>
    /// مقادیر اولیه را گرفته و بارگزاری می کند
    /// </summary>
    private void SetParametrAvalie()
    {
        dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
        hfqurystring.Value = Request.QueryString["args"];
        mode = ArssPayamUtility.GetQueryString("mode", Request.QueryString["args"]);
        string namfilm = ArssPayamUtility.GetQueryString("namfilm", Request.QueryString["args"]);
        string zhanr = ArssPayamUtility.GetQueryString("zhanr", Request.QueryString["args"]);
        string avamelfilm = ArssPayamUtility.GetQueryString("avamelfilm", Request.QueryString["args"]);
        int tmp = 0;
        int? salaz = int.TryParse("" + ArssPayamUtility.GetQueryString("salaz", Request.QueryString["args"]), out tmp) ? tmp : (int?)null;
        int? salta = int.TryParse("" + ArssPayamUtility.GetQueryString("salta", Request.QueryString["args"]), out tmp) ? tmp : (int?)null;
        DIv_SearchFilm.Visible = !int.TryParse(mode, out tmp);

        List<int> lstzhanr = new List<int>();
        if (zhanr != null && zhanr.Trim() != "")
        {
            foreach (var zhid in zhanr.Split(',').ToList())
            {
                if (int.TryParse(zhid, out tmp))
                    lstzhanr.Add(tmp);
            }
        }
        string searchresult = "";
        if (!string.IsNullOrEmpty(namfilm))
            searchresult += "نام فیلم : " + namfilm;
        if (!string.IsNullOrEmpty(avamelfilm))
            searchresult += (string.IsNullOrEmpty(searchresult) ? "" : " / ") + "عوامل فیلم : " + avamelfilm;
        if (lstzhanr.Any())
            searchresult += (string.IsNullOrEmpty(searchresult) ? "" : " / ") + "ژانر : " + dc.Zhanrs.Where(p => lstzhanr.Contains(p.Id)).Select(s => s.Name).ToList().Aggregate((a, b) => a + ", " + b);

        if (salaz != null && salta != null && salaz == salta)
            searchresult += (string.IsNullOrEmpty(searchresult) ? "" : " / ") + "سال ساخت " + salaz;
        else if (salaz != null && salta != null)
            searchresult += (string.IsNullOrEmpty(searchresult) ? "" : " / ") + "سال ساخت از " + salaz + " تا سال " + salta;
        else if (salaz != null && salta == null)
            searchresult += (string.IsNullOrEmpty(searchresult) ? "" : " / ") + "سال ساخت " + salaz + " و به بعد";
        else if (salaz == null && salta != null)
            searchresult += (string.IsNullOrEmpty(searchresult) ? "" : " / ") + "سال ساخت " + salta + " و ماقبل";

        DIv_SearchFilm.InnerHtml = searchresult;
    }


    [System.Web.Services.WebMethod]
    public static string LoadListViewItem(string skape, string IsBrowserIEVersoinLower9, string value_querystring)
    {
        int num = int.Parse(skape);
        return GetItem(num, Convert.ToBoolean(IsBrowserIEVersoinLower9), value_querystring);
    }

    private static string GetItem(int num, bool IsBrowserIEVersoinLower9,string value_querystring)
    {

        string _mode = "";
        string namfilm = "";
        List<int> lstzhanr = new List<int>();
        string avamelfilm = "";
        int? salaz = null;
        int? salta = null;


        _mode = ArssPayamUtility.GetQueryString("mode", value_querystring);
        namfilm = ArssPayamUtility.GetQueryString("namfilm", value_querystring);
        string zhanr = ArssPayamUtility.GetQueryString("zhanr", value_querystring);
        avamelfilm = ArssPayamUtility.GetQueryString("avamelfilm", value_querystring);
        int tmp = 0;
        salaz = int.TryParse("" + ArssPayamUtility.GetQueryString("salaz", value_querystring), out tmp) ? tmp : (int?)null;
        salta = int.TryParse("" + ArssPayamUtility.GetQueryString("salta", value_querystring), out tmp) ? tmp : (int?)null;
      

        lstzhanr = new List<int>();
        if (zhanr != null && zhanr.Trim() != "")
        {
            foreach (var zhid in zhanr.Split(',').ToList())
            {
                if (int.TryParse(zhid, out tmp))
                    lstzhanr.Add(tmp);
            }
        }


        //
        Random r = new Random();
        string msg = "";
        List<Media> lst = new List<Media>();

        int? DastebandiId = int.TryParse(_mode, out tmp) ? tmp : (int?)null;

        dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
        if (IsBrowserIEVersoinLower9)
        {
            if (DastebandiId != null && DastebandiId == (int)DastebandiTypeIds.Daghtarin)
            {
                int DownloadsIds = (int)FaaliatTypeIds.Download;
                int Bazdidids = (int)FaaliatTypeIds.Bazdid;
                lst = dc.Medias.Where(s => s.IsShowMediaInSite == true).OrderByDescending(s => s.MediaLinks.Sum(t => t.FaaliatKarbarans.Count(p => p.FaaliatTypeId == DownloadsIds || p.FaaliatTypeId == Bazdidids))).ThenByDescending(s => s.SalSakht).ThenBy(s => s.Priority).Take((num + 1) * 6).ToList();
            }
            else if (DastebandiId != null && DastebandiId == (int)DastebandiTypeIds.Jadidtarin)
            {
                lst = dc.Medias.Where(s=>s.IsShowMediaInSite == true).OrderByDescending(s => s.SalSakht).ThenBy(s => s.Priority).Take((num + 1) * 6).ToList();
            }
            else if (DastebandiId != null)
            {
                lst = dc.Medias.Where(s =>s.IsShowMediaInSite == true&& s.Dastebandis.Any(t => t.DastebandiTypeId == DastebandiId.Value)).OrderByDescending(s => s.SalSakht).ThenBy(s => s.Priority).Take((num + 1) * 6).ToList();
            }
            else
            {
                List<string> lstnamFilm = (namfilm == null || namfilm.Trim() == "") ? new List<string>() : namfilm.Trim().Split(' ').Where(s => s != null && s.Trim() != "").ToList();
                List<string> lstavamelfilm = (avamelfilm == null || avamelfilm.Trim() == "") ? new List<string>() : avamelfilm.Trim().Split(' ').Where(s => s != null && s.Trim() != "").ToList();
                var lsttemp = (from p in dc.Medias
                               where
                               p.IsShowMediaInSite == true
                               &&
                               (
                               lstzhanr.Count == 0
                               ||
                               (p.MediaZhanrs.Any(s => lstzhanr.Contains(s.ZhanrId)))
                               )
                               &&
                               (
                                    (
                                        (salaz == null || (p.SalSakht != null && p.SalSakht >= salaz))
                                        &&
                                        (salta == null || (p.SalSakht != null && p.SalSakht <= salta))
                                    )
                               ||
                                   (
                                        (salta == null || (p.SalSakhtMiladi != null && p.SalSakhtMiladi >= salaz))
                                        &&
                                        (salta == null || (p.SalSakhtMiladi != null && p.SalSakhtMiladi <= salta))
                                   )
                               )
                               select p).ToList();
                lst = (from p in lsttemp
                       where
                       (lstnamFilm.Count == 0 || (p.Name != null && lstnamFilm.Any(t => p.NameKeyword.ToLower().Contains(t.ToLower()))))
                       &&
                       (lstavamelfilm.Count == 0 || (p.AvamelFilm != null && lstavamelfilm.Any(t => p.AvamelFilmKeyword.ToLower().Contains(t.ToLower()))))
                       select new
                        {
                            countName = lstnamFilm.Count(s => p.NameKeyword.ToLower().Contains(s.ToLower())),
                            countAvamelfilm = lstavamelfilm.Count(s => p.AvamelFilmKeyword.ToLower().Contains(s.ToLower())),
                            countzhanr = p.MediaZhanrs.Count(s => lstzhanr.Contains(s.ZhanrId)),
                            p
                        }).OrderByDescending(s => s.countName).ThenByDescending(s => s.countAvamelfilm).ThenByDescending(s => s.p.SalSakht).ThenByDescending(s => s.countzhanr).ThenBy(s => s.p.Priority).Select(s => s.p).Take((num + 1) * 6).ToList();

            }

            if (!lst.Skip(num * 6).Any())
                return "";
            foreach (var l in lst)
            {
                string Address = ArssPayamUtility.GetEncodedQueryString("ShowTime.aspx?args={0}", "ID=" + l.UID + "&TEMP__=" + Guid.NewGuid());
                msg += " <div class=\"Div-Panel-Item\" style=\"margin-right:12px;margin-left:12px;\" > "
                        + " <a href=\"" + Address + "\"> "
                        + " <div  class=\"quickFlip\"  >"
                        + "  <div  class=\"panel1 front\"  style=\"background-image: url('"
                        + ArssPayamUtility.GetEncodedQueryString("ShowImage.aspx?args={0}", "URL="
                        + (l.UrlAxJeloCard == null ? "" : l.UrlAxJeloCard)
                        + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image")
                        + "');\"> "
                        + " &nbsp; "
                        + " </div> "
                        + "     <div  class=\"panel2 back\" style=\"background-image: url('"
                        + ArssPayamUtility.GetEncodedQueryString("ShowImage.aspx?args={0}", "URL="
                        + (l.UrlAxPoshtCard == null ? "" : l.UrlAxPoshtCard)
                        + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image")
                        + "');\" > ";
                if (l.IsUseFilterForPoshtJesld)
                    msg += "  <div class=\"FILTERFLIPFLOPTEMpCLASS_JASTISNAME\" style=\"background-image: url('" + Filter + "');width:100%;height:100% \" > ";
                msg += " &nbsp; " + (l.Dsc_PoshtCard == null ? "" : l.Dsc_PoshtCard.Replace("\n", "</br>")) + " ";
                if (l.IsUseFilterForPoshtJesld)
                    msg += "     </div> ";
                msg += "     </div> "
                    + " </div> "
                    + " <div class=\"BreakDiv1\"></div> "
                    + " <div class=\"Div_Panel_Item_Label\"> "
                    + "  " + l.Name
                    + " </div> "
                    + " </a> "
                    + " </div> ";
            }


        }
        else
        {
            if (DastebandiId != null && DastebandiId == (int)DastebandiTypeIds.Daghtarin)
            {
                int DownloadsIds = (int)FaaliatTypeIds.Download;
                lst = dc.Medias.Where(s => s.IsShowMediaInSite == true).OrderByDescending(s => s.MediaLinks.Sum(t => t.FaaliatKarbarans.Count(p => p.FaaliatTypeId == DownloadsIds))).ThenByDescending(s => s.SalSakht).ThenBy(s => s.Priority).Skip((num) * 6).Take(6).ToList();
            }
            else if (DastebandiId != null && DastebandiId == (int)DastebandiTypeIds.Jadidtarin)
            {
                lst = dc.Medias.Where(s=>s.IsShowMediaInSite == true).OrderByDescending(s => s.SalSakht).ThenBy(s => s.Priority).Skip((num) * 6).Take(6).ToList();
            }
            else if (DastebandiId != null)
            {
                lst = dc.Medias.Where(s => s.IsShowMediaInSite == true).Where(s => s.Dastebandis.Any(t => t.DastebandiTypeId == DastebandiId.Value)).OrderByDescending(s => s.SalSakht).ThenBy(s => s.Priority).Skip((num) * 6).Take(6).ToList();
            }
            else
            {
                List<string> lstnamFilm = (namfilm == null || namfilm.Trim() == "") ? new List<string>() : namfilm.Trim().Split(' ').Where(s => s != null && s.Trim() != "").ToList();
                List<string> lstavamelfilm = (avamelfilm == null || avamelfilm.Trim() == "") ? new List<string>() : avamelfilm.Trim().Split(' ').Where(s => s != null && s.Trim() != "").ToList();
                var lsttmp = (from p in dc.Medias
                              where
                              p.IsShowMediaInSite == true
                              &&
                              (lstzhanr.Count == 0 || (p.MediaZhanrs.Any(s => lstzhanr.Contains(s.ZhanrId))))
                              &&
                              (salaz == null || (p.SalSakht != null && p.SalSakht >= salaz) || (p.SalSakhtMiladi != null && p.SalSakhtMiladi >= salaz))
                              &&
                              (salta == null || (p.SalSakht != null && p.SalSakht <= salta) || (p.SalSakhtMiladi != null && p.SalSakhtMiladi <= salta))
                              select p).ToList();
                lst = (from p in lsttmp
                       where
                       (lstnamFilm.Count == 0 || (p.Name != null && lstnamFilm.Any(t => p.NameKeyword.ToLower().Contains(t.ToLower()))))
                       &&
                       (lstavamelfilm.Count == 0 || (p.AvamelFilm != null && lstavamelfilm.Any(t => p.AvamelFilmKeyword.ToLower().Contains(t.ToLower()))))
                       select new
                       {
                           countName = lstnamFilm.Count(s => p.NameKeyword.ToLower().Contains(s.ToLower())),
                           countAvamelfilm = lstavamelfilm.Count(s => p.AvamelFilmKeyword.ToLower().Contains(s.ToLower())),
                           countzhanr = p.MediaZhanrs.Count(s => lstzhanr.Contains(s.ZhanrId)),
                           p
                       }).OrderByDescending(s => s.countName).ThenByDescending(s => s.countAvamelfilm).ThenByDescending(s => s.p.SalSakht).ThenByDescending(s => s.countzhanr).ThenBy(s => s.p.Priority).Select(s => s.p).Skip((num) * 6).Take(6).ToList();
            }

            foreach (var l in lst)
            {
                string Address = ArssPayamUtility.GetEncodedQueryString("ShowTime.aspx?args={0}", "ID=" + l.UID + "&TEMP__=" + Guid.NewGuid());
                msg += " <div class=\"Div-Panel-Item\" style=\"margin-right:12px;margin-left:12px;\" > "
                        + " <a href=\"" + Address + "\"> "
                        + " <div  class=\"quickFlip\"  >"
                        + "  <div  class=\"panel1 front\"  style=\"background-image: url('"
                        + ArssPayamUtility.GetEncodedQueryString("ShowImage.aspx?args={0}", "URL="
                        + (l.UrlAxJeloCard == null ? "" : l.UrlAxJeloCard)
                        + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image")
                        + "');\" > "
                        + " &nbsp; "
                        + " </div> "
                        + "     <div  class=\"panel2 back\" style=\"background-image: url('"
                        + ArssPayamUtility.GetEncodedQueryString("ShowImage.aspx?args={0}", "URL="
                        + (l.UrlAxPoshtCard == null ? "" : l.UrlAxPoshtCard)
                        + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image")
                        + "');\" > ";
                if (l.IsUseFilterForPoshtJesld)
                    msg += "  <div class=\"FILTERFLIPFLOPTEMpCLASS_JASTISNAME\" style=\"background-image: url('" + Filter + "');width:100%;height:100% \" > ";
                msg += " &nbsp; " + (l.Dsc_PoshtCard == null ? "" : l.Dsc_PoshtCard.Replace("\n", "</br>")) + " ";
                if (l.IsUseFilterForPoshtJesld)
                    msg += "     </div> ";
                msg += "     </div> "
                    + " </div> "
                    + " <div class=\"BreakDiv1\"></div> "
                    + " <div class=\"Div_Panel_Item_Label\"> "
                    + "  " + l.Name
                    + " </div> "
                    + " </a> "
                    + " </div> ";
            }
        }
        return msg;
    }

}