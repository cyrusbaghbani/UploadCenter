﻿using DataAccsess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Site_Pages_ShowTime : PrimeryPage
{

    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
            DisplayPage();
        LoadComments();
        Access();


    }
    protected void lstviewNazarat_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        if (e.CommandName == "PASOKH")
        {
            string message = "";
            if (GetTextArea().Trim() == "")
            {
                message = "ShowErrorMessage('</br>  لطفا نظر خود را وارد نمایید');";
                ScriptManager.RegisterClientScriptBlock(sender as Control, this.GetType(), "alert", message, true);
                return;
            }
            SaveNazar(e.CommandArgument.ToString());
            LoadComments();
            message = "ShowSeccessMessage('نظر شما با موفقیت ثبت گردید.');";
            ScriptManager.RegisterClientScriptBlock(sender as Control, this.GetType(), "alert", message, true);
        }
    }
    protected void btnSabtNazarJadid_Click(object sender, EventArgs e)
    {
        string message = "";
        if (GetTextArea().Trim() == "")
        {
            message = "ShowErrorMessage('</br>  لطفا نظر خود را وارد نمایید');";
            ScriptManager.RegisterClientScriptBlock(sender as Control, this.GetType(), "alert", message, true);
            return;
        }
        SaveNazar();
        LoadComments();
        message = "ShowSeccessMessage('نظر شما با موفقیت ثبت گردید.</br>  پس از تایید توسط مدیر سیستم نظر شما نمایش داده می شود.');";
        ScriptManager.RegisterClientScriptBlock(sender as Control, this.GetType(), "alert", message, true);
    }
    protected void lstviewNazarat_DataBound(object sender, EventArgs e)
    {
        AddbtnToUploadPannel_Commnets();
    }

    private void DisplayPage()
    {
        ShowGallery(true);


        Div_Control.Visible = false;
        bool IsSafari = Validation.IsBrowser("Safari");
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var media_ = dc.Medias.SingleOrDefault(s => s.IsShowMediaInSite == true && s.UID.ToString() == ID);
        if (media_ == null)
            returnTomainPage();

        Div_PardeNamayesh.InnerHtml = "پرده نمایش : &nbsp;&nbsp;" + media_.Name;


        int countduration = 0;
        if (media_.MediaTime != null && media_.MediaTime.Trim() != "")
        {
            lblduration.Text = media_.MediaTime;
            lblcurrentTime.Text = media_.MediaTime.Length > 5 ? "0:00:00" : "00:00";
            string[] time = media_.MediaTime.Split(':');
            int sec = 1;
            for (int i = time.Count() - 1; i >= 0; i--)
            {

                countduration += int.Parse("0" + time[i]) * sec;
                sec *= 60;
            }
        }

        var ds_keyfiat = (from p in dc.MediaLinks
                          where
                          p.MediaId == media_.UID
                          &&
                          p.qualityId != null
                          select new
                          {
                              Id = p.UID,
                              IDNAME = "btnKeyfiat" + p.UID.ToString().Replace("-", "_"),
                              cssclass = (p.UID.ToString() == hfLinkID.Value ? "DropDownItemBoxactive" : "DropDownItemBox"),
                              Name = p.Quality.Name,
                              priority = p.Quality.Priority,
                              UrlName = p.UrlName == null ? "" : p.UrlName,
                              p.MediaId,
                              p.IsShowOnVideo
                          }).ToList();
        var ds_keyfiat2 = (from p in ds_keyfiat

                           select new
                           {
                               p.Id,
                               p.IDNAME,
                               p.cssclass,
                               p.Name,
                               p.IsShowOnVideo,
                               p.priority,
                               script = "ChangeVideo('" + (IsBrowserIEVersoinLowerEqual9() ? p.UrlName.Replace(Request.ServerVariables["APPL_PHYSICAL_PATH"], String.Empty) :
                               (ArssPayamUtility.GetEncodedQueryString("ShowImage.aspx?args={0}", "URL="
                                + p.UrlName
                                + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=video"))
                                ) + "','" + p.MediaId + "',this);  return false;",
                               urlshowimage = (ArssPayamUtility.GetEncodedQueryString("ShowImage.aspx?args={0}", "URL="
                               + p.UrlName
                               + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=video")),
                               urlPath = p.UrlName.Replace(Request.ServerVariables["APPL_PHYSICAL_PATH"], String.Empty),
                           }).ToList();
        lstboxKeyfiat.DataSource = ds_keyfiat2.Where(s => s.IsShowOnVideo).OrderBy(s => s.priority);
        lstboxKeyfiat.DataBind();

        DIV_TANZIMKEFIAT.Visible = ds_keyfiat2.Count(s => s.IsShowOnVideo) > 1;

        var ds_ = (from p in dc.MediaLinks
                   where
                   p.MediaId == media_.UID
                   &&
                   p.qualityId != null
                   select new
                   {
                       Id = p.UID,
                       p.OnvanNamayeshFilm,
                       priorty_namayeshfilm = p.priority,
                       Name = p.Quality.Name,
                       priority = p.Quality.Priority,
                       p.UrlName,
                       p.MediaId,
                       NameHajm = p.Hajm == null ? "" : (p.Hajm.Value + " MB")
                   }).ToList();


        bool IsShowOnvan = ds_.Any(s => s.OnvanNamayeshFilm != null && s.OnvanNamayeshFilm.Trim() != "");
        ShowonvanInDownload(IsShowOnvan);
        var ds_media = from p in ds_
                       select new
                       {
                           p.Id,
                           Onvan = (p.OnvanNamayeshFilm == null || p.OnvanNamayeshFilm.Trim() == "") ? "&nbsp;" : p.OnvanNamayeshFilm.Trim(),
                           p.priorty_namayeshfilm,
                           p.Name,
                           p.priority,
                           p.UrlName,
                           p.MediaId,
                           p.NameHajm,
                           visOnvan = IsShowOnvan,
                           script = "SabtDoenload('" + p.Id + "'); ShowFile('" + GetlinkDownload(p.Id) + "'); CloseMenu('btnDownloadDropDown','Div_DownloadBox'); return false;"
                       };



        lstDownload.DataSource = ds_media.OrderByDescending(s => s.priorty_namayeshfilm).ThenBy(s => s.priority);
        lstDownload.DataBind();

        hfmax.Value = countduration.ToString();
        var linkNamayesh = media_.MediaLinks.Where(s => s.IsShowOnVideo == true && s.qualityId != null).OrderBy(s => s.Quality.Priority).FirstOrDefault();


        if (linkNamayesh != null)
        {
            string url = ArssPayamUtility.GetEncodedQueryString("ShowImage.aspx?args={0}", "URL="
                                            + (linkNamayesh.UrlName == null ? "" : linkNamayesh.UrlName)
                                            + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=video");


            if (hfLinkID.Value == "")
                hfLinkID.Value = linkNamayesh.UID.ToString();


            if (IsBrowserIEVersoinLowerEqual9())
            {
                Div_Control.Visible = true;
                DIV_TANZIMKEFIAT.Visible = false;
                Div_VidieoPlayer.InnerHtml = " <embed id=\"video_control\"  runat=\"server\" src=\"/" + linkNamayesh.UrlName.Replace(Request.ServerVariables["APPL_PHYSICAL_PATH"], String.Empty) + "\" width=\"592px\" height=\"320px\""
                        + " autostart=\"false\""
                        + " name=\"windows media player\" type=\"application/x-mplayer2\""
                        + " pluginspage=\"http://www.microsoft.com/Windows/MediaPlayer/\" showcontrols=\"0\""
                        + " showpositioncontrols=\"0\""
                        + " showaudiocontrols=\"1\""
                        + " showtracker=\"1\""
                        + " showdisplay=\"0\""
                        + " showstatusbar=\"0\""
                        + " autosize=\"1\""
                        + " showgotobar=\"0\""
                        + " showcaptioning=\"0\""
                        + " autorewind=\"0\""
                        + " animationatstart=\"1\""
                        + " transparentatstart=\"1\""
                        + " allowscan=\"0\""
                        + " enablecontextmenu=\"0\""
                        + " clicktoplay=\"0\""
                        + " invokeurls=\"0\""
                        + " defaultframe=\"datawindow\">"
                        + " <noembed><img id=\"imgposter\" src=\""
                        + ArssPayamUtility.GetEncodedQueryString("ShowImage.aspx?args={0}", "URL="
                        + (linkNamayesh.Media.PosterAxUrl == null ? "" : linkNamayesh.Media.PosterAxUrl)
                        + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image")
                        + "\"  ></noembed> "
                        + " </embed>";

            }
            else
            {
                if (!IsBrowserFireFox())
                {

                    int countKyfiat = 0;
                    Div_VidieoPlayer.InnerHtml = " <script type=\"text/javascript\" language=\"javascript\" src=\"/Site/Scripts/FZzN8CJO.js\"></script>    "
                                                 + " <script language=\"javascript\" type=\"text/javascript\"> \n"
                                                 + " $(document).ready(function () { "
                                                        + " jwplayer.key = \"fcLgu0IY4OAVd5sPG24Jm8p05MlyyO6j1+nu9w==\"; " + " \n"
                                                        + " jwplayer('" + Div_VidieoPlayer.ClientID + "').setup({ " + " \n"
                                                        + "   playlist: [{ " + " \n"
                        //+ "   image: \""
                        //                 + ArssPayamUtility.GetEncodedQueryString("ShowImage.aspx?args={0}", "URL="
                        //                 + linkNamayesh.Media.PosterAxUrl
                        //                 + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image")
                        //                 + "\", "+" \n"
                                                                                         + "   height: " + Div_VidieoPlayer.Style["height"].Replace("px", "") + ", " + " \n"
                                                                                         + "   width: " + Div_VidieoPlayer.Style["width"].Replace("px", "") + ", " + " \n"
                                                                                         + "   sources: [ " + " \n";
                    foreach (var q in ds_keyfiat2.Where(s => s.IsShowOnVideo).OrderBy(s => s.priority))
                    {
                        string url_st = ArssPayamUtility.GetEncodedQueryString("ShowImage.aspx?args={0}", "URL="
                                                  + (q.urlPath == null ? "" : @"D:\shervin\Hamyarnet\WEB\UploadCenter\s.mp4")
                                                  + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=video");
                        countKyfiat++;
                        Div_VidieoPlayer.InnerHtml += "    { " + " \n"
                        + "   UID:\"" + q.Id + "\", " + " \n"
                        + "    file: 'http://cinema.hamyar.net/" + q.urlPath.Replace(@"C:\Arsspayam\Application\", String.Empty).Replace("\\", "/") + "', " + " \n"
                            //   + "    file: '/s.mp4"+ "', " + " \n"
                        + "    label: \"" + q.Name + "\", " + " \n"
                        + "    default: " + (q.Id.ToString() == hfLinkID.Value).ToString().ToLower() + " , " + " \n"
                        + "     }" + (countKyfiat == ds_keyfiat2.Count(s => s.IsShowOnVideo) ? "" : ", ") + " \n";

                    }

                    Div_VidieoPlayer.InnerHtml += " ] " + " \n"
    + "  }] " + " \n"
    + " }); " + " \n"
    + " }); " + " \n"

                    //+ "    jwplayer('" + Div_VidieoPlayer.ClientID + "').on('error', function (event) { " + " \n"
                        //                    ////+ "  alert('Why did my user pause their video instead of watching it?'); "+" \n"
                        //                    //+ "   jwplayer('" + Div_VidieoPlayer.ClientID + "').load({  "+" \n"
                        //                    //+ "    file: \"/s.mp4\", "+" \n"
                        //                    //+ "     }); "+" \n"
                        //                    + "            jwplayer('" + Div_VidieoPlayer.ClientID + "').play(); " + " \n"
                        //                    + "    }); " + " \n"

                    + " </script> ";
                }
                else
                {
                    // Div_Control.Visible = true;
                    Div_VidieoPlayer.InnerHtml = " <video id=\"video_control\" controls  runat=\"server\" width=\"592\" height=\"360\" > "
                        //  + " <source id=\"Src_Video\"  src=\"" + url + "\" type=\"video/mp4\" >"
                           + " <source id=\"Src_Video\"  src=\"" + url + "\" type=\"video/mp4\" >"
                           + " <div style=\"padding: 80px;font-size:16px\"> برای مشاهده ویدیو از مرورگر فایر فاکس یا کروم استفاده نمایید </div> "
                           + " </video>";
                }

            }

        }
        else
        {
            Div_VidieoPlayer.InnerHtml = " <div style=\"padding-right: 200px;padding-top: 170px;font-size:16px\"> فایل ویدیو برای نمایش یافت نشد</div> ";
            DIV_TANZIMKEFIAT.Style.Add("display", "none");
        }
        Div_KholaseFilm.InnerHtml = media_.Dsc == null ? "" : media_.Dsc.Replace("\n", "<br/>");
        Div_KholaseFilm.InnerHtml += media_.MediaZhanrs.Any() == false ? "" : ("<br/><br/><b> ژانر : </b>" + media_.MediaZhanrs.ToList().Select(s => s.Zhanr.Name).Aggregate((a, b) => a + ", " + b));
        Div_KholaseFilm.InnerHtml += (media_.IsShowSalSakhtMiadi == true ? (media_.SalSakhtMiladi == null ? "" : ("<br/><br/><b> سال ساخت : </b>" + media_.SalSakhtMiladi.ToString())) : (media_.SalSakht == null ? "" : ("<br/><br/> سال ساخت : " + media_.SalSakht.ToString())));

        ShowGallery(media_.MediaGalleries.Any());
        Ul_gallery.InnerHtml = "";
        foreach (var axgallery in media_.MediaGalleries.OrderBy(s => s.Priority))
        {
            Ul_gallery.InnerHtml += " <li style=\"float:left\"> " + "<img src=\""
                + ArssPayamUtility.GetEncodedQueryString("ShowImage.aspx?args={0}", "URL="
                + (axgallery.ImageUrl == null ? "" : axgallery.ImageUrl)
                + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image")
                + "\" /></li> ";
        }




        lbltedaddownload.Text = (dc.FaaliatKarbarans.Count(s => s.FaaliatTypeId != null
                                                                &&
                                                                s.FaaliatTypeId == (int)FaaliatTypeIds.Download
                                                                &&
                                                                s.MediaLinkId != null
                                                                &&
                                                                s.MediaLink.MediaId == media_.UID) + media_.Pishfarz_Download).ToString();

        lblTedadBazdidha.Text = (dc.FaaliatKarbarans.Where(s => s.FaaliatTypeId != null
                                                                &&
                                                                s.FaaliatTypeId == (int)FaaliatTypeIds.Bazdid
                                                                &&
                                                                s.MediaLinkId != null
                                                                &&
                                                                s.MediaLink.MediaId == media_.UID).Select(s => s.IP).Distinct().Count() + media_.Pishfarz_Bazdid).ToString();

        loadFilmhayMoshabe(media_);
    }

    private void ShowonvanInDownload(bool IsShowOnvan)
    {
        Div_Onvan_DownloadBox.Visible = IsShowOnvan;
        if (IsShowOnvan)
        {
            Div_DownloadBox.Style.Add("left", "-90px");
            Div_DownloadBox.Style.Add("*left", "-285px");
            Div_DownloadForm.Style.Add("width", "-325px");
            lstDownload.Width = 323;

        }
        else
        {
            Div_DownloadBox.Style.Add("left", "-10px");
            Div_DownloadBox.Style.Add("*left", "-205px");
            Div_DownloadForm.Style.Add("width", "-195px");
            lstDownload.Width = 192;
        }
    }

    private void ShowGallery(bool value)
    {
        td_Gallery.Visible = value;
        td_Vertical_Split.Visible = value;
        td_FilmhayMoshabePayin_.Visible = value;
        tdFilmhayMoshabeBalaJadval.Visible = !value;
    }

    private string GetlinkDownload(Guid uid)
    {
        return ArssPayamUtility.GetEncodedQueryString("Downloadspec.aspx?args={0}", "ID=" + uid + "&Temp=" + Guid.NewGuid());
    }
    private void AddbtnToUploadPannel_Commnets()
    {
        foreach (ListViewDataItem q in lstviewNazarat.Items)
        {
            ListView lstviewPasokhNazarat = (ListView)q.FindControl("lstviewPasokhNazarat");
            LinkButton btn = (LinkButton)q.FindControl("btnSabtNazarJadid");
            scriptManager_Comments.RegisterAsyncPostBackControl(btn);
            scriptManager_Comments.RegisterAsyncPostBackControl(lstviewPasokhNazarat);
            foreach (ListViewDataItem row in lstviewPasokhNazarat.Items)
            {
                LinkButton btnSabtNazarJadid = (LinkButton)row.FindControl("btnSabtNazarJadid");
                scriptManager_Comments.RegisterAsyncPostBackControl(btnSabtNazarJadid);
            }
        }
    }

    private void Access()
    {
        btnSabtNazarJadid.OnClientClick = "if(ShowTextArea(this)) return false;";//: ("ShowErrorMessage('</br>" + "برای ثبت نظر خود ابتدا باید وارد سایت شوید" + "'); return false");
        btnFullScreen.Visible = false;

    }

    /// <summary>
    /// بررسی میکند که ورژن بروزر استفاده شده است اینترنت اکسپلرور کمتر از از 9 است یانه
    /// زیرا زیر این ورزن بعضی از کدها جواب داده نمی شود
    /// </summary>
    /// <returns></returns>
    bool IsBrowserIEVersoinLowerEqual9()
    {

        if (Request.Browser.Type.ToUpper().Contains("IE")) // replace with your check
        {
            if (Request.Browser.MajorVersion <= 8)
            {
                return true;
            }
        }
        return false;
    }

    bool IsBrowserFireFox()
    {

        if (Request.Browser.Type.ToUpper().Contains("FIREFOX")) // replace with your check
        {

            return true;

        }
        return false;
    }

    private void loadFilmhayMoshabe(Media media)
    {

        List<int> lstmediazhanrids = media.MediaZhanrs.Any() ? media.MediaZhanrs.Select(s => s.ZhanrId).ToList() : (new List<int>());

        var Q_COUNT = (from p in dc.FaaliatKarbarans.Where(s => s.FaaliatTypeId != null && (s.FaaliatTypeId == (int)FaaliatTypeIds.Bazdid || s.FaaliatTypeId == (int)FaaliatTypeIds.Download) && s.MediaLinkId != null && s.MediaLink.MediaId == media.UID)
                       join t in dc.FaaliatKarbarans.Where(s => s.FaaliatTypeId != null && (s.FaaliatTypeId == (int)FaaliatTypeIds.Bazdid || s.FaaliatTypeId == (int)FaaliatTypeIds.Download) && s.MediaLinkId != null && s.MediaLink.MediaId != media.UID)
                       on new { p.IP, p.ZamanSabt.Value.Date } equals new { t.IP, t.ZamanSabt.Value.Date } into rows
                       from s in rows.DefaultIfEmpty()
                       where
                       s != null
                       select new
                       {
                           p.MediaLink.UID,
                           Filmid = s.MediaLink.UID
                       }).ToList();

        var Q_FilmHayMoshabe1 = (from p in dc.Medias
                                 where p.UID != media.UID
                                 &&
                                 p.IsShowMediaInSite==true
                                 select new
                                 {
                                     p.UID,
                                     address = ArssPayamUtility.GetEncodedQueryString("ShowTime.aspx?args={0}", "ID=" + p.UID),
                                     imgurl = (ArssPayamUtility.GetEncodedQueryString("ShowImage.aspx?args={0}", "URL="
                                              + (p.UrlAxFilmhayMoshabe == null ? "" : p.UrlAxFilmhayMoshabe)
                                              + "&TEMP=" + Guid.NewGuid().ToString() + "&mode=image")),
                                     title = p.Name,
                                     sakht_va_zamanfilm = "( سال : " +
                                     (p.IsShowSalSakhtMiadi == true ?
                                     (p.SalSakhtMiladi == null ? "" : p.SalSakhtMiladi.Value.ToString())
                                     : (p.SalSakht == null ? "" : p.SalSakht.Value.ToString()))
                                     + "  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; مدت زمان " + p.MediaTime + " )",
                                     Dsc = p.Dsc_PoshtCard == null ? "" : p.Dsc_PoshtCard.Replace("\n", "</br>"),
                                     countzhanr = p.MediaZhanrs.Count(s => lstmediazhanrids.Contains(s.ZhanrId)),


                                 }).ToList();

        var Q_FilmHayMoshabe_Zhanr = (from p in Q_FilmHayMoshabe1

                                      select new
                                      {
                                          p.UID,
                                          p.address,
                                          p.imgurl,
                                          p.title,
                                          sakht_va_zamanfilm = p.sakht_va_zamanfilm,
                                          p.Dsc,
                                          p.countzhanr,
                                          cnt_Bazdid = Q_COUNT.Count(s => s.Filmid == p.UID && s.UID == media.UID),

                                      }).ToList().OrderByDescending(s => s.countzhanr).ThenByDescending(s => s.cnt_Bazdid).ThenByDescending(s => s.sakht_va_zamanfilm).Take(5);
        var Q_FilmHayMoshabe_cntBazdid = (from p in Q_FilmHayMoshabe1
                                          where
                                          !Q_FilmHayMoshabe_Zhanr.Any(s => s.UID == p.UID)
                                          select new
                                          {
                                              p.UID,
                                              p.address,
                                              p.imgurl,
                                              p.title,
                                              sakht_va_zamanfilm = p.sakht_va_zamanfilm,
                                              p.Dsc,
                                              p.countzhanr,
                                              cnt_Bazdid = Q_COUNT.Count(s => s.Filmid == p.UID && s.UID == media.UID),

                                          }).ToList().OrderByDescending(s => s.cnt_Bazdid).ThenByDescending(s => s.countzhanr).ThenByDescending(s => s.sakht_va_zamanfilm).Take(5);


        var Q_FilmHayMoshabe = Q_FilmHayMoshabe_cntBazdid.Concat(Q_FilmHayMoshabe_Zhanr).OrderByDescending(s => s.countzhanr + s.cnt_Bazdid).ThenByDescending(s => s.sakht_va_zamanfilm);

        lst_FilmhayMoshabeBalayJadval.DataSource = Q_FilmHayMoshabe;
        lst_FilmhayMoshabeBalayJadval.DataBind();

        lst_filmhayMoshabe.DataSource = Q_FilmHayMoshabe;
        lst_filmhayMoshabe.DataBind();
    }

    private void returnTomainPage()
    {
        Response.Redirect("~/main.aspx");
    }
    private void LoadComments()
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var media = dc.Medias.SingleOrDefault(s => s.UID.ToString() == ID);

        var Query_comments = (from p in dc.Comments
                              where
                              p.CommentTypeId == (int)CommentTypeIds.comment
                              &&
                              p.ParentId == null
                              &&
                              p.MediaId.ToString() == ID
                              &&
                              p.IsShowOnSite == true
                              select new
                              {
                                  p.UID,
                                  Like = p.childs_Comments.Count(s => s.CommentTypeId == (int)CommentTypeIds.agree),
                                  DisLike = p.childs_Comments.Count(s => s.CommentTypeId == (int)CommentTypeIds.agree),
                                  datasource = p.childs_Comments.Where(s => s.CommentTypeId == (int)CommentTypeIds.comment && s.IsShowOnSite == true).Select(s => new
                                  {
                                      UID = p.UID,
                                      childIDs = s.UID,
                                      childDsc = s.Dsc,
                                      childLike = s.childs_Comments.Count(t => t.CommentTypeId == (int)CommentTypeIds.agree),
                                      DisLike = s.childs_Comments.Count(t => t.CommentTypeId == (int)CommentTypeIds.agree),
                                      child_user_fullName = s.UserId == null ? "ناشناس" : ((s._User.UserTypeId == (int)UserTypeIds.Modirsystem || s._User.UserTypeId == (int)UserTypeIds.KarbarSystem) ? "سینما همیار" : s._User.FullName),
                                      childTime = s.Time,
                                      childDate = s.Date,
                                      s.SabtDate,
                                      childonclientclick = "if(ShowTextArea(this)) return false;",// : ("ShowErrorMessage('</br>" + "برای ثبت نظر خود ابتدا باید وارد سایت شوید" + "'); return false"),
                                  }).OrderBy(s => s.childDate).ThenBy(s => s.childTime),
                                  FullName = p.UserId == null ? "ناشناس" : ((p._User.UserTypeId == (int)UserTypeIds.Modirsystem || p._User.UserTypeId == (int)UserTypeIds.KarbarSystem) ? "سینما همیار" : p._User.FullName),
                                  Time = p.Time,
                                  Date = p.Date,
                                  p.Dsc,
                                  p.SabtDate,

                                  onclientclick = "if(ShowTextArea(this)) return false;",// : ("ShowErrorMessage('</br>" + "برای ثبت نظر خود ابتدا باید وارد سایت شوید" + "'); return false"),
                              }).OrderByDescending(s => s.Date).ThenByDescending(s => s.Time);

        lstviewNazarat.DataSource = Query_comments;
        lstviewNazarat.DataBind();
    }

    private void SaveNazar(string parentId = null)
    {
        string ID = ArssPayamUtility.GetQueryString("ID", Request.QueryString["args"]);
        var obj = new Comment();
        obj.UID = Guid.NewGuid();
        obj.Time = DateShamsi.GetCurrentHour();
        obj.Date = DateShamsi.GetCurrentDate();
        obj.CommentTypeId = (int)CommentTypeIds.comment;
        obj.Dsc = GetTextArea().Trim().Replace("\n", "</br>");
        obj.IsRead = false;
        obj.IsShowOnSite = false;
        obj.Media = dc.Medias.FirstOrDefault(s => s.UID.ToString() == ID);
        obj.UserId = CurrentUser == null ? (Guid?)null : CurrentUser.UID;
        obj.ParentId = parentId == null ? (Guid?)null : Guid.Parse(parentId);
        dc.Comments.InsertOnSubmit(obj);
        dc.SubmitChanges();
        if (CurrentUser != null)
        {
            EventLoger.LogEvent("کاربر با نام '" + CurrentUser.FullName + "" + "' و نام کاربری '" + CurrentUser.UserName + "' نظر خود را در رابطه با برنامه '" + obj.Media.Name + "' ثبت نمود.", (int)EventTypeIds.Darj, CurrentUser.UID);
        }


    }

    [System.Web.Services.WebMethod]
    public static string SabtBazidid(string linkid)
    {
        string IP = HttpContext.Current.Request.UserHostAddress;
        dbhamyarnetTvDataContext dc1 = new dbhamyarnetTvDataContext();
        var usr = ((_User)HttpContext.Current.Session["userhamyartv"] == null ? null : (_User)HttpContext.Current.Session["userhamyartv"]);
        var link = dc1.MediaLinks.SingleOrDefault(s => s.UID.ToString() == linkid);
        var bazdid = dc1.FaaliatKarbarans.FirstOrDefault(s => s.IP == IP && s.MediaLinkId.ToString() == linkid && s.FaaliatTypeId == (int)FaaliatTypeIds.Bazdid);
        if (bazdid == null)
        {
            bazdid = new FaaliatKarbaran();
            bazdid.UID = Guid.NewGuid();
            bazdid.MediaLink = link;
            bazdid._User = usr;
            bazdid.FaaliatType = dc1.FaaliatTypes.SingleOrDefault(s => s.Id == (int)FaaliatTypeIds.Bazdid);
            bazdid.IP = IP;
            bazdid.ZamanSabt = DateTime.Now;
            dc1.FaaliatKarbarans.InsertOnSubmit(bazdid);
            dc1.SubmitChanges();
        }
        return "";
    }
    [System.Web.Services.WebMethod]
    public static string SabtDownload(string linkid)
    {
        string IP = HttpContext.Current.Request.UserHostAddress;
        dbhamyarnetTvDataContext dc1 = new dbhamyarnetTvDataContext();
        var usr = ((_User)HttpContext.Current.Session["userhamyartv"] == null ? null : (_User)HttpContext.Current.Session["userhamyartv"]);
        var link = dc1.MediaLinks.SingleOrDefault(s => s.UID.ToString() == linkid);
        var bazdid = dc1.FaaliatKarbarans.FirstOrDefault(s => s.IP == IP && s.MediaLinkId.ToString() == linkid && s.FaaliatTypeId == (int)FaaliatTypeIds.Download);
        if (bazdid == null)
        {
            try
            {
                bazdid = new FaaliatKarbaran();
                bazdid.UID = Guid.NewGuid();
                bazdid.MediaLink = link;
                bazdid._User = usr;
                bazdid.FaaliatType = dc1.FaaliatTypes.SingleOrDefault(s => s.Id == (int)FaaliatTypeIds.Download);
                bazdid.IP = IP;
                bazdid.ZamanSabt = DateTime.Now;
                dc1.FaaliatKarbarans.InsertOnSubmit(bazdid);
                dc1.SubmitChanges();
            }
            catch
            {
                Mailer.SendMail("خطا در دانلود لینک '" + link.MediaName.Replace(" ", "_") + "." + link.ExtentionMedia + "' برای فیلم ''  " + link.Hajm, "خطا در دانلود", "korooshbaghbani@yahoo.com", true, "");
            }
        }
        return "";
    }




}
