﻿using DataAccsess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Site_Pages_SabtNam : PrimeryPage
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void btnSabt_Click(object sender, ImageClickEventArgs e)
    {
        if (CheckValidate_SabtNam())
        {
            Save_SabtNam();
            ShowSeccessMessage("اطلاعات با موفقیت ثبت گردید." + "</br>لطفا برای تکمیل فرآیند ثبت نام به ایمیل خود مراجعه نموده و بر روی لینک ارسالی کلیک نمایید.");
        }
    }

    /// <summary>
    /// بررسی ثبت نام
    /// </summary>
    /// <returns></returns>
    private bool CheckValidate_SabtNam()
    {
        dbhamyarnetTvDataContext dc1 = new dbhamyarnetTvDataContext();
        string Msg = "لطفا به نکات زیر توجه نمایید :" + "</br>";
        bool result = true;
        int i = 0;

        if (txtUsername_Email.Text.Trim() == "" || txtUsername_Email.Text.Trim() == "اجباری")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "ایمیل (نام کاربری) را وارد نمایید." + "</br>";
        }
        else if (!Validation.IsEmail(txtUsername_Email.Text.Trim()))
        {
            result = false;
            Msg += (++i).ToString() + " - " + "ایمیل (نام کاربری) را صحیح وارد نمایید." + "</br>";
        }
        else if (dc1._Users.Any(s => s.UserName == txtUsername_Email.Text.Trim() && s.IsLogin == true))
        {
            result = false;
            Msg += (++i).ToString() + " - " + "ایمیل شما (نام کاربری) در سایت قبلا ثبت شده است." + "</br>";
        }

        if (txt_Password.Text == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "رمز عبور را وارد نمایید." + "</br>";
        }
        else if (txt_Password.Text.Length < 6)
        {
            result = false;
            Msg += (++i).ToString() + " - " + "رمز عبور باید حداقل دارای 6 حرف باشد." + "</br>";
        }
        else if (txt_Password.Text != txt_RePassword.Text)
        {
            result = false;
            Msg += (++i).ToString() + " - " + "رمز عبور با تکرار آن برابر نمی باشد." + "</br>";
        }

        if (txtName.Text.Trim() == "" || txtName.Text.Trim() == "اجباری")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "نام را وارد نمایید." + "</br>";
        }

        if (txtLasname.Text.Trim() == "" || txtLasname.Text.Trim() == "اجباری")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "نام خانوادگی را وارد نمایید." + "</br>";
        }

        if (txt_ShomareTel.Text.Trim() != ""
            &&
            txt_ShomareTel.Text.Trim().Length != 11
            )
        {
            result = false;
            Msg += (++i).ToString() + " - " + "شماره همراه را صحیح و کامل وارد نمایید." + "</br>";
        }

        if (!security_captcha.Validate(txt_SecurityCode.Text.Trim()))
        {
            
            result = false;
            Msg += (++i).ToString() + " - " + "کلید امنیتی را صحیح وارد نمایید." + "</br>";
        }

        if (hfGHavaninSite.Value != "true")
        {
            result = false;
            Msg += (++i).ToString() + " - " + " تیک پذیرفتن قوانین سایت را بزنید." + "</br>";
        }
        txt_SecurityCode.Text = "";
        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }
    /// <summary>
    /// ذخیره کاربر 
    /// </summary>
    private void Save_SabtNam()
    {

        bool isInsert = false;
        var obj = dc._Users.FirstOrDefault(s => s.UserName == txtUsername_Email.Text.Trim());
        if (obj == null)
        {

            obj = new _User();
            obj.UID = Guid.NewGuid();
            dc._Users.InsertOnSubmit(obj);
            isInsert = true;
        }
        obj.UserName = txtUsername_Email.Text.Trim();
        obj.Email = txtUsername_Email.Text.Trim();
        obj.IsActive = true;
        obj.Password = EncryptedQueryString.GetMD5Hash(txt_Password.Text);
        obj.UserTypeId = (int)UserTypeIds.MihmanHamyarnet;
        obj.FirstName = txtName.Text.Trim();
        obj.LastName = txtLasname.Text.Trim();
        obj.Telephone = obj.Mobile = txt_ShomareTel.Text.Trim();
        obj.IsLogin = false;
        obj.DateTimeSabtNam = DateTime.Now;
        bool ischange = dc.GetChangeSet().Updates.Any();
        dc.SubmitChanges();
        if (isInsert)
            EventLoger.LogEvent("کاربر '" + obj.FullName + "' با نام کاربری '" + obj.UserName + "' در سایت سینما همیار عضو گردید", (int)EventTypeIds.Darj, CurrentUser == null ? obj.UID : CurrentUser.UID);
        else if (ischange)
            EventLoger.LogEvent("کاربر '" + obj.FullName + "' با نام کاربری '" + obj.UserName + "' در سایت سینما همیار ویرایش گردید", (int)EventTypeIds.virayesh, CurrentUser == null ? obj.UID : CurrentUser.UID);


        string msgBody = obj.FullName + " از اینکه به عضویت سینما همیار درآمدید بسیار متشکریم لطفا بر روی لینک زیر کلیک نمایید. " + "<br/>" + "<br/>"
            + "<a href=\"" + ArssPayamUtility.GetEncodedQueryString("http://cinema.hamyar.net/main.aspx" + "?args={0}", "UID=" + obj.UID) + "\">تکمیل فرآیند ثبت نام - کلیک نمایید</a>";
           
        Mailer.SendMail(msgBody, " سینما همیار ", obj.Email, true, "سینما همیار");

    }
}