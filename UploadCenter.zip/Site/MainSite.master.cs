﻿using DataAccsess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utility;

public partial class Pages_Site_MainSite : PrimeryMaster
{
    dbhamyarnetTvDataContext dc = new dbhamyarnetTvDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        form1.DefaultButton = btn_DosentWork.UniqueID;
        if (!IsPostBack)
        {
            CheckAndLogin();
            SetFilter();
        }

        RestartPage();
    }


    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);

        if (ArssPayamUtility.GetQueryString("SetFilter", Request.QueryString["args"]) == "true")
            SetFilter();

        Access();
    }


    protected void li_DastebandiResult_Selecting(object sender, LinqDataSourceSelectEventArgs e)
    {
        e.Result = SearchDastebandi();
    }
    protected void btnLoginForm_Click(object sender, ImageClickEventArgs e)
    {
        if (CheckValidate_Login())
        {
            Login_SaveInDb();
            RestartPage();
            ClearLogin();
        }
    }
    protected void btnModisystem_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Application/Pages/AppMain.aspx");
    }

    protected void btn_Exit_Click(object sender, EventArgs e)
    {
        Exit();
    }
    protected void btnForgatPassword_Click(object sender, EventArgs e)
    {
        if (CheckValidate_ForgatPassword())
        {
            SendMail_ForgatPassword();
            ShowSeccessMessage("</br>" + "کلمه عبور به ایمیل شما ارسال گردید");


        }
    }
    protected void imgbtnFilter_Click(object sender, ImageClickEventArgs e)
    {
        string zhanr = "";
        foreach (DataListItem q in lstboxZhanr.Items)
        {
            CheckBox chk = (CheckBox)q.FindControl("chkzhanr");
            if (chk.Checked == true)
                zhanr += lstboxZhanr.DataKeys[q.ItemIndex].ToString() + ",";
        }
        if (zhanr != "")
            zhanr = zhanr.Substring(0, zhanr.Length - 1);
        Response.Redirect(ArssPayamUtility.GetEncodedQueryString("~/Site/Pages/ListShow.aspx?args={0}",
              "namfilm=" + txtNamFilm.Text.Trim()
              + "&zhanr=" + zhanr
              + "&avamelfilm=" + txtAvamelFilm.Text.Trim()
              + "&salaz=" + txtSalSakhtAz.Text.Trim()
              + "&salta=" + txtTaSalSakht.Text.Trim()
              ));
    }
    protected void imgbtn_SabtDarkhast_Click(object sender, ImageClickEventArgs e)
    {
        if (CheckValidate_DarkhastFilm())
        {
            SaveDarkhast();
            ClearDarkhastFilm();
            ShowSeccessMessage("</br>" + "درخواست شما ثبت گردید");


        }
    }
    protected void lblNameMoshtarakHamyarnetVaMihman_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Site/Pages/SignUp.aspx");
    }

    /// <summary>
    /// بررسی می کند در صورتی که بار اولی باشد که کاربر وارد این صفحه می شود
    /// کاربر مستقیم لاگین می شود
    /// </summary>
    private void CheckAndLogin()
    {
        string UID = ArssPayamUtility.GetQueryString("UID", Request.QueryString["args"]);

        var usr = dc._Users.SingleOrDefault(s => s.UID.ToString() == UID && s.IsLogin == false);
        if (usr != null)
        {
            usr.IsLogin = true;
            dc.SubmitChanges();
            Session["userhamyartv"] = usr;
            EventLoger.LogEvent("کاربر سینما همیار '" + usr.FullName + "' با نام کاربری '" + usr.UserName + "' به سایت وارد شد. تکمیا فرآیند ثبت نام.", (int)EventTypeIds.VorodBeSystem, usr.UID);
            ShowSeccessMessage("</br>" + usr.FullName + " به سایت سینما همیار خوش آمدید.");
        }

    }
    private void Access()
    {
        if (CurrentUser == null
            ||
            (
            CurrentUser.UserTypeId != (int)UserTypeIds.Modirsystem
            &&
            CurrentUser.UserTypeId != (int)UserTypeIds.KarbarSystem
            )
            )
            DIV_MODIRSYSTEM.Visible = false;
        else if (CurrentUser != null && (CurrentUser.UserTypeId == (int)UserTypeIds.KarbarSystem || CurrentUser.UserTypeId == (int)UserTypeIds.Modirsystem))
            DIV_MODIRSYSTEM.Visible = true;

    }
    /// <summary>
    /// بررسی درخواست فیلم
    /// </summary>
    /// <returns></returns>
    private bool CheckValidate_DarkhastFilm()
    {

        string Msg = "لطفا به نکات زیر توجه نمایید :" + "</br>";
        bool result = true;
        int i = 0;
        if (CurrentUser == null)
        {
            ShowErrorMessage("</br>" + "برای ثبت درخواست ابتدا باید وارد سایت شوید.");
            return false;
        }
        if (txtSalSakht_DarkhastSabtFilm.Text.Trim() == "" && txtNamFilm_DarkhastSabtFilm.Text.Trim() == "" && txtAvamelFilm_DarkhastSabtFilm.Text.Trim() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "حداقل یکی از فیلدهای 'نام فیلم' یا 'سال ساخت' یا 'عوامل فیلم' را باید تکمیل نمایید." + "</br>";
        }


        if (!result)
            ShowErrorMessage(Msg);
        return result; ;
    }
    /// <summary>
    /// فرم درخواست را پاک میکند
    /// </summary>
    private void ClearDarkhastFilm()
    {
        txtNamFilm_DarkhastSabtFilm.Text = "";
        txtSalSakht_DarkhastSabtFilm.Text = "";
        txtAvamelFilm_DarkhastSabtFilm.Text = "";
        txtDsc_SabtDarkhastFilm.Text = "";
    }
    /// <summary>
    /// ذخیره درخواست فیلم
    /// </summary>
    private void SaveDarkhast()
    {
        DarkhastFilm obj = new DarkhastFilm();
        obj.UID = Guid.NewGuid();
        obj.UserId = CurrentUser.UID;
        obj.ZamanSabt = DateTime.Now;
        obj.Time = DateShamsi.GetCurrentHour();
        obj.Date = DateShamsi.GetCurrentDate();
        obj.IsRead = false;
        obj.SalSakht = txtSalSakht_DarkhastSabtFilm.Text.Trim();
        obj.NamFilm = txtNamFilm_DarkhastSabtFilm.Text.Trim();
        obj.AvamelFilm = txtAvamelFilm_DarkhastSabtFilm.Text.Trim();
        obj.Dsc = txtDsc_SabtDarkhastFilm.Text.Trim();
        dc.DarkhastFilms.InsertOnSubmit(obj);
        dc.SubmitChanges();
        EventLoger.LogEvent("کاربر '" + CurrentUser.FullName + "' با نام کاربری '" + CurrentUser.UserName + "' درخواست فیلم " + (txtNamFilm_DarkhastSabtFilm.Text.Trim() != "" ? (" با عنوان '" + txtNamFilm_DarkhastSabtFilm.Text.Trim() + "'") : "") + (txtSalSakht_DarkhastSabtFilm.Text.Trim() != "" ? (" با سال ساخت '" + txtSalSakht_DarkhastSabtFilm.Text.Trim() + "'") : "") + (txtAvamelFilm_DarkhastSabtFilm.Text.Trim() != "" ? (" با عوامل فیلم '" + txtAvamelFilm_DarkhastSabtFilm.Text.Trim() + "'") : "") + " ثبت نمود.", (int)EventTypeIds.Darj, CurrentUser.UID);


    }

    /// <summary>
    /// ارسال ایمیل به همراه رمز عبور جدید
    /// </summary>
    private void SendMail_ForgatPassword()
    {
        string Email = GetEmailFromForgatPassword();
        var obj = dc._Users.SingleOrDefault(s => s.UserName == Email);
        if (obj == null)
            return;
        string PasswordNew = (new Random()).Next(100000000, 999999999).ToString();
        obj.Password = EncryptedQueryString.GetMD5Hash(PasswordNew);
        dc.SubmitChanges();
        EventLoger.LogEvent("برای کاربر '" + obj.FullName + "' با نام کاربری '" + obj.UserName + "' رمز عبور جدید صادر شد. ", (int)EventTypeIds.virayesh, obj.UID);

        string msgBody = " نام کاربری به همراه رمزعبور جدید : " + "<br/>"
    + "نام کاربری : " + obj.UserName + "<br/>"
    + "رمز عبور : " + PasswordNew + "<br/>";

        Mailer.SendMail(msgBody, "رمز عبور جدید", obj.Email, true, "سینما همیار");
    }
    /// <summary>
    /// فراموشی رمز عبور را بررسی میکند
    /// </summary>
    /// <returns></returns>
    private bool CheckValidate_ForgatPassword()
    {
        string Email = GetEmailFromForgatPassword();
        string Msg = "لطفا به نکات زیر توجه نمایید :" + "</br>";
        bool result = true;
        int i = 0;

        if (Email.Trim() == "")
        {
            result = false;
            Msg += (++i).ToString() + " - " + "ایمیل خود را وارد نمایید." + "</br>";
        }
        else if (!Validation.IsEmail(Email.Trim()))
        {
            result = false;
            Msg += (++i).ToString() + " - " + "ایمیل خود را صحیح وارد نمایید." + "</br>";
        }
        else if (!dc._Users.Any(s => s.UserName == Email.Trim() && s.IsLogin == true))
        {
            result = false;
            Msg += (++i).ToString() + " - " + "ایمیل شما در سایت ثبت نشده است." + "</br>";
        }

        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }


    /// <summary>
    /// در صورتی که در نام کاربری ایمیل وجود داشته باشد از نام کاربری خوانده می شود
    /// در غیر این صورت از وب سرویس همیارنت خوانده شده سپس در صورتی که در سیستم وجود نداشته باشد در سیستم ذخیره می شود
    /// </summary>
    private void Login_SaveInDb()
    {
        dbhamyarnetTvDataContext dc1 = new dbhamyarnetTvDataContext();
        var usr = dc1._Users.FirstOrDefault(s => s.UserName == txtusername.Text.Trim());
        if (usr != null && usr.UserTypeId != (int)UserTypeIds.MoshtarakHamyarnet)
        {
           // _User usr = dc1._Users.Single(s => s.UserName == txtusername.Text.Trim() && s.Password == EncryptedQueryString.GetMD5Hash(txtpass.Text.Trim()));
            Session["userhamyartv"] = usr;
            EventLoger.LogEvent("کاربر سینما همیار '" + usr.FullName + "' با نام کاربری '" + usr.UserName + "' به سایت وارد شد.", (int)EventTypeIds.VorodBeSystem, usr.UID);
            ShowSeccessMessage("</br>" + usr.FullName + " به سایت همیار سینما خوش آمدید.");
        }
        else
        {

            AnsJasonObject obj = ArssPayamHelp.GetUserFromWebService(txtusername.Text.Trim(), txtpass.Text);
            if (obj != null && obj.code == "1")
            {
                string _Event = "UPDATE";
                //_User usr = dc1._Users.SingleOrDefault(s => s.UserName == txtusername.Text.Trim());
                if (usr == null)
                {
                    usr = new _User();
                    usr.UID = Guid.NewGuid();
                    usr.UserName = txtusername.Text.Trim();
                    usr.IsActive = true;
                    usr.DateTimeSabtNam = DateTime.Now;
                    usr.IsLogin = true;
                    usr.UserTypeId = (int)UserTypeIds.MoshtarakHamyarnet;
                    dc1._Users.InsertOnSubmit(usr);
                    _Event = "INSERT";
                }
                usr.Telephone = obj.customer.tel;
                usr.FirstName = obj.customer.name;
                usr.LastName = "";
                bool ischange = dc1.GetChangeSet().Updates.Any();
                dc1.SubmitChanges();

                if (_Event == "_INSERT")
                    EventLoger.LogEvent("مشترک همیارنت '" + obj.customer.name + "' با نام کاربری '" + usr.UserName + "' در سیستم درج گردید", (int)EventTypeIds.Darj, usr.UID);
                else if (_Event == "UPDATE" && ischange)
                    EventLoger.LogEvent("مشترک همیارنت '" + obj.customer.name + "' با نام کاربری '" + usr.UserName + "' در سیستم ویرایش گردید", (int)EventTypeIds.virayesh, usr.UID);

                Session["userhamyartv"] = usr;
                EventLoger.LogEvent("مشترک همیارنت '" + usr.FullName + "' با نام کاربری '" + usr.UserName + "' به سایت وارد شد.", (int)EventTypeIds.VorodBeSystem, usr.UID);
                ShowSeccessMessage("</br>" + usr.FullName + " به سایت سینما همیار خوش آمدید.");
            }
        }
    }
    /// <summary>
    /// در صورتی که اطلاعات ورود به سیستم صحیح وارد نشده باشد پیغام مناسب داده می شود
    /// </summary>
    /// <returns></returns>
    private bool CheckValidate_Login()
    {
        string Msg = "لطفا به نکات زیر توجه نمایید :" + "</br>";
        bool result = true;
        int i = 0;

        var obj_usr = dc._Users.FirstOrDefault(s => s.UserName == txtusername.Text.Trim());

        if (obj_usr == null)
        {

            if (Validation.IsEmail(txtusername.Text.Trim()))
            {
                if (!dc._Users.Any(s => s.UserName == txtusername.Text.Trim() && s.Password == EncryptedQueryString.GetMD5Hash(txtpass.Text.Trim()) && s.IsLogin == true))
                {
                    result = false;
                    Msg += (++i).ToString() + " - " + "نام کاربری و یا رمز عبور اشتباه می باشد." + "</br>";
                }
            }
            else
            {
                AnsJasonObject obj = ArssPayamHelp.GetUserFromWebService(txtusername.Text.Trim(), txtpass.Text);
                if (obj == null || obj.code != "1")
                {
                    result = false;
                    Msg += (++i).ToString() + " - " + "نام کاربری و یا رمز عبور اشتباه می باشد." + "</br>";
                }
            }
        }
        else
        {
            if (obj_usr.UserTypeId == (int)UserTypeIds.MoshtarakHamyarnet)
            {
                AnsJasonObject obj = ArssPayamHelp.GetUserFromWebService(txtusername.Text.Trim(), txtpass.Text);
                if (obj == null || obj.code != "1")
                {
                    result = false;
                    Msg += (++i).ToString() + " - " + "نام کاربری و یا رمز عبور اشتباه می باشد." + "</br>";
                }
            }
            else
            {
                if (!(obj_usr.Password == EncryptedQueryString.GetMD5Hash(txtpass.Text.Trim())))
                {
                    result = false;
                    Msg += (++i).ToString() + " - " + "نام کاربری و یا رمز عبور اشتباه می باشد." + "</br>";
                }
                if (obj_usr.IsLogin == false || obj_usr.IsActive == false)
                {
                    result = false;
                    Msg += (++i).ToString() + " - " + "نام کاربری و یا رمز عبور اشتباه می باشد." + "</br>";
                }
            }
        }
        if (!result)
            ShowErrorMessage(Msg);
        return result;
    }
    /// <summary>
    /// پاک کردن اطلاعات لاگین
    /// </summary>
    private void ClearLogin()
    {
        txtusername.Text = "";
        txtpass.Text = "";
    }


    /// <summary>
    /// دسته بندی ها را گرفته و د منوی دسته بندی قرار می دهد
    /// </summary>
    /// <returns></returns>
    private object SearchDastebandi()
    {
        var query = from p in dc.DastebandiTypes.ToList()
                    where
                    p.IsShowOnMenu == true
                    select new
                    {
                        p.Priority,
                        p.Id,
                        txtDastebandi = p.Name,
                        Url = ArssPayamUtility.GetEncodedQueryString("~/Site/Pages/ListShow.aspx?args={0}", "mode=" + p.Id + "&SetFilter=true"),
                    };
        return query.OrderBy(p => p.Priority);
    }
    /// <summary>
    /// دسترسی کاربران به منو را فراهم می کند
    /// </summary>
    private void Acsess()
    {
        Div_Login.Visible = CurrentUser == null;
        Div_Exit.Visible = CurrentUser != null;
    }
    /// <summary>
    /// اطلاعات مربوط به کاربر نمایش داده می شود
    /// </summary>
    private void Display()
    {
        string currenturl = HttpContext.Current.Request.Url.AbsolutePath;

        if (CurrentUser == null)
        {
            lblNameMoshtarakHamyarnetVaMihman.Text = "کاربر مهمان، خوش آمدید";
            lblNameMoshtarakHamyarnetVaMihman.OnClientClick = "return false;";
            lblNameMoshtarakHamyarnetVaMihman.CssClass = "MenuTextLabel";


        }
        else
        {
            lblNameMoshtarakHamyarnetVaMihman.Text = CurrentUser.FullName + ", خوش آمدید";
            lblNameMoshtarakHamyarnetVaMihman.OnClientClick = "";
            lblNameMoshtarakHamyarnetVaMihman.CssClass = "MenuText_User";
            Div_Menu_User.Attributes.Add("class", "ButtonMenu");

        }

    }
    /// <summary>
    /// مقادیر فیلتر را در کامبو آن قرار می دهیم
    /// </summary>
    private void SetFilter()
    {

        txtNamFilm.Text = ArssPayamUtility.GetQueryString("namfilm", Request.QueryString["args"]);
        string zhanr = ArssPayamUtility.GetQueryString("zhanr", Request.QueryString["args"]);
        txtAvamelFilm.Text = ArssPayamUtility.GetQueryString("avamelfilm", Request.QueryString["args"]);
        txtSalSakhtAz.Text = ArssPayamUtility.GetQueryString("salaz", Request.QueryString["args"]);
        txtTaSalSakht.Text = ArssPayamUtility.GetQueryString("salta", Request.QueryString["args"]);

        List<string> lstzhanr = (zhanr == null || zhanr.Trim() == "") ? new List<string>() : zhanr.Trim().Split(',').ToList();

        var ds_Zhar = (from p in dc.Zhanrs.OrderBy(s => s.Priority)
                       select new
                           {
                               p.Id,
                               p.Name,
                               script = "ChangeZhanr(this,'" + p.Name + ", ','lblZhanrName','hfZhanrName');",
                               Value = lstzhanr.Contains(p.Id.ToString())
                           }).ToList();
        hfZhanrName.Value = ds_Zhar.Any(s => s.Value) ? (ds_Zhar.Where(s => s.Value).Select(s => s.Name).Aggregate((a, b) => a + ", " + b) + ",") : "";
        lstboxZhanr.DataSource = ds_Zhar;
        lstboxZhanr.DataBind();


    }

    /// <summary>
    ///خروج از سامانه 
    /// </summary>
    private void Exit()
    {
        if (CurrentUser != null)
        {
            EventLoger.LogEvent("کاربر  '" + CurrentUser.FullName + "' با نام کاربری '" + CurrentUser.UserName + "' از سایت خارج شد.", (int)EventTypeIds.KhorojAzSystem, CurrentUser.UID);
        }
        Session.RemoveAll();
        string currenturl = HttpContext.Current.Request.Url.AbsolutePath;
        if (currenturl.ToLower().Contains("signup.aspx"))
            Response.Redirect("~/main.aspx");
        RestartPage();
    }


    /// <summary>
    /// تمام اطلاعات صفحه را بارگزاری میکند
    /// </summary>
    private void RestartPage()
    {
        Display();
        Acsess();
    }





}
